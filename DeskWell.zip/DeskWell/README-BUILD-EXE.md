# Turning DeskWell into a Windows installer (.exe)

Good news: because DeskWell uses only JavaFX + SQLite + JNA + Gson + PDFBox
(pure Java, nothing that needs a compiler at runtime), you can bundle it
with its own private Java runtime so the **person installing it never
needs to install Java themselves.** They just double-click your EXE like
any normal Windows app.

This packaging step has to be done once, by you, **on a Windows machine**,
using a tool called `jpackage` that ships inside the JDK. You do it once;
the output is a normal `.exe` you can hand out to anyone.

## What you need on YOUR machine (one-time setup)

1. **JDK 21** (this project targets Java 21) — install the full JDK, not
   just a JRE, since it includes `jpackage`.
   - Get "Eclipse Temurin 21 (JDK)" for Windows x64:
     https://adoptium.net/temurin/releases/?version=21
   - Run the installer, and during setup make sure "Set JAVA_HOME" and
     "Add to PATH" are checked.

2. **Maven** — to build the project.
   - https://maven.apache.org/download.cgi (grab the "Binary zip archive",
     unzip it somewhere like `C:\maven`, add `C:\maven\bin` to your PATH)

3. **WiX Toolset v3.11** — `jpackage` needs this to produce a `.exe`
   installer on Windows.
   - https://wixtoolset.org/docs/wix3/ (download and run the installer)
   - Reboot or open a fresh terminal afterward so PATH updates apply.

4. Confirm everything is on PATH by opening Command Prompt and running:
   ```
   java -version      (should say 21.x)
   mvn -version
   jpackage --version
   ```
   If any of these fail, that tool isn't on PATH yet — fix that before
   continuing.

## Building the EXE

1. Unzip this project folder anywhere, e.g. `C:\DeskWell`.
2. Open Command Prompt, `cd` into that folder (the one with `pom.xml`).
3. Double-click, or run from the Command Prompt:
   ```
   build-exe.bat
   ```
   This script:
   - Runs `mvn clean package` to compile everything into one
     self-contained "fat jar" (`target\DeskWell-app.jar`) that already
     has JavaFX, SQLite, JNA, Gson and PDFBox bundled inside it.
   - Runs `jpackage`, which bundles that jar together with a private
     copy of the Java runtime and wraps the whole thing into a Windows
     installer.
4. When it finishes, you'll find:
   ```
   installer\DeskWell-1.0.0.exe
   ```
   That single file **is** your distributable installer.

## Giving it to users

Send them `DeskWell-1.0.0.exe`. They double-click it, click through the
install wizard (it'll offer a Start Menu shortcut), and the app runs.
They do **not** need Java, Maven, or any dev tools installed — the JRE
is bundled inside the app's install folder automatically by `jpackage`.

## Optional: a custom icon

If you want your own icon instead of the default Java icon:
1. Make a `.ico` file (e.g. `icon.ico`, must actually be `.ico` format,
   not just a renamed `.png`).
2. Put it in the project root next to `pom.xml`.
3. Add this line inside the `jpackage` command in `build-exe.bat`:
   ```
   --icon icon.ico
   ```

## Troubleshooting

- **"jpackage failed... WiX"** → WiX isn't installed or isn't on PATH.
  Reinstall it and open a new Command Prompt.
- **App opens then instantly closes** → run it from a terminal instead
  of double-clicking, so you can see the error:
  `installer\DeskWell\DeskWell.exe` (after install) or
  `java -jar target\DeskWell-app.jar` (before packaging) — either will
  print the real Java stack trace.
- **Antivirus / SmartScreen warning** → normal for unsigned installers
  from indie devs. Windows will show "Windows protected your PC" the
  first time; users click "More info" → "Run anyway". To avoid this
  warning entirely you'd need a paid code-signing certificate — not
  required to make the app work, just to remove that warning.
- **Build fails on `mvn clean package`** → read the actual Maven error
  near the top of the red text; it's almost always a missing PATH
  variable (JAVA_HOME) or a typo, not something wrong with the code.

<h1 align="center">🖥️ DeskWell</h1>

<p align="center">
<b>A modern Digital Wellbeing & Productivity Tracker for Windows.</b><br>
Track your screen time, stay focused, and build healthier digital habits.
</p>

<p align="center">

<a href="https://github.com/jahmed9832/DeskWell/releases/download/DeskWell_Installer/DeskWell-1.0.0.exe">
    <img src="https://img.shields.io/badge/⬇️_DOWNLOAD_DESKWELL_FOR_WINDOWS-brightgreen?style=for-the-badge&logo=windows&logoColor=white" alt="Download DeskWell">
</a>


</p>

DeskWell helps you understand and improve your digital habits by tracking application usage in real time, analyzing productivity, and providing tools to stay focused. With detailed insights, smart reminders, and distraction-free work sessions, DeskWell makes it easier to balance productivity and digital wellbeing.

## ✨ Features

* 📊 Real-time application usage tracking
* 📂 Automatic app categorization
* 🎯 Focus Mode for distraction-free work
* 🚫 App Blocker for selected applications
* 📈 Daily, weekly, and monthly productivity reports
* 🎯 Custom productivity goals
* 🔔 Smart screen-time reminders
* 📤 Export reports as PDF and CSV
* 🌙 Light & Dark themes
* 🚀 Launch at Windows startup
* 🔒 Privacy-first with local data storage

## 🛠️ Tech Stack

* **Java**
* **JavaFX**
* **SQLite**
* **JDBC**
* **Maven**



Open the project in your preferred Java IDE, configure JavaFX if needed, and run the application.



**DeskWell** is built to help students, developers, freelancers, and professionals work smarter, stay focused, and develop healthier digital habits.

@echo off
REM ============================================================
REM  DeskWell - build a self-contained Windows EXE installer
REM  Run this on a Windows machine that has JDK 21 + Maven + WiX
REM  installed (see README-BUILD-EXE.md for setup steps).
REM ============================================================

echo.
echo [1/3] Building fat JAR with Maven...
call mvn clean package
if errorlevel 1 (
    echo.
    echo Maven build failed. Fix the errors above and re-run this script.
    pause
    exit /b 1
)

echo.
echo [2/3] Locating built jar...
set JARFILE=target\DeskWell-app.jar
if not exist "%JARFILE%" (
    echo Could not find %JARFILE% - check the target\ folder for the actual name.
    dir target\*.jar
    pause
    exit /b 1
)

echo.
echo [3/3] Running jpackage to create the installer EXE...
if not exist installer mkdir installer

jpackage ^
  --input target ^
  --main-jar DeskWell-app.jar ^
  --main-class com.deskwell.Launcher ^
  --name DeskWell ^
  --app-version 1.0.0 ^
  --vendor "DeskWell" ^
  --description "Desktop Digital Wellbeing Application" ^
  --type exe ^
  --dest installer ^
  --icon icon.ico ^
  --win-shortcut ^
  --win-menu ^
  --win-dir-chooser

if errorlevel 1 (
    echo.
    echo jpackage failed. Make sure the WiX Toolset is installed and on PATH.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo  Done! Your installer is in the "installer" folder:
echo     installer\DeskWell-1.0.0.exe
echo  Send that single file to users - they just double-click it
echo  to install DeskWell. No Java setup needed on their end.
echo ============================================================
pause

package com.deskwell;

import com.deskwell.controller.MainController;
import com.deskwell.database.DatabaseManager;
import com.deskwell.service.*;
import com.deskwell.tracker.ActivityTracker;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.awt.AWTException;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.util.logging.Logger;

public class DeskWellApp extends Application {
    private static final Logger logger = Logger.getLogger(DeskWellApp.class.getName());
    
    private ActivityTracker activityTracker;
    private DatabaseManager databaseManager;
    private SettingsService settingsService;
    private CategoryService categoryService;
    private NotificationService notificationService;
    private ThemeManager themeManager;
    private BackupService backupService;
    private StartupManager startupManager;
    private AppBlockerService appBlockerService;
    private MainController mainController;
    private TrayIcon trayIcon;
    private Stage primaryStage;
    // True only when the user picked "Exit" from the tray menu / really
    // wants to quit. Used to tell a normal window-close (the X button) apart
    // from a real shutdown.
    private volatile boolean exitRequested = false;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        try {
            logger.info("Starting DeskWell...");
            
            // Initialize database
            databaseManager = DatabaseManager.getInstance();
            databaseManager.initialize();
            logger.info("Database initialized");

            // Initialize services
            settingsService = new SettingsService(databaseManager);
            categoryService = new CategoryService(databaseManager);
            themeManager = ThemeManager.getInstance(settingsService);
            backupService = new BackupService(databaseManager);
            startupManager = new StartupManager(settingsService);
            notificationService = new NotificationService(databaseManager, settingsService);
            appBlockerService = new AppBlockerService(databaseManager);

            // Initialize tracker
            activityTracker = new ActivityTracker(databaseManager, categoryService);
            activityTracker.setAppBlockerService(appBlockerService);
            activityTracker.setSettingsService(settingsService);
            
            // Register notification service as tracker listener
            activityTracker.addListener(notificationService);
            
            // Create main controller
            mainController = new MainController(
                activityTracker, 
                databaseManager, 
                settingsService, 
                categoryService,
                notificationService,
                themeManager,
                backupService,
                startupManager,
                appBlockerService
            );

            // Setup scene
            Scene scene = new Scene(mainController.getRoot(), 1200, 800);
            themeManager.registerScene(scene);

            // Configure stage
            primaryStage.setTitle("DeskWell - Digital Wellbeing");
            primaryStage.setMinWidth(900);
            primaryStage.setMinHeight(600);
            primaryStage.setScene(scene);

            // App/taskbar icon - register multiple sizes so Windows can pick
            // the sharpest one for each context (title bar, taskbar, alt-tab).
            for (String size : new String[]{"16", "32", "48", "128"}) {
                var iconUrl = getClass().getResource("/icons/icon-" + size + ".png");
                if (iconUrl != null) {
                    primaryStage.getIcons().add(new javafx.scene.image.Image(iconUrl.toExternalForm()));
                }
            }
            
            // Setup system tray
            setupSystemTray(primaryStage);
            
            // Setup close handler.
            //
            // This used to call handleApplicationClose() directly, which
            // stops the tracker, closes the DB and calls System.exit(0) -
            // i.e. clicking the window's X button always fully quit the app,
            // tracker and all. That contradicted the whole "minimize to tray
            // and keep tracking in the background" design (see the iconified
            // listener below) and is exactly why usage stopped being
            // recorded as soon as the window was closed. Now the X button
            // just hides the window to the tray, like minimizing; the app
            // (and tracking) only really shuts down via the tray icon's
            // "Exit DeskWell" menu item, which sets exitRequested first.
            primaryStage.setOnCloseRequest(event -> {
                if (!exitRequested && SystemTray.isSupported()) {
                    event.consume();
                    primaryStage.hide();
                    showTrayNotification("DeskWell is still running in the background");
                } else {
                    handleApplicationClose();
                }
            });

            primaryStage.show();
            logger.info("DeskWell UI displayed");

            // Start services
            activityTracker.start();
            notificationService.start();
            logger.info("All services started");

        } catch (Exception e) {
            logger.severe("Failed to start DeskWell: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void setupSystemTray(Stage primaryStage) {
        if (!SystemTray.isSupported()) {
            // No tray available on this platform - closing the window has to
            // mean really quitting, otherwise there would be no way to get
            // the app back or ever stop tracking.
            return;
        }

        Platform.setImplicitExit(false);

        try {
            SystemTray tray = SystemTray.getSystemTray();

            java.awt.Image image = java.awt.Toolkit.getDefaultToolkit()
                .createImage(getClass().getResource("/icons/tray-icon.png"));

            PopupMenu popup = new PopupMenu();

            MenuItem openItem = new MenuItem("Open DeskWell");
            openItem.addActionListener(e -> Platform.runLater(this::restoreWindow));

            MenuItem exitItem = new MenuItem("Exit DeskWell");
            exitItem.addActionListener(e -> {
                exitRequested = true;
                Platform.runLater(this::handleApplicationClose);
            });

            popup.add(openItem);
            popup.addSeparator();
            popup.add(exitItem);

            trayIcon = new TrayIcon(image, "DeskWell", popup);
            trayIcon.setImageAutoSize(true);
            // Double-click (and single-click on platforms that fire
            // ACTION_PERFORMED for it) restores the window, same as "Open".
            trayIcon.addActionListener(e -> Platform.runLater(this::restoreWindow));

            tray.add(trayIcon);

            // Added once here and left in place for the whole app lifetime -
            // the old code added the icon, showed a message, and immediately
            // removed it again inside showTrayNotification(), so there was
            // never actually a persistent tray icon for the user to click on
            // to get the window back.
            primaryStage.iconifiedProperty().addListener((obs, oldVal, newVal) -> {
                if (newVal) {
                    primaryStage.hide();
                    showTrayNotification("DeskWell is still running in the background");
                }
            });
        } catch (AWTException e) {
            logger.warning("Could not add tray icon: " + e.getMessage());
        } catch (Exception e) {
            logger.warning("Error setting up system tray: " + e.getMessage());
        }
    }

    private void restoreWindow() {
        if (primaryStage != null) {
            primaryStage.show();
            primaryStage.setIconified(false);
            primaryStage.toFront();
        }
    }

    private void showTrayNotification(String message) {
        if (trayIcon == null) return;
        try {
            trayIcon.displayMessage("DeskWell", message, TrayIcon.MessageType.INFO);
        } catch (Exception e) {
            logger.warning("Error showing tray notification: " + e.getMessage());
        }
    }

    private void handleApplicationClose() {
        logger.info("Shutting down DeskWell...");
        
        // Stop services in order
        if (notificationService != null) {
            notificationService.stop();
        }
        
        if (activityTracker != null) {
            activityTracker.stop();
        }
        
        if (appBlockerService != null) {
            appBlockerService.stopBlocking();
        }
        
        if (databaseManager != null) {
            databaseManager.close();
        }

        if (trayIcon != null && SystemTray.isSupported()) {
            SystemTray.getSystemTray().remove(trayIcon);
        }
        
        Platform.exit();
        System.exit(0);
    }

    @Override
    public void stop() {
        handleApplicationClose();
    }

    public static void main(String[] args) {
        // Set system properties for better performance
        System.setProperty("prism.lcdtext", "true");
        System.setProperty("prism.text", "t2k");
        System.setProperty("javafx.animation.fullspeed", "true");
        
        launch(args);
    }
}
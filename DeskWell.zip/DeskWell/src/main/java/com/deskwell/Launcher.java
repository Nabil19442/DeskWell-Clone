package com.deskwell;

/**
 * Separate entry point (does NOT extend javafx.application.Application).
 * Running the fat jar's Main-Class directly on an Application subclass
 * triggers "Error: JavaFX runtime components are missing" on some setups.
 * Going through this indirection avoids that.
 */
public class Launcher {
    public static void main(String[] args) {
        DeskWellApp.main(args);
    }
}

package com.deskwell.controller;

import com.deskwell.database.DatabaseManager;
import com.deskwell.service.*;
import com.deskwell.tracker.ActivityTracker;
import com.deskwell.view.*;
import javafx.animation.*;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.util.Duration;

public class MainController {
    private final ActivityTracker activityTracker;
    private final DatabaseManager databaseManager;
    private final SettingsService settingsService;
    private final CategoryService categoryService;
    private final NotificationService notificationService;
    private final ThemeManager themeManager;
    private final BackupService backupService;
    private final StartupManager startupManager;
    private final AppBlockerService appBlockerService;
    
    private ChartService chartService;
    private ReportService reportService;
    private FocusModeService focusModeService;
    
    private BorderPane root;
    private VBox sidebar;
    private StackPane contentArea;
    private String currentView = "dashboard";
    
    private DashboardView dashboardView;
    private FocusModeView focusModeView;

    public MainController(ActivityTracker activityTracker, DatabaseManager databaseManager,
                         SettingsService settingsService, CategoryService categoryService,
                         NotificationService notificationService, ThemeManager themeManager,
                         BackupService backupService, StartupManager startupManager,
                         AppBlockerService appBlockerService) {
        this.activityTracker = activityTracker;
        this.databaseManager = databaseManager;
        this.settingsService = settingsService;
        this.categoryService = categoryService;
        this.notificationService = notificationService;
        this.themeManager = themeManager;
        this.backupService = backupService;
        this.startupManager = startupManager;
        this.appBlockerService = appBlockerService;
        
        // Initialize services
        this.chartService = new ChartService(databaseManager);
        this.reportService = new ReportService(databaseManager);
        this.focusModeService = new FocusModeService(databaseManager);
        
        buildUI();
    }

    private void buildUI() {
        root = new BorderPane();
        
        // Create sidebar
        sidebar = createSidebar();
        root.setLeft(sidebar);
        
        // Create content area with animation support
        contentArea = new StackPane();
        contentArea.setPadding(new Insets(20));
        root.setCenter(contentArea);
        
        // Show default view with animation
        showDashboard();
    }

    private VBox createSidebar() {
        VBox sidebar = new VBox(10);
        sidebar.getStyleClass().add("sidebar");
        sidebar.setPrefWidth(250);
        sidebar.setPadding(new Insets(20, 10, 20, 10));
        
        // App title with icon
        Label appTitle = new Label("🕐 DeskWell");
        appTitle.getStyleClass().add("app-title");
        
        // Navigation buttons
        Button dashboardBtn = createNavButton("📊 Dashboard", "dashboard");
        Button reportsBtn = createNavButton("📈 Reports", "reports");
        Button focusBtn = createNavButton("🎯 Focus Mode", "focus");
        Button goalsBtn = createNavButton("🎯 Goals", "goals");
        Button settingsBtn = createNavButton("⚙ Settings", "settings");
        
        // Active tracking indicator
        HBox statusBox = new HBox(10);
        statusBox.setPadding(new Insets(10));
        statusBox.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        
        Circle statusDot = new Circle(5);
        statusDot.setFill(javafx.scene.paint.Color.valueOf("#4CAF50"));
        
        Label statusLabel = new Label("Tracking Active");
        statusLabel.getStyleClass().add("status-label");
        
        statusBox.getChildren().addAll(statusDot, statusLabel);
        
        sidebar.getChildren().addAll(
            appTitle,
            new Separator(),
            dashboardBtn,
            reportsBtn,
            focusBtn,
            goalsBtn,
            new Separator(),
            settingsBtn,
            statusBox
        );
        
        return sidebar;
    }

    private Button createNavButton(String text, String viewName) {
        Button button = new Button(text);
        button.getStyleClass().add("nav-button");
        button.setMaxWidth(Double.MAX_VALUE);
        button.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        
        button.setOnAction(e -> navigateTo(viewName));
        
        return button;
    }

    private void navigateTo(String viewName) {
        if (currentView.equals(viewName)) return;
        
        currentView = viewName;
        
        // Clear current view
        contentArea.getChildren().clear();
        
        // Show new view with fade transition
        switch (viewName) {
            case "dashboard" -> showDashboard();
            case "reports" -> showReports();
            case "focus" -> showFocusMode();
            case "goals" -> showGoals();
            case "settings" -> showSettings();
        }
        
        // Animate transition
        if (!contentArea.getChildren().isEmpty()) {
            FadeTransition ft = new FadeTransition(Duration.millis(300), 
                contentArea.getChildren().get(0));
            ft.setFromValue(0);
            ft.setToValue(1);
            ft.play();
        }
    }

    private void showDashboard() {
        if (dashboardView == null) {
            dashboardView = new DashboardView(chartService, activityTracker);
        }
        contentArea.getChildren().clear();
        contentArea.getChildren().add(dashboardView.getView());
    }

    private void showReports() {
        ReportsView reportsView = new ReportsView(reportService);
        contentArea.getChildren().clear();
        contentArea.getChildren().add(reportsView.getView());
    }

    private void showFocusMode() {
        if (focusModeView == null) {
            focusModeView = new FocusModeView(focusModeService, appBlockerService);
        }
        contentArea.getChildren().clear();
        contentArea.getChildren().add(focusModeView.getView());
    }

    private void showGoals() {
        GoalsView goalsView = new GoalsView(databaseManager);
        contentArea.getChildren().clear();
        contentArea.getChildren().add(goalsView.getView());
    }

    private void showSettings() {
        SettingsView settingsView = new SettingsView(
            settingsService, databaseManager, themeManager, 
            backupService, startupManager, activityTracker
        );
        contentArea.getChildren().clear();
        contentArea.getChildren().add(settingsView.getView());
    }

    public BorderPane getRoot() {
        return root;
    }
    
    // Helper class for status indicator
    private static class Circle extends javafx.scene.shape.Circle {
        public Circle(double radius) {
            super(radius);
        }
    }
}
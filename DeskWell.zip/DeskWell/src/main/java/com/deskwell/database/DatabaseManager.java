package com.deskwell.database;

import java.sql.*;
import java.time.LocalDate;

public class DatabaseManager{
    private static DatabaseManager instance;
    private Connection connection;
    private static final String DB_URL = buildDbUrl();

    private static String buildDbUrl(){
        java.io.File dbFile = new java.io.File(com.deskwell.util.AppPaths.getDataDir(), "deskwell.db");
        return "jdbc:sqlite:" + dbFile.getAbsolutePath();
    }

    private DatabaseManager(){}

    public static synchronized DatabaseManager getInstance(){
        if (instance == null) {
            instance = new DatabaseManager();
        }
        return instance;
    }

    public void initialize(){
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(DB_URL);
            connection.setAutoCommit(true);
            
            // Enable WAL mode for better concurrent access
            try (Statement stmt = connection.createStatement()) {
                stmt.execute("PRAGMA journal_mode=WAL");
                stmt.execute("PRAGMA foreign_keys=ON");
            }
            
            createTables();
            migrateSchema();
            insertDefaultCategories();
            insertDefaultSettings();
            
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize database", e);
        }
    }

    /**
     * Adds columns that didn't exist in earlier releases of the schema.
     * SQLite has no "ADD COLUMN IF NOT EXISTS", so we just try the ALTER
     * and swallow the "duplicate column" error on databases that already
     * have it (every DB created by createTables() above already includes
     * it, so this only matters for people upgrading from an older DB file).
     */
    private void migrateSchema() {
        try (Statement stmt = connection.createStatement()) {
            stmt.execute("ALTER TABLE categories ADD COLUMN productivity_weight REAL DEFAULT 0.0");
        } catch (SQLException e) {
            // Column already exists - nothing to do.
        }
        purgeStaleIdleUsageRows();
    }

    /**
     * One-time cleanup for databases written by earlier builds, which used
     * to insert a synthetic "Idle" application into usage_tracking every
     * time the user went away from keyboard (see
     * ActivityTracker.IDLE_APP_NAME - that insert has since been removed).
     * Those rows fell into the "Other" category (nothing in
     * CategoryService's keyword list matches "Idle") and got summed
     * alongside real app usage by every reader of usage_tracking - Category
     * Breakdown, Hourly Activity, Most Used Apps, Reports, CSV/PDF exports
     * - inflating all of their totals above the dashboard's "Screen Time
     * Today" figure (which never included idle time to begin with), so the
     * two numbers never agreed. Deleting any such rows (and the "Idle"
     * application row itself) here, on every startup, makes already-tracked
     * days - including "today" - self-heal immediately instead of staying
     * wrong until a new day rolls over. Both statements are no-ops (0 rows
     * affected) on a database that never had this problem or has already
     * been cleaned up.
     */
    private void purgeStaleIdleUsageRows() {
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(
                "DELETE FROM usage_tracking WHERE application_id IN " +
                "(SELECT id FROM applications WHERE name = 'Idle')");
            stmt.execute("DELETE FROM applications WHERE name = 'Idle'");
        } catch (SQLException e) {
            // Best-effort cleanup; leave the data as-is if this fails rather
            // than blocking startup over it.
        }
    }

    private void createTables() throws SQLException {
        String[] tables = {
            // Users table
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """,
            
            // Sessions table
            """
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER DEFAULT 1,
                start_time TIMESTAMP NOT NULL,
                end_time TIMESTAMP,
                duration_seconds INTEGER DEFAULT 0,
                is_active BOOLEAN DEFAULT 1,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
            """,
            
            // Applications table
            """
            CREATE TABLE IF NOT EXISTS applications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                executable_path TEXT,
                category_id INTEGER DEFAULT 7,
                FOREIGN KEY (category_id) REFERENCES categories(id)
            )
            """,
            
            // Usage tracking table
            """
            CREATE TABLE IF NOT EXISTS usage_tracking (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                application_id INTEGER NOT NULL,
                window_title TEXT,
                start_time TIMESTAMP NOT NULL,
                end_time TIMESTAMP,
                duration_seconds INTEGER DEFAULT 0,
                FOREIGN KEY (session_id) REFERENCES sessions(id),
                FOREIGN KEY (application_id) REFERENCES applications(id)
            )
            """,
            
            // Daily stats table
            """
            CREATE TABLE IF NOT EXISTS daily_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date DATE NOT NULL UNIQUE,
                total_screen_time INTEGER DEFAULT 0,
                productive_time INTEGER DEFAULT 0,
                idle_time INTEGER DEFAULT 0,
                session_count INTEGER DEFAULT 0,
                productivity_score REAL DEFAULT 0.0
            )
            """,
            
            // Categories table
            """
            CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                color TEXT DEFAULT '#607D8B',
                is_default BOOLEAN DEFAULT 1,
                icon TEXT,
                productivity_weight REAL DEFAULT 0.0
            )
            """,
            
            // Goals table
            """
            CREATE TABLE IF NOT EXISTS goals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                target_value INTEGER NOT NULL,
                current_value INTEGER DEFAULT 0,
                start_date DATE NOT NULL,
                end_date DATE,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """,
            
            // Focus sessions table
            """
            CREATE TABLE IF NOT EXISTS focus_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                start_time TIMESTAMP NOT NULL,
                end_time TIMESTAMP,
                duration_minutes INTEGER NOT NULL,
                break_minutes INTEGER DEFAULT 5,
                pomodoro_mode BOOLEAN DEFAULT 0,
                completed BOOLEAN DEFAULT 0,
                interruptions INTEGER DEFAULT 0
            )
            """,
            
            // Settings table
            """
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """,
            
            // Blocked apps for focus mode
            """
            CREATE TABLE IF NOT EXISTS blocked_apps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                application_id INTEGER NOT NULL,
                focus_session_id INTEGER,
                is_permanent BOOLEAN DEFAULT 0,
                FOREIGN KEY (application_id) REFERENCES applications(id),
                FOREIGN KEY (focus_session_id) REFERENCES focus_sessions(id)
            )
            """
        };

        try (Statement stmt = connection.createStatement()) {
            for (String table : tables) {
                stmt.execute(table);
            }
        }
    }

    // Productivity weight is how much of an app's tracked time counts toward
    // the productivity score/productive_time. Per product requirement, only
    // actual coding/development work should ever count as "productive" -
    // 1.0 = counts fully (coding / compiler / IDE tools, category
    // "Development"). Every other category - including "Productivity"
    // (office suites, design tools, AI assistants), Browser, Entertainment,
    // Communication (also covers social media/messaging), Gaming and Other -
    // is 0.0: those apps still get grouped into their own category for the
    // breakdown chart/reports, they just don't count toward the productivity
    // score. Only "Development" should ever carry a non-zero weight here.
    private void insertDefaultCategories() throws SQLException {
        String[][] defaults = {
            {"Productivity", "#4CAF50", "1", "0.0"},
            {"Development", "#2196F3", "1", "1.0"},
            {"Browser", "#FF9800", "1", "0.0"},
            {"Entertainment", "#F44336", "1", "0.0"},
            {"Communication", "#9C27B0", "1", "0.0"},
            {"Gaming", "#795548", "1", "0.0"},
            {"Other", "#607D8B", "1", "0.0"}
        };

        String insertSql = "INSERT OR IGNORE INTO categories (name, color, is_default, productivity_weight) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(insertSql)) {
            for (String[] cat : defaults) {
                pstmt.setString(1, cat[0]);
                pstmt.setString(2, cat[1]);
                pstmt.setString(3, cat[2]);
                pstmt.setDouble(4, Double.parseDouble(cat[3]));
                pstmt.executeUpdate();
            }
        }

        // INSERT OR IGNORE above only sets productivity_weight for brand new
        // rows. Databases created before this column existed (or before this
        // weighting scheme was introduced) already have these category rows,
        // so their weight would otherwise stay stuck at the column's default
        // of 0.0 forever. Re-applying the correct weight for the known
        // default categories on every startup keeps existing installs in
        // sync without touching any custom categories a user may have added.
        String updateSql = "UPDATE categories SET productivity_weight = ? WHERE name = ? AND is_default = 1";
        try (PreparedStatement pstmt = connection.prepareStatement(updateSql)) {
            for (String[] cat : defaults) {
                pstmt.setDouble(1, Double.parseDouble(cat[3]));
                pstmt.setString(2, cat[0]);
                pstmt.executeUpdate();
            }
        }
    }

    private void insertDefaultSettings() throws SQLException {
        String[][] defaults = {
            {"theme", "light"},
            {"startup_with_windows", "false"},
            {"break_reminder_enabled", "true"},
            {"break_interval_minutes", "60"},
            {"screen_time_warning_enabled", "true"},
            {"screen_time_warning_threshold", "360"},
            {"notifications_enabled", "true"}
        };

        String sql = "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            for (String[] setting : defaults) {
                pstmt.setString(1, setting[0]);
                pstmt.setString(2, setting[1]);
                pstmt.executeUpdate();
            }
        }
        
        // Ensure default user exists
        String userSql = "INSERT OR IGNORE INTO users (id, username) VALUES (1, 'default')";
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(userSql);
        }
    }

    public Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(DB_URL);
                // PRAGMAs are per-connection, not persisted in the DB file,
                // so a reopened connection needs these re-applied - otherwise
                // a reconnect after an error silently loses WAL mode /
                // foreign key enforcement for the rest of the app's life.
                try (Statement stmt = connection.createStatement()) {
                    stmt.execute("PRAGMA journal_mode=WAL");
                    stmt.execute("PRAGMA foreign_keys=ON");
                }
            }
        }catch (SQLException e){
            throw new RuntimeException("Failed to get database connection", e);
        }
        return connection;
    }

    /**
     * Forces SQLite to flush the WAL file into the main deskwell.db file.
     * In WAL mode (enabled in initialize()), committed writes normally live
     * in a separate deskwell.db-wal file and are only folded back into the
     * main file when SQLite decides to checkpoint automatically. That's
     * invisible to the app itself (every connection transparently reads
     * WAL + main file together), but if anything outside the app's own
     * connection ever reads deskwell.db directly - a backup tool, another
     * process, or the file simply being copied - it can appear to be
     * missing recent days of data until a checkpoint happens. Called
     * periodically and on shutdown so the on-disk file is always current.
     */
    public void checkpoint() {
        try (Statement stmt = getConnection().createStatement()) {
            stmt.execute("PRAGMA wal_checkpoint(FULL)");
        } catch (SQLException e) {
            // Non-fatal: the data is still safe in the WAL file either way.
        }
    }

    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                // Flush WAL into the main file before closing so a fresh
                // connection next launch (or an external tool) sees
                // everything that was ever committed.
                try (Statement stmt = connection.createStatement()) {
                    stmt.execute("PRAGMA wal_checkpoint(FULL)");
                } catch (SQLException ignored) {
                }
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
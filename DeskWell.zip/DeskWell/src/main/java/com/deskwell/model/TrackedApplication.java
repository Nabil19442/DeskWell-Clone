package com.deskwell.model;

import java.util.Objects;

public class TrackedApplication {
    private final String processName;
    private final String windowTitle;
    private final String className;
    private final String executablePath;

    public TrackedApplication(String processName, String windowTitle, String className, String executablePath) {
        this.processName = processName;
        this.windowTitle = windowTitle;
        this.className = className;
        this.executablePath = executablePath;
    }

    // Backward compatible constructor
    public TrackedApplication(String processName, String windowTitle, String className) {
        this(processName, windowTitle, className, "");
    }

    public String getProcessName() {
        return processName;
    }

    public String getWindowTitle() {
        return windowTitle;
    }

    public String getClassName() {
        return className;
    }

    public String getExecutablePath() {
        return executablePath;
    }

    public String getDisplayName() {
        if (windowTitle != null && !windowTitle.isEmpty() && !windowTitle.equals(processName)) {
            return windowTitle;
        }
        return processName;
    }

    // Identity is based on the process only, NOT the window title.
    //
    // ActivityTracker.pollActiveWindow() uses this equals() to decide
    // whether the foreground app "changed" (close the open usage_tracking
    // row and start a new one) or is "the same app" (just keep accumulating
    // onto the currently open row). Window titles change constantly during
    // completely ordinary use of a single app - a browser's title changes
    // with every page/tab, an IDE's with every file you switch to, a
    // terminal's with the current directory or running command. Including
    // windowTitle here previously meant every such title change was treated
    // as a full application switch: the in-progress usage_tracking row was
    // closed and a brand-new one opened on essentially every poll for apps
    // like this, fragmenting a single continuous session into dozens or
    // hundreds of tiny rows and massively inflating the "session count"
    // shown for that app in Reports (COUNT(*) over usage_tracking rows -
    // see ReportService.getAppUsage()), even though the user never actually
    // left the app.
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TrackedApplication that = (TrackedApplication) o;
        return Objects.equals(processName, that.processName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(processName);
    }

    @Override
    public String toString() {
        return "TrackedApplication{" +
               "processName='" + processName + '\'' +
               ", windowTitle='" + windowTitle + '\'' +
               '}';
    }
}
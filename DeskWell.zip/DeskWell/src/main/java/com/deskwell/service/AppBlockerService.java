package com.deskwell.service;

import com.deskwell.database.DatabaseManager;

import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class AppBlockerService {
    private static final Logger logger = Logger.getLogger(AppBlockerService.class.getName());
    private final DatabaseManager databaseManager;
    private final ScheduledExecutorService scheduler;
    private final Set<String> blockedApps = ConcurrentHashMap.newKeySet();
    private final Set<String> permanentlyBlockedApps = ConcurrentHashMap.newKeySet();
    private boolean isBlocking = false;
    private List<BlockListener> listeners = new CopyOnWriteArrayList<>();

    public AppBlockerService(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
        loadBlockedApps();
    }

    private void loadBlockedApps() {
        String sql = """
            SELECT a.name, ba.is_permanent
            FROM blocked_apps ba
            JOIN applications a ON ba.application_id = a.id
            WHERE ba.is_permanent = 1
            """;
        
        try (Statement stmt = databaseManager.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                String appName = rs.getString("name");
                if (rs.getBoolean("is_permanent")) {
                    permanentlyBlockedApps.add(appName);
                }
            }
        } catch (SQLException e) {
            logger.warning("Error loading blocked apps: " + e.getMessage());
        }
    }

    public void startBlocking(List<String> appsToBlock) {
        if (isBlocking) return;
        
        isBlocking = true;
        blockedApps.clear();
        blockedApps.addAll(appsToBlock);
        blockedApps.addAll(permanentlyBlockedApps);
        
        notifyListeners("blocking_started");
        logger.info("App blocking started for " + blockedApps.size() + " apps");
    }

    public void stopBlocking() {
        if (!isBlocking) return;
        
        isBlocking = false;
        blockedApps.clear();
        notifyListeners("blocking_stopped");
        logger.info("App blocking stopped");
    }

    public boolean isAppBlocked(String appName) {
        if (!isBlocking) return false;
        return blockedApps.contains(appName) || 
               blockedApps.stream().anyMatch(blocked -> 
                   appName.toLowerCase().contains(blocked.toLowerCase()));
    }

    public void addPermanentBlock(String appName) {
        permanentlyBlockedApps.add(appName);
        saveBlockedApp(appName, true);
        
        if (isBlocking) {
            blockedApps.add(appName);
        }
    }

    public void removePermanentBlock(String appName) {
        permanentlyBlockedApps.remove(appName);
        blockedApps.remove(appName);
        removeBlockedApp(appName);
    }

    public void addTemporaryBlock(String appName) {
        if (isBlocking) {
            blockedApps.add(appName);
        }
    }

    public void removeTemporaryBlock(String appName) {
        blockedApps.remove(appName);
    }

    private void saveBlockedApp(String appName, boolean isPermanent) {
        // Get or create application
        int appId = getOrCreateApp(appName);
        
        String sql = """
            INSERT OR REPLACE INTO blocked_apps (application_id, is_permanent)
            VALUES (?, ?)
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, appId);
            pstmt.setBoolean(2, isPermanent);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            logger.warning("Error saving blocked app: " + e.getMessage());
        }
    }

    private void removeBlockedApp(String appName) {
        int appId = getAppId(appName);
        if (appId == -1) return;
        
        String sql = "DELETE FROM blocked_apps WHERE application_id = ?";
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, appId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            logger.warning("Error removing blocked app: " + e.getMessage());
        }
    }

    private int getOrCreateApp(String appName) {
        String findSql = "SELECT id FROM applications WHERE name = ?";
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(findSql)) {
            pstmt.setString(1, appName);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            logger.warning("Error finding app: " + e.getMessage());
        }
        
        String insertSql = "INSERT INTO applications (name) VALUES (?)";
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(insertSql)) {
            pstmt.setString(1, appName);
            pstmt.executeUpdate();
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            logger.warning("Error creating app: " + e.getMessage());
        }
        
        return -1;
    }

    private int getAppId(String appName) {
        String sql = "SELECT id FROM applications WHERE name = ?";
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, appName);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            logger.warning("Error getting app id: " + e.getMessage());
        }
        return -1;
    }

    public Set<String> getBlockedApps() {
        return new HashSet<>(blockedApps);
    }

    public Set<String> getPermanentlyBlockedApps() {
        return new HashSet<>(permanentlyBlockedApps);
    }

    public boolean isBlocking() {
        return isBlocking;
    }

    // Returns apps DeskWell's own ActivityTracker has recorded as the
    // foreground window in the last 7 days. This is tracked *history*, not
    // a live list of what's installed/running right now - kept around as a
    // fallback source (see getAvailableAppsForBlocking()) so previously
    // seen apps stay selectable even when they're not currently running.
    public List<String> getAvailableApps() {
        List<String> apps = new ArrayList<>();
        
        String sql = """
            SELECT DISTINCT a.name 
            FROM applications a
            JOIN usage_tracking ut ON a.id = ut.application_id
            WHERE date(ut.start_time) >= date('now', '-7 days')
            ORDER BY a.name
            """;
        
        try (Statement stmt = databaseManager.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                apps.add(rs.getString("name"));
            }
        } catch (SQLException e) {
            logger.warning("Error getting available apps: " + e.getMessage());
        }
        
        return apps;
    }

    /**
     * Enumerates the names of processes currently running on the system,
     * using ProcessHandle.allProcesses() (works on any OS, no native/JNA
     * dependency needed). This is the actual fix for the "Block Apps"
     * dropdown only showing java.exe: getAvailableApps() above only ever
     * returns apps DeskWell's own tracker has already seen in the
     * foreground, so during a short dev/test session the only entry was
     * DeskWell's own window (java.exe/javaw.exe). This method instead looks
     * at what's genuinely running right now, the same way Task Manager
     * would, regardless of whether DeskWell has ever tracked it.
     */
    public List<String> getRunningProcesses() {
        long ownPid = ProcessHandle.current().pid();
        
        return ProcessHandle.allProcesses()
            .filter(p -> p.pid() != ownPid)
            .map(ProcessHandle::info)
            .map(ProcessHandle.Info::command)
            .filter(Optional::isPresent)
            .map(Optional::get)
            .map(this::toProcessName)
            .filter(name -> name != null && !name.isBlank())
            .filter(name -> !isOwnProcessName(name))
            .distinct()
            .sorted(String.CASE_INSENSITIVE_ORDER)
            .collect(Collectors.toList());
    }

    // A process's "command" from ProcessHandle.info() is typically a full
    // path (e.g. C:\...\java.exe) - reduce it to just the executable's file
    // name for display/matching, the same shape isAppBlocked() compares
    // against.
    private String toProcessName(String command) {
        if (command == null) return null;
        int lastSlash = Math.max(command.lastIndexOf('\\'), command.lastIndexOf('/'));
        return lastSlash >= 0 ? command.substring(lastSlash + 1) : command;
    }

    // DeskWell itself runs under java.exe/javaw.exe (or "java"/"javaw" on
    // non-Windows), so those get excluded even beyond the PID filter above
    // in case multiple JVMs happen to be running.
    private boolean isOwnProcessName(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        return lower.equals("java.exe") || lower.equals("javaw.exe")
            || lower.equals("java") || lower.equals("javaw");
    }

    /**
     * Combined source for the Focus Mode "Block Apps" dropdown: currently
     * running system processes (live, primary source) plus previously
     * tracked app names (getAvailableApps(), kept as a fallback so apps
     * seen before but not running right now - e.g. something the user
     * closed - are still selectable), deduplicated and sorted.
     */
    public List<String> getAvailableAppsForBlocking() {
        LinkedHashSet<String> combined = new LinkedHashSet<>();
        combined.addAll(getRunningProcesses());
        for (String tracked : getAvailableApps()) {
            if (!isOwnProcessName(tracked)) {
                combined.add(tracked);
            }
        }
        return combined.stream()
            .sorted(String.CASE_INSENSITIVE_ORDER)
            .collect(Collectors.toList());
    }

    // Listener management
    public void addListener(BlockListener listener) {
        listeners.add(listener);
    }

    public void removeListener(BlockListener listener) {
        listeners.remove(listener);
    }

    private void notifyListeners(String event) {
        for (BlockListener listener : listeners) {
            try {
                listener.onBlockEvent(event, this);
            } catch (Exception e) {
                logger.warning("Error notifying listener: " + e.getMessage());
            }
        }
    }

    public interface BlockListener {
        void onBlockEvent(String event, AppBlockerService service);
    }
}
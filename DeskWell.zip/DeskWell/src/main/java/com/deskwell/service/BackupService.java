package com.deskwell.service;

import com.deskwell.database.DatabaseManager;
import com.deskwell.util.AppPaths;

import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class BackupService {
    private static final Logger logger = Logger.getLogger(BackupService.class.getName());
    private final DatabaseManager databaseManager;
    private static final DateTimeFormatter TIMESTAMP_FORMAT = 
        DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");

    public BackupService(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
    }

    public File createBackup(String destinationPath) throws IOException {
        String timestamp = LocalDateTime.now().format(TIMESTAMP_FORMAT);
        String backupFileName = String.format("deskwell_backup_%s.zip", timestamp);
        File backupFile = new File(destinationPath, backupFileName);
        
        // First, export database to temporary SQL file
        File tempSqlFile = exportDatabaseToSql();
        
        try {
            // Create ZIP archive
            try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(backupFile));
                 FileInputStream fis = new FileInputStream(tempSqlFile)) {
                
                ZipEntry entry = new ZipEntry("deskwell_backup.sql");
                zos.putNextEntry(entry);
                
                byte[] buffer = new byte[8192];
                int length;
                while ((length = fis.read(buffer)) > 0) {
                    zos.write(buffer, 0, length);
                }
                
                zos.closeEntry();
            }
            
            // Also backup settings file if exists
            File settingsFile = new File(AppPaths.getDataDir(), "deskwell_settings.json");
            if (settingsFile.exists()) {
                try (ZipOutputStream zos = new ZipOutputStream(
                        new FileOutputStream(backupFile, true))) {
                    ZipEntry entry = new ZipEntry("settings.json");
                    zos.putNextEntry(entry);
                    Files.copy(settingsFile.toPath(), zos);
                    zos.closeEntry();
                }
            }
            
            logger.info("Backup created successfully: " + backupFile.getAbsolutePath());
            
        } finally {
            // Clean up temp file
            tempSqlFile.delete();
        }
        
        return backupFile;
    }

    public void restoreBackup(File backupFile) throws IOException, SQLException {
        if (!backupFile.exists()) {
            throw new FileNotFoundException("Backup file not found: " + backupFile.getAbsolutePath());
        }
        
        File tempDir = new File(AppPaths.getDataDir(), "temp_restore");
        tempDir.mkdirs();
        
        try {
            // Extract ZIP
            try (java.util.zip.ZipFile zipFile = new java.util.zip.ZipFile(backupFile)) {
                java.util.Enumeration<? extends ZipEntry> entries = zipFile.entries();
                
                while (entries.hasMoreElements()) {
                    ZipEntry entry = entries.nextElement();
                    File extractedFile = new File(tempDir, entry.getName());
                    
                    if (!entry.isDirectory()) {
                        try (InputStream is = zipFile.getInputStream(entry);
                             FileOutputStream fos = new FileOutputStream(extractedFile)) {
                            byte[] buffer = new byte[8192];
                            int length;
                            while ((length = is.read(buffer)) > 0) {
                                fos.write(buffer, 0, length);
                            }
                        }
                    }
                }
            }
            
            // Restore database from SQL
            File sqlFile = new File(tempDir, "deskwell_backup.sql");
            if (sqlFile.exists()) {
                restoreDatabaseFromSql(sqlFile);
            }
            
            // Restore settings
            File settingsFile = new File(tempDir, "settings.json");
            if (settingsFile.exists()) {
                Files.copy(settingsFile.toPath(), 
                    new File(AppPaths.getDataDir(), "deskwell_settings.json").toPath(),
                    StandardCopyOption.REPLACE_EXISTING);
            }
            
            logger.info("Backup restored successfully");
            
        } finally {
            // Clean up temp directory
            deleteDirectory(tempDir);
        }
    }

    private File exportDatabaseToSql() throws IOException {
        File tempFile = File.createTempFile("deskwell_export_", ".sql");

        // IMPORTANT: databaseManager.getConnection() returns the single shared
        // Connection used by the whole app (tracker thread, UI, every other
        // service). It must NEVER be put inside a try-with-resources here,
        // because that calls conn.close() when this method returns - which
        // silently kills the shared connection for the entire application.
        // That was the root cause of "the database stops working": simply
        // opening the Settings screen called getBackupSizeFormatted(), which
        // closed the shared connection, so every DB call afterwards
        // (tracking, dashboard, reports...) started failing until
        // DatabaseManager transparently reopened it on the next call -
        // dropping data and causing errors in between.
        Connection conn = databaseManager.getConnection();
        try (FileWriter writer = new FileWriter(tempFile)) {
            
            writer.write("-- DeskWell Database Backup\n");
            writer.write("-- Created: " + LocalDateTime.now() + "\n\n");
            
            // Export schema
            writer.write("-- Schema\n");
            String schemaSql = "SELECT sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(schemaSql)) {
                while (rs.next()) {
                    String sql = rs.getString("sql");
                    if (sql != null) {
                        writer.write(sql + ";\n");
                    }
                }
            }
            writer.write("\n");
            
            // Export data
            String[] tables = {"users", "sessions", "applications", "usage_tracking", 
                              "daily_stats", "goals", "categories", "focus_sessions", 
                              "settings", "blocked_apps"};
            
            for (String table : tables) {
                writer.write("-- Data for " + table + "\n");
                
                String selectSql = "SELECT * FROM " + table;
                try (Statement stmt = conn.createStatement();
                     ResultSet rs = stmt.executeQuery(selectSql)) {
                    
                    ResultSetMetaData meta = rs.getMetaData();
                    int columnCount = meta.getColumnCount();
                    
                    while (rs.next()) {
                        StringBuilder insert = new StringBuilder("INSERT INTO " + table + " VALUES (");
                        
                        for (int i = 1; i <= columnCount; i++) {
                            if (i > 1) insert.append(", ");
                            
                            String value = rs.getString(i);
                            if (value == null) {
                                insert.append("NULL");
                            } else {
                                // Escape single quotes
                                String escaped = value.replace("'", "''");
                                insert.append("'").append(escaped).append("'");
                            }
                        }
                        
                        insert.append(");\n");
                        writer.write(insert.toString());
                    }
                }
                
                writer.write("\n");
            }
            
        } catch (SQLException e) {
            throw new IOException("Failed to export database", e);
        }
        
        return tempFile;
    }

    private void restoreDatabaseFromSql(File sqlFile) throws IOException, SQLException {
        String sql = new String(Files.readAllBytes(sqlFile.toPath()));

        // See the comment in exportDatabaseToSql(): do not try-with-resources
        // the shared Connection itself, only the Statement created from it.
        Connection conn = databaseManager.getConnection();
        try (Statement stmt = conn.createStatement()) {
            
            // Split by semicolons and execute each statement
            String[] statements = sql.split(";");
            
            conn.setAutoCommit(false);
            
            for (String statement : statements) {
                statement = statement.trim();
                if (!statement.isEmpty() && !statement.startsWith("--")) {
                    try {
                        stmt.execute(statement);
                    } catch (SQLException e) {
                        logger.warning("Error executing restore statement: " + e.getMessage());
                        // Continue with other statements
                    }
                }
            }
            
            conn.commit();
            conn.setAutoCommit(true);
        }
    }

    private void deleteDirectory(File dir) {
        if (dir.isDirectory()) {
            File[] files = dir.listFiles();
            if (files != null) {
                for (File file : files) {
                    deleteDirectory(file);
                }
            }
        }
        dir.delete();
    }

    public long getBackupSize() {
        // Same rule as above: never close the shared Connection here. This
        // one is especially dangerous because it's called every time the
        // Settings screen is opened (to show the DB size label), so the old
        // code was closing the app's only DB connection on every visit to
        // Settings.
        Connection conn = databaseManager.getConnection();
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT page_count * page_size as size FROM pragma_page_count(), pragma_page_size()")) {
            
            if (rs.next()) {
                return rs.getLong("size");
            }
        } catch (SQLException e) {
            logger.warning("Error getting database size: " + e.getMessage());
        }
        return 0;
    }

    public String getBackupSizeFormatted() {
        long size = getBackupSize();
        if (size < 1024) return size + " B";
        if (size < 1024 * 1024) return String.format("%.1f KB", size / 1024.0);
        return String.format("%.1f MB", size / (1024.0 * 1024.0));
    }
}
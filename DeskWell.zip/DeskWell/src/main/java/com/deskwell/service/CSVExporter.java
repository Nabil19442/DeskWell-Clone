package com.deskwell.service;

import com.deskwell.service.ReportService.*;
import com.deskwell.util.AppPaths;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

public class CSVExporter {
    private static final Logger logger = Logger.getLogger(CSVExporter.class.getName());
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd");

    public static File exportDailyReport(DailyReport report) throws IOException {
        String fileName = String.format("deskwell_daily_report_%s.csv", 
            report.date.format(DATE_FORMAT));
        File file = new File(AppPaths.getExportDir(), fileName);
        
        try (FileWriter writer = new FileWriter(file)) {
            // Header
            writer.write("DeskWell Daily Report\n");
            writer.write("Date:," + report.date.toString() + "\n\n");
            
            // Summary
            writer.write("SUMMARY\n");
            writer.write("Total Screen Time (hours)," + String.format("%.2f", report.totalScreenTime / 3600.0) + "\n");
            writer.write("Productive Time (hours)," + String.format("%.2f", report.productiveTime / 3600.0) + "\n");
            writer.write("Idle Time (hours)," + String.format("%.2f", report.idleTime / 3600.0) + "\n");
            writer.write("Number of Sessions," + report.sessionCount + "\n");
            writer.write("Productivity Score," + String.format("%.1f%%", report.productivityScore) + "\n\n");
            
            // App Usage
            writer.write("APPLICATION USAGE\n");
            writer.write("Application,Category,Sessions,Time (hours)\n");
            for (AppUsageInfo app : report.appUsage) {
                writer.write(String.format("%s,%s,%d,%.2f\n",
                    escapeCsv(app.name),
                    app.category,
                    app.sessionCount,
                    app.getHours()));
            }
            writer.write("\n");
            
            // Hourly Breakdown
            writer.write("HOURLY BREAKDOWN\n");
            writer.write("Hour,Active Time (minutes)\n");
            for (Map.Entry<Integer, Long> entry : report.hourlyBreakdown.entrySet()) {
                writer.write(String.format("%02d:00,%d\n",
                    entry.getKey(),
                    entry.getValue() / 60));
            }
            writer.write("\n");
            
            // Category Breakdown
            writer.write("CATEGORY BREAKDOWN\n");
            writer.write("Category,Time (hours)\n");
            for (Map.Entry<String, Long> entry : report.categoryBreakdown.entrySet()) {
                writer.write(String.format("%s,%.2f\n",
                    entry.getKey(),
                    entry.getValue() / 3600.0));
            }
        }
        
        return file;
    }

    public static File exportWeeklyReport(WeeklyReport report) throws IOException {
        String fileName = String.format("deskwell_weekly_report_%s.csv",
            report.weekStart.format(DATE_FORMAT));
        File file = new File(AppPaths.getExportDir(), fileName);
        
        try (FileWriter writer = new FileWriter(file)) {
            writer.write("DeskWell Weekly Report\n");
            writer.write(String.format("Period: %s to %s\n\n",
                report.weekStart.toString(), report.weekEnd.toString()));
            
            // Summary
            writer.write("WEEKLY SUMMARY\n");
            writer.write("Total Screen Time (hours)," + String.format("%.2f", report.totalScreenTime / 3600.0) + "\n");
            writer.write("Average Daily Screen Time (hours)," + String.format("%.2f", report.averageDailyScreenTime / 3600.0) + "\n");
            writer.write("Average Productivity Score," + String.format("%.1f%%", report.averageProductivityScore) + "\n\n");
            
            // Daily Breakdown
            writer.write("DAILY BREAKDOWN\n");
            writer.write("Date,Screen Time (hours),Productive Time (hours),Sessions,Productivity Score\n");
            for (DailySummary day : report.dailySummaries) {
                writer.write(String.format("%s,%.2f,%.2f,%d,%.1f\n",
                    day.date.toString(),
                    day.totalScreenTime / 3600.0,
                    day.productiveTime / 3600.0,
                    day.sessionCount,
                    day.productivityScore));
            }
            writer.write("\n");
            
            // Top Apps
            writer.write("TOP APPLICATIONS\n");
            writer.write("Application,Category,Sessions,Time (hours)\n");
            for (AppUsageInfo app : report.topApps) {
                writer.write(String.format("%s,%s,%d,%.2f\n",
                    escapeCsv(app.name), app.category, app.sessionCount, app.getHours()));
            }
        }
        
        return file;
    }

    public static File exportMonthlyReport(MonthlyReport report) throws IOException {
        String fileName = String.format("deskwell_monthly_report_%s.csv",
            report.monthStart.format(DateTimeFormatter.ofPattern("yyyyMM")));
        File file = new File(AppPaths.getExportDir(), fileName);
        
        try (FileWriter writer = new FileWriter(file)) {
            writer.write("DeskWell Monthly Report\n");
            writer.write("Month:," + report.monthName + "\n\n");
            
            // Summary
            writer.write("MONTHLY SUMMARY\n");
            writer.write("Total Screen Time (hours)," + String.format("%.2f", report.totalScreenTime / 3600.0) + "\n");
            writer.write("Average Daily Screen Time (hours)," + String.format("%.2f", report.averageDailyScreenTime / 3600.0) + "\n");
            writer.write("Average Productivity Score," + String.format("%.1f%%", report.averageProductivityScore) + "\n");
            
            if (report.mostProductiveDay != null) {
                writer.write("Most Productive Day," + report.mostProductiveDay.date.toString() + "\n");
            }
            if (report.leastProductiveDay != null) {
                writer.write("Least Productive Day," + report.leastProductiveDay.date.toString() + "\n");
            }
            writer.write("\n");
            
            // Weekly Breakdown
            writer.write("WEEKLY BREAKDOWN\n");
            writer.write("Week,Screen Time (hours),Productivity Score\n");
            for (WeeklyBreakdown week : report.weeklyBreakdown) {
                writer.write(String.format("Week of %s,%.2f,%.1f\n",
                    week.weekStart.toString(),
                    week.totalScreenTime / 3600.0,
                    week.averageProductivityScore));
            }
            writer.write("\n");
            
            // Daily Breakdown
            writer.write("DAILY BREAKDOWN\n");
            writer.write("Date,Screen Time (hours),Productive Time (hours),Sessions,Productivity Score\n");
            for (DailySummary day : report.dailySummaries) {
                writer.write(String.format("%s,%.2f,%.2f,%d,%.1f\n",
                    day.date.toString(),
                    day.totalScreenTime / 3600.0,
                    day.productiveTime / 3600.0,
                    day.sessionCount,
                    day.productivityScore));
            }
            writer.write("\n");
            
            // Category Breakdown
            writer.write("CATEGORY BREAKDOWN\n");
            writer.write("Category,Time (hours)\n");
            for (Map.Entry<String, Long> entry : report.categoryBreakdown.entrySet()) {
                writer.write(String.format("%s,%.2f\n",
                    entry.getKey(),
                    entry.getValue() / 3600.0));
            }
        }
        
        return file;
    }

    public static File exportRawData(List<Map<String, Object>> data, String fileName) throws IOException {
        File file = new File(fileName);
        
        try (FileWriter writer = new FileWriter(file)) {
            if (data.isEmpty()) return file;
            
            // Write headers
            Map<String, Object> firstRow = data.get(0);
            writer.write(String.join(",", firstRow.keySet()) + "\n");
            
            // Write data
            for (Map<String, Object> row : data) {
                String line = row.values().stream()
                    .map(v -> v != null ? v.toString() : "")
                    .collect(java.util.stream.Collectors.joining(","));
                writer.write(line + "\n");
            }
        }
        
        return file;
    }

    private static String escapeCsv(String value) {
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }
}
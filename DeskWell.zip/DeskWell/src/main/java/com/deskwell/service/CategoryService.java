package com.deskwell.service;

import com.deskwell.database.DatabaseManager;

import java.sql.*;
import java.util.*;
import java.util.logging.Logger;

public class CategoryService {
    private static final Logger logger = Logger.getLogger(CategoryService.class.getName());
    private final DatabaseManager databaseManager;

    // LinkedHashMap (not HashMap) so iteration order is deterministic and
    // matches the order entries are added below. That matters here:
    // "Development" is checked before "Productivity" on purpose, so an IDE
    // or tool whose name could plausibly match a keyword in either list
    // always resolves to the more specific "Development" (full productivity
    // weight) rather than being at the mercy of undefined HashMap ordering.
    private static final Map<String, String[]> KEYWORD_CATEGORIES = new LinkedHashMap<>();

    static {
        KEYWORD_CATEGORIES.put("Development", new String[]{
            "code", "visual studio", "intellij", "eclipse", "netbeans",
            "terminal", "cmd", "powershell", "git", "docker", "postman",
            "sublime", "atom", "vim", "neovim", "debug", "pycharm",
            "webstorm", "rider", "android studio", "xcode", "clion",
            "goland", "phpstorm", "rubymine", "datagrip", "compiler",
            "gcc", "javac", "python", "node", "rstudio", "jupyter",
            // Embedded / hardware development tools
            "arduino", "codeblocks", "code::blocks", "platformio",
            "energia", "keil", "mplab", "cubeide", "esp-idf", "avr studio",
            "avrdude", "putty", "minicom"
        });
        // Office / productivity suites, and design or AI tools. These are
        // genuinely work-related but are not hands-on-keyboard coding, so
        // per product requirement they do NOT count toward the productivity
        // score - only "Development" carries productivity weight (see
        // DatabaseManager.insertDefaultCategories: Productivity weight 0.0,
        // Development weight 1.0). They still get their own category here
        // for the breakdown chart/reports.
        KEYWORD_CATEGORIES.put("Productivity", new String[]{
            "word", "excel", "powerpoint", "outlook", "onenote", "notion",
            "evernote", "todoist", "trello", "asana", "calendar", "notes",
            // Design / creative tools
            "photoshop", "illustrator", "indesign", "premiere", "after effects",
            "lightroom", "xd", "figma", "sketch", "canva", "coreldraw",
            "affinity", "blender", "davinci resolve", "procreate",
            // AI tools / assistants
            "chatgpt", "claude", "copilot", "midjourney", "stable diffusion",
            "gemini", "dall-e", "runway", "perplexity"
        });
        KEYWORD_CATEGORIES.put("Browser", new String[]{
            "chrome", "firefox", "edge", "safari", "opera", "brave"
        });
        KEYWORD_CATEGORIES.put("Entertainment", new String[]{
            "youtube", "netflix", "spotify", "prime", "hulu", "disney",
            "twitch", "vimeo", "media player", "vlc", "video"
        });
        // Communication also covers social media / social networking apps
        // and sites (there is no separate "Social" category) - they never
        // count toward the productivity score either (weight 0.0).
        KEYWORD_CATEGORIES.put("Communication", new String[]{
            "slack", "discord", "teams", "zoom", "skype", "telegram",
            "whatsapp", "messenger", "signal", "chat", "mail", "gmail",
            // Social media / social networking
            "facebook", "instagram", "twitter", "x.com", "tiktok",
            "reddit", "linkedin", "pinterest", "snapchat", "threads",
            "tumblr", "quora", "wechat", "line", "viber"
        });
        KEYWORD_CATEGORIES.put("Gaming", new String[]{
            "steam", "epic", "minecraft", "league", "valorant", "fortnite",
            "gog", "battle.net", "origin", "uplay"
        });
    }

    // Category -> productivity weight, cached from the DB so the tracker's
    // per-poll productivity calculation doesn't need a query every few
    // seconds. Categories rarely change, so a simple invalidate-on-write
    // cache is enough; see invalidateWeightCache().
    private volatile Map<String, Double> weightCache;

    public CategoryService(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
    }

    public void autoCategorizeApplication(int applicationId, String appName) {
        String category = determineCategory(appName.toLowerCase());
        String sql = "UPDATE applications SET category_id = (SELECT id FROM categories WHERE name = ?) WHERE id = ?";
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, category);
            pstmt.setInt(2, applicationId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            logger.warning("Error auto-categorizing application: " + e.getMessage());
        }
    }

    private String determineCategory(String appName) {
        for (Map.Entry<String, String[]> entry : KEYWORD_CATEGORIES.entrySet()) {
            for (String keyword : entry.getValue()) {
                if (appName.toLowerCase().contains(keyword.toLowerCase())) {
                    return entry.getKey();
                }
            }
        }
        return "Other";
    }

    public Map<String, Object> getCategories() {
        Map<String, Object> categories = new LinkedHashMap<>();
        String sql = "SELECT * FROM categories ORDER BY id";
        
        try (Statement stmt = databaseManager.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Map<String, Object> category = new HashMap<>();
                category.put("id", rs.getInt("id"));
                category.put("name", rs.getString("name"));
                category.put("color", rs.getString("color"));
                category.put("isDefault", rs.getBoolean("is_default"));
                categories.put(rs.getString("name"), category);
            }
        } catch (SQLException e) {
            logger.severe("Error getting categories: " + e.getMessage());
        }
        
        return categories;
    }

    public void updateCategory(int categoryId, String name, String color) {
        String sql = "UPDATE categories SET name = ?, color = ? WHERE id = ? AND is_default = 0";
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, color);
            pstmt.setInt(3, categoryId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            logger.severe("Error updating category: " + e.getMessage());
        } finally {
            invalidateWeightCache();
        }
    }

    /**
     * How much of an app's time in this category counts toward the
     * productivity score / productive_time (1.0 = full credit, 0.0 = not
     * counted). Backed by categories.productivity_weight; defaults to 0.0
     * (not productive) for an unknown/missing category so a lookup failure
     * never inflates the score. By product requirement, only the
     * "Development" (coding/IDE/compiler) category is ever non-zero -
     * everything else, including "Productivity" (office/design/AI tools),
     * Browser, Entertainment, Communication (incl. social media) and
     * Gaming, is tracked and shown in its own category but never counted
     * as productive time.
     */
    public double getProductivityWeight(String categoryName) {
        if (categoryName == null) return 0.0;
        return loadWeightCache().getOrDefault(categoryName, 0.0);
    }

    private Map<String, Double> loadWeightCache() {
        Map<String, Double> cache = weightCache;
        if (cache != null) return cache;

        Map<String, Double> loaded = new HashMap<>();
        String sql = "SELECT name, productivity_weight FROM categories";
        try (Statement stmt = databaseManager.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                loaded.put(rs.getString("name"), rs.getDouble("productivity_weight"));
            }
        } catch (SQLException e) {
            logger.warning("Error loading category productivity weights: " + e.getMessage());
        }
        weightCache = loaded;
        return loaded;
    }

    public void invalidateWeightCache() {
        weightCache = null;
    }

    public void assignCategoryToApp(int applicationId, int categoryId) {
        String sql = "UPDATE applications SET category_id = ? WHERE id = ?";
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, categoryId);
            pstmt.setInt(2, applicationId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            logger.severe("Error assigning category: " + e.getMessage());
        }
    }
        public String getCategoryForApp(int appId) {
        String sql = """
            SELECT c.name 
            FROM applications a 
            JOIN categories c ON a.category_id = c.id 
            WHERE a.id = ?
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, appId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getString("name");
            }
        } catch (SQLException e) {
            logger.warning("Error getting category for app: " + e.getMessage());
        }
        return "Other";
    }
}
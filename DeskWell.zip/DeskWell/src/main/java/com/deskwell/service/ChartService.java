package com.deskwell.service;

import com.deskwell.database.DatabaseManager;
import javafx.scene.chart.XYChart;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.logging.Logger;

public class ChartService {
    private static final Logger logger = Logger.getLogger(ChartService.class.getName());
    private final DatabaseManager databaseManager;
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("MM/dd");
    private static final DateTimeFormatter MONTH_FORMATTER = DateTimeFormatter.ofPattern("MMM yyyy");

    public ChartService(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
    }

    // Hourly activity data for today
    public Map<Integer, Long> getHourlyActivity() {
        Map<Integer, Long> hourlyData = new LinkedHashMap<>();
        
        // Initialize all hours
        for (int i = 0; i < 24; i++) {
            hourlyData.put(i, 0L);
        }
        
        String sql = """
            SELECT CAST(strftime('%H', start_time) AS INTEGER) as hour,
                   SUM(duration_seconds) as total_time
            FROM usage_tracking
            WHERE date(start_time) = ?
            GROUP BY hour
            ORDER BY hour
            """;
        
        // Bound local date, not SQLite's UTC-based date('now') - see
        // ActivityTracker.loadTodayAppUsage() for why that matters.
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, LocalDate.now().toString());
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                int hour = rs.getInt("hour");
                long time = rs.getLong("total_time");
                hourlyData.put(hour, time);
            }
        } catch (SQLException e) {
            logger.warning("Error getting hourly activity: " + e.getMessage());
        }
        
        return hourlyData;
    }

    // Daily activity for the past week
    public Map<LocalDate, Long> getDailyActivity(int days) {
        Map<LocalDate, Long> dailyData = new LinkedHashMap<>();
        
        String sql = """
            SELECT date, total_screen_time
            FROM daily_stats
            WHERE date >= date('now', ?)
            ORDER BY date
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, "-" + days + " days");
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                LocalDate date = LocalDate.parse(rs.getString("date"));
                long time = rs.getLong("total_screen_time");
                dailyData.put(date, time);
            }
        } catch (SQLException e) {
            logger.warning("Error getting daily activity: " + e.getMessage());
        }
        
        // Fill in missing days with 0
        LocalDate today = LocalDate.now();
        for (int i = days; i >= 0; i--) {
            LocalDate date = today.minusDays(i);
            dailyData.putIfAbsent(date, 0L);
        }
        
        return dailyData;
    }

    // Weekly activity for the past month
    public Map<String, Long> getWeeklyActivity() {
        Map<String, Long> weeklyData = new LinkedHashMap<>();
        
        String sql = """
            SELECT strftime('%Y-%W', date) as week,
                   MIN(date) as week_start,
                   SUM(total_screen_time) as total_time
            FROM daily_stats
            WHERE date >= date('now', '-28 days')
            GROUP BY week
            ORDER BY week
            """;
        
        try (Statement stmt = databaseManager.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                String weekStart = rs.getString("week_start");
                long time = rs.getLong("total_time");
                weeklyData.put("Week of " + weekStart, time);
            }
        } catch (SQLException e) {
            logger.warning("Error getting weekly activity: " + e.getMessage());
        }
        
        return weeklyData;
    }

    // Monthly activity for the past year
    public Map<String, Long> getMonthlyActivity() {
        Map<String, Long> monthlyData = new LinkedHashMap<>();
        
        String sql = """
            SELECT strftime('%Y-%m', date) as month,
                   SUM(total_screen_time) as total_time
            FROM daily_stats
            WHERE date >= date('now', '-12 months')
            GROUP BY month
            ORDER BY month
            """;
        
        try (Statement stmt = databaseManager.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                String month = rs.getString("month");
                long time = rs.getLong("total_time");
                // Format month
                LocalDate date = LocalDate.parse(month + "-01");
                monthlyData.put(date.format(MONTH_FORMATTER), time);
            }
        } catch (SQLException e) {
            logger.warning("Error getting monthly activity: " + e.getMessage());
        }
        
        return monthlyData;
    }

    // Category breakdown for today
    public Map<String, CategoryStats> getCategoryBreakdown() {
        Map<String, CategoryStats> categoryData = new LinkedHashMap<>();
        
        String sql = """
            SELECT c.name, c.color, 
                   SUM(ut.duration_seconds) as total_time,
                   COUNT(DISTINCT a.id) as app_count
            FROM usage_tracking ut
            JOIN applications a ON ut.application_id = a.id
            JOIN categories c ON a.category_id = c.id
            WHERE date(ut.start_time) = ?
            GROUP BY c.id
            ORDER BY total_time DESC
            """;
        
        // Bound local date, not SQLite's UTC-based date('now') - see
        // ActivityTracker.loadTodayAppUsage() for why that matters. This is
        // what feeds the dashboard's category breakdown (colored donut
        // chart), so the same UTC-vs-local mismatch made it go empty too.
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, LocalDate.now().toString());
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                CategoryStats stats = new CategoryStats();
                stats.name = rs.getString("name");
                stats.color = rs.getString("color");
                stats.totalSeconds = rs.getLong("total_time");
                stats.appCount = rs.getInt("app_count");
                categoryData.put(stats.name, stats);
            }
        } catch (SQLException e) {
            logger.warning("Error getting category breakdown: " + e.getMessage());
        }
        
        return categoryData;
    }

    // Category breakdown for custom date range
    public Map<String, CategoryStats> getCategoryBreakdown(LocalDate startDate, LocalDate endDate) {
        Map<String, CategoryStats> categoryData = new LinkedHashMap<>();
        
        String sql = """
            SELECT c.name, c.color, 
                   SUM(ut.duration_seconds) as total_time,
                   COUNT(DISTINCT a.id) as app_count
            FROM usage_tracking ut
            JOIN applications a ON ut.application_id = a.id
            JOIN categories c ON a.category_id = c.id
            WHERE date(ut.start_time) BETWEEN ? AND ?
            GROUP BY c.id
            ORDER BY total_time DESC
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, startDate.toString());
            pstmt.setString(2, endDate.toString());
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                CategoryStats stats = new CategoryStats();
                stats.name = rs.getString("name");
                stats.color = rs.getString("color");
                stats.totalSeconds = rs.getLong("total_time");
                stats.appCount = rs.getInt("app_count");
                categoryData.put(stats.name, stats);
            }
        } catch (SQLException e) {
            logger.warning("Error getting category breakdown: " + e.getMessage());
        }
        
        return categoryData;
    }

    // Productivity trends
    public Map<LocalDate, Double> getProductivityTrends(int days) {
        Map<LocalDate, Double> trends = new LinkedHashMap<>();
        
        String sql = """
            SELECT date, productivity_score
            FROM daily_stats
            WHERE date >= date('now', ?)
            ORDER BY date
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, "-" + days + " days");
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                LocalDate date = LocalDate.parse(rs.getString("date"));
                double score = rs.getDouble("productivity_score");
                trends.put(date, score);
            }
        } catch (SQLException e) {
            logger.warning("Error getting productivity trends: " + e.getMessage());
        }
        
        return trends;
    }

    // Most used applications for a period
    public List<AppUsageData> getTopApplications(int limit, int days) {
        List<AppUsageData> apps = new ArrayList<>();
        
        String sql = """
            SELECT a.name, c.name as category, c.color,
                   SUM(ut.duration_seconds) as total_time
            FROM usage_tracking ut
            JOIN applications a ON ut.application_id = a.id
            JOIN categories c ON a.category_id = c.id
            WHERE date(ut.start_time) >= date('now', ?)
            GROUP BY a.id
            ORDER BY total_time DESC
            LIMIT ?
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, "-" + days + " days");
            pstmt.setInt(2, limit);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                AppUsageData app = new AppUsageData();
                app.name = rs.getString("name");
                app.category = rs.getString("category");
                app.color = rs.getString("color");
                app.totalSeconds = rs.getLong("total_time");
                apps.add(app);
            }
        } catch (SQLException e) {
            logger.warning("Error getting top applications: " + e.getMessage());
        }
        
        return apps;
    }

    // Focus time statistics
    public FocusStats getFocusStats() {
        FocusStats stats = new FocusStats();
        
        String sql = """
            SELECT 
                COUNT(*) as total_sessions,
                SUM(duration_minutes) as total_minutes,
                AVG(duration_minutes) as avg_duration,
                SUM(interruptions) as total_interruptions
            FROM focus_sessions
            WHERE date(start_time) = ?
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, LocalDate.now().toString());
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                stats.totalSessions = rs.getInt("total_sessions");
                stats.totalMinutes = rs.getInt("total_minutes");
                stats.avgDuration = rs.getDouble("avg_duration");
                stats.totalInterruptions = rs.getInt("total_interruptions");
            }
        } catch (SQLException e) {
            logger.warning("Error getting focus stats: " + e.getMessage());
        }
        
        return stats;
    }

    // Get total screen time for a period
    public long getTotalScreenTime(int days) {
        String sql = """
            SELECT COALESCE(SUM(total_screen_time), 0) as total
            FROM daily_stats
            WHERE date >= date('now', ?)
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, "-" + days + " days");
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getLong("total");
            }
        } catch (SQLException e) {
            logger.warning("Error getting total screen time: " + e.getMessage());
        }
        
        return 0;
    }

    // Data classes
    public static class CategoryStats {
        public String name;
        public String color;
        public long totalSeconds;
        public int appCount;
        
        public String getFormattedTime() {
            long hours = totalSeconds / 3600;
            long minutes = (totalSeconds % 3600) / 60;
            return String.format("%dh %dm", hours, minutes);
        }
        
        public double getPercentage(long total) {
            if (total == 0) return 0;
            return (totalSeconds * 100.0) / total;
        }
    }

    public static class AppUsageData {
        public String name;
        public String category;
        public String color;
        public long totalSeconds;
        
        public String getFormattedTime() {
            long hours = totalSeconds / 3600;
            long minutes = (totalSeconds % 3600) / 60;
            if (hours > 0) {
                return String.format("%dh %dm", hours, minutes);
            }
            return String.format("%dm", minutes);
        }
    }

    public static class FocusStats {
        public int totalSessions;
        public int totalMinutes;
        public double avgDuration;
        public int totalInterruptions;
        
        public String getFormattedFocusTime() {
            long hours = totalMinutes / 60;
            long minutes = totalMinutes % 60;
            return String.format("%dh %dm", hours, minutes);
        }
    }

    // Helper method to format seconds to readable time
    public static String formatDuration(long seconds) {
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        
        if (hours > 0) {
            return String.format("%dh %dm %ds", hours, minutes, secs);
        } else if (minutes > 0) {
            return String.format("%dm %ds", minutes, secs);
        } else {
            return String.format("%ds", secs);
        }
    }
}
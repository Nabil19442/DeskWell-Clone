package com.deskwell.service;

import com.deskwell.database.DatabaseManager;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.*;
import java.util.logging.Logger;

public class FocusModeService {
    private static final Logger logger = Logger.getLogger(FocusModeService.class.getName());
    private final DatabaseManager databaseManager;
    private final ScheduledExecutorService scheduler;
    private final List<FocusListener> listeners = new CopyOnWriteArrayList<>();
    
    private FocusSession currentSession;
    // Handle to the recurring tick() task. startFocusSession() used to call
    // scheduler.scheduleAtFixedRate() without ever cancelling a previous
    // task, so every "Start Focus" click (after a Stop, or across separate
    // sessions in the same run) queued another 1-second ticker on top of
    // any earlier ones. Since tick() only early-returns on IDLE/PAUSED
    // (not "cancelled"), old tasks kept firing forever once a new session
    // began, and the timer would count down N times faster than real time
    // after N restarts. Tracking the handle lets us cancel the previous
    // task before starting a new one, guaranteeing exactly one ticker runs.
    private ScheduledFuture<?> tickTaskHandle;
    private boolean isFocusMode = false;
    private boolean isOnBreak = false;
    private TimerState timerState = TimerState.IDLE;
    
    // Timer properties
    private int remainingSeconds = 0;
    private int focusDurationMinutes = 25; // Default 25 minutes
    private int breakDurationMinutes = 5;  // Default 5 minutes
    private int longBreakDurationMinutes = 15;
    private int sessionsBeforeLongBreak = 4;
    private int completedSessions = 0;
    
    // Session tracking
    private LocalDateTime sessionStartTime;
    private LocalDateTime focusStartTime;
    private int interruptions = 0;
    private long totalFocusTimeToday = 0;
    private int totalSessionsToday = 0;

    public FocusModeService(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
        loadTodayStats();
    }

    private void loadTodayStats() {
        String sql = """
            SELECT COUNT(*) as sessions, 
                   COALESCE(SUM(duration_minutes), 0) as total_minutes
            FROM focus_sessions
            WHERE date(start_time) = ?
            AND completed = 1
            """;
        
        // Bound local date, not SQLite's UTC-based date('now') - see
        // ActivityTracker.loadTodayAppUsage() for why that matters.
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, java.time.LocalDate.now().toString());
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                totalSessionsToday = rs.getInt("sessions");
                totalFocusTimeToday = rs.getLong("total_minutes");
            }
        } catch (SQLException e) {
            logger.warning("Error loading focus stats: " + e.getMessage());
        }
    }

    // Start a focus session
    public void startFocusSession() {
        if (isFocusMode) return;
        
        isFocusMode = true;
        isOnBreak = false;
        timerState = TimerState.FOCUS;
        remainingSeconds = focusDurationMinutes * 60;
        focusStartTime = LocalDateTime.now();
        interruptions = 0;
        
        // Save session to database
        saveSessionStart();
        
        notifyListeners("focus_started");
        
        // Start countdown. Cancel any previous ticker first so restarting
        // (or starting a fresh session after a previous one ended) never
        // results in more than one task driving tick() at once.
        if (tickTaskHandle != null) {
            tickTaskHandle.cancel(false);
        }
        tickTaskHandle = scheduler.scheduleAtFixedRate(this::tick, 0, 1, TimeUnit.SECONDS);
    }

    // Pause current session
    public void pauseSession() {
        if (!isFocusMode || timerState == TimerState.PAUSED) return;
        
        timerState = TimerState.PAUSED;
        interruptions++;
        updateSessionInterruptions();
        notifyListeners("focus_paused");
    }

    // Resume paused session
    public void resumeSession() {
        if (!isFocusMode || timerState != TimerState.PAUSED) return;
        
        timerState = isOnBreak ? TimerState.BREAK : TimerState.FOCUS;
        notifyListeners("focus_resumed");
    }

    // Stop current session
    public void stopSession() {
        if (!isFocusMode) return;
        
        isFocusMode = false;
        isOnBreak = false;
        timerState = TimerState.IDLE;
        remainingSeconds = 0;
        
        if (tickTaskHandle != null) {
            tickTaskHandle.cancel(false);
            tickTaskHandle = null;
        }
        
        saveSessionEnd(false);
        notifyListeners("focus_stopped");
    }

    // Timer tick
    private void tick() {
        if (timerState == TimerState.PAUSED || timerState == TimerState.IDLE) return;
        
        if (remainingSeconds > 0) {
            remainingSeconds--;
            notifyListeners("tick");
        } else {
            handleTimerComplete();
        }
    }

    private void handleTimerComplete() {
        if (timerState == TimerState.FOCUS) {
            // Focus session complete
            completedSessions++;
            totalSessionsToday++;
            totalFocusTimeToday += focusDurationMinutes;
            saveSessionEnd(true);
            
            notifyListeners("focus_complete");
            
            // Check if it's time for a long break
            if (completedSessions % sessionsBeforeLongBreak == 0) {
                startBreak(longBreakDurationMinutes);
            } else {
                startBreak(breakDurationMinutes);
            }
        } else if (timerState == TimerState.BREAK) {
            // Break complete. isFocusMode must be reset here too, not just
            // in stopSession() - otherwise it stays stuck at true forever
            // once a break finishes naturally, and startFocusSession()'s
            // "if (isFocusMode) return;" guard silently blocks every
            // future "Start Focus" click for the rest of the run (the UI
            // still shows a button press "working" because FocusModeView
            // resets its own button state independently, but no new timer
            // ever actually starts).
            isOnBreak = false;
            isFocusMode = false;
            timerState = TimerState.IDLE;
            if (tickTaskHandle != null) {
                tickTaskHandle.cancel(false);
                tickTaskHandle = null;
            }
            notifyListeners("break_complete");
        }
    }

    private void startBreak(int breakMinutes) {
        isOnBreak = true;
        timerState = TimerState.BREAK;
        remainingSeconds = breakMinutes * 60;
        notifyListeners("break_started");
    }

    // Skip break
    public void skipBreak() {
        if (isOnBreak) {
            isOnBreak = false;
            timerState = TimerState.IDLE;
            remainingSeconds = 0;
            notifyListeners("break_skipped");
        }
    }

    // Database operations
    private void saveSessionStart() {
        String sql = """
            INSERT INTO focus_sessions (start_time, duration_minutes, break_minutes, pomodoro_mode)
            VALUES (?, ?, ?, ?)
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, LocalDateTime.now().toString());
            pstmt.setInt(2, focusDurationMinutes);
            pstmt.setInt(3, breakDurationMinutes);
            pstmt.setBoolean(4, true);
            pstmt.executeUpdate();
            
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                currentSession = new FocusSession();
                currentSession.id = rs.getInt(1);
                currentSession.startTime = LocalDateTime.now();
                currentSession.focusDuration = focusDurationMinutes;
            }
        } catch (SQLException e) {
            logger.warning("Error saving focus session: " + e.getMessage());
        }
    }

    private void saveSessionEnd(boolean completed) {
        if (currentSession == null) return;
        
        String sql = """
            UPDATE focus_sessions 
            SET end_time = ?, completed = ?, interruptions = ?
            WHERE id = ?
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, LocalDateTime.now().toString());
            pstmt.setBoolean(2, completed);
            pstmt.setInt(3, interruptions);
            pstmt.setInt(4, currentSession.id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            logger.warning("Error updating focus session: " + e.getMessage());
        }
        
        currentSession = null;
    }

    private void updateSessionInterruptions() {
        if (currentSession == null) return;
        
        String sql = "UPDATE focus_sessions SET interruptions = ? WHERE id = ?";
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, interruptions);
            pstmt.setInt(2, currentSession.id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            logger.warning("Error updating interruptions: " + e.getMessage());
        }
    }

    // Get today's focus statistics
    public FocusStats getTodayStats() {
        FocusStats stats = new FocusStats();
        stats.totalSessions = totalSessionsToday;
        stats.totalFocusMinutes = totalFocusTimeToday;
        stats.currentStreak = completedSessions;
        stats.isInSession = isFocusMode;
        
        // Get weekly stats
        String sql = """
            SELECT COUNT(*) as sessions, 
                   COALESCE(SUM(duration_minutes), 0) as total_minutes,
                   COUNT(DISTINCT date(start_time)) as active_days
            FROM focus_sessions
            WHERE date(start_time) >= date('now', '-7 days')
            AND completed = 1
            """;
        
        try (Statement stmt = databaseManager.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                stats.weeklySessions = rs.getInt("sessions");
                stats.weeklyFocusMinutes = rs.getLong("total_minutes");
                stats.activeDays = rs.getInt("active_days");
            }
        } catch (SQLException e) {
            logger.warning("Error getting focus stats: " + e.getMessage());
        }
        
        return stats;
    }

    // Get focus history
    public List<FocusSession> getFocusHistory(int limit) {
        List<FocusSession> history = new ArrayList<>();
        
        String sql = """
            SELECT * FROM focus_sessions 
            ORDER BY start_time DESC 
            LIMIT ?
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, limit);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                FocusSession session = new FocusSession();
                session.id = rs.getInt("id");
                session.startTime = rs.getString("start_time") != null ?
                    LocalDateTime.parse(rs.getString("start_time").replace(" ", "T")) : null;
                session.endTime = rs.getString("end_time") != null ?
                    LocalDateTime.parse(rs.getString("end_time").replace(" ", "T")) : null;
                session.focusDuration = rs.getInt("duration_minutes");
                session.breakDuration = rs.getInt("break_minutes");
                session.completed = rs.getBoolean("completed");
                session.interruptions = rs.getInt("interruptions");
                history.add(session);
            }
        } catch (SQLException e) {
            logger.warning("Error getting focus history: " + e.getMessage());
        }
        
        return history;
    }

    // Settings
    public void setFocusDuration(int minutes) {
        this.focusDurationMinutes = minutes;
    }

    public void setBreakDuration(int minutes) {
        this.breakDurationMinutes = minutes;
    }

    public void setLongBreakDuration(int minutes) {
        this.longBreakDurationMinutes = minutes;
    }

    public void setSessionsBeforeLongBreak(int sessions) {
        this.sessionsBeforeLongBreak = sessions;
    }

    // Listener management
    public void addListener(FocusListener listener) {
        listeners.add(listener);
    }

    public void removeListener(FocusListener listener) {
        listeners.remove(listener);
    }

    private void notifyListeners(String event) {
        for (FocusListener listener : listeners) {
            try {
                listener.onFocusEvent(event, this);
            } catch (Exception e) {
                logger.warning("Error notifying listener: " + e.getMessage());
            }
        }
    }

    // Getters
    public boolean isFocusMode() { return isFocusMode; }
    public boolean isOnBreak() { return isOnBreak; }
    public TimerState getTimerState() { return timerState; }
    public int getRemainingSeconds() { return remainingSeconds; }
    public int getFocusDurationMinutes() { return focusDurationMinutes; }
    public int getBreakDurationMinutes() { return breakDurationMinutes; }
    public int getCompletedSessions() { return completedSessions; }
    public int getTotalSessionsToday() { return totalSessionsToday; }
    public long getTotalFocusTimeToday() { return totalFocusTimeToday; }

    // Helper methods
    public String getFormattedTime() {
        int hours = remainingSeconds / 3600;
        int minutes = (remainingSeconds % 3600) / 60;
        int seconds = remainingSeconds % 60;
        
        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        }
        return String.format("%02d:%02d", minutes, seconds);
    }

    public double getProgress() {
        if (timerState == TimerState.FOCUS) {
            int totalSeconds = focusDurationMinutes * 60;
            return 1.0 - ((double) remainingSeconds / totalSeconds);
        } else if (timerState == TimerState.BREAK) {
            int totalSeconds = breakDurationMinutes * 60;
            return 1.0 - ((double) remainingSeconds / totalSeconds);
        }
        return 0;
    }

    // Data classes
    public enum TimerState {
        IDLE, FOCUS, BREAK, PAUSED
    }

    public static class FocusSession {
        public int id;
        public LocalDateTime startTime;
        public LocalDateTime endTime;
        public int focusDuration;
        public int breakDuration;
        public boolean completed;
        public int interruptions;
        
        public String getFormattedStartTime() {
            return startTime != null ? 
                startTime.format(java.time.format.DateTimeFormatter.ofPattern("HH:mm")) : "";
        }
        
        public String getFormattedDuration() {
            return focusDuration + " min";
        }
    }

    public static class FocusStats {
        public int totalSessions;
        public long totalFocusMinutes;
        public int currentStreak;
        public boolean isInSession;
        public int weeklySessions;
        public long weeklyFocusMinutes;
        public int activeDays;
        
        public String getFormattedTotalTime() {
            long hours = totalFocusMinutes / 60;
            long minutes = totalFocusMinutes % 60;
            if (hours > 0) {
                return String.format("%dh %dm", hours, minutes);
            }
            return String.format("%dm", minutes);
        }
        
        public String getFormattedWeeklyTime() {
            long hours = weeklyFocusMinutes / 60;
            long minutes = weeklyFocusMinutes % 60;
            if (hours > 0) {
                return String.format("%dh %dm", hours, minutes);
            }
            return String.format("%dm", minutes);
        }
    }

    public interface FocusListener {
        void onFocusEvent(String event, FocusModeService service);
    }
}
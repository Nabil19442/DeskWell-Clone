package com.deskwell.service;

import com.deskwell.database.DatabaseManager;
import com.deskwell.tracker.ActivityTracker;
import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.awt.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

public class NotificationService implements ActivityTracker.TrackerListener {
    private static final Logger logger = Logger.getLogger(NotificationService.class.getName());
    private final DatabaseManager databaseManager;
    private final SettingsService settingsService;
    private final ScheduledExecutorService scheduler;
    
    private LocalDateTime lastBreakReminder;
    private LocalDateTime lastScreenTimeWarning;
    private boolean isRunning = false;
    
    private static final int BREAK_REMINDER_INTERVAL_MINUTES = 60;
    private static final int SCREEN_TIME_WARNING_THRESHOLD_SECONDS = 3600; // 1 hour

    public NotificationService(DatabaseManager databaseManager, SettingsService settingsService) {
        this.databaseManager = databaseManager;
        this.settingsService = settingsService;
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
    }

    public void start() {
        if (!isRunning) {
            isRunning = true;
            lastBreakReminder = LocalDateTime.now();
            lastScreenTimeWarning = LocalDateTime.now();
            
            // Check for notifications periodically
            scheduler.scheduleAtFixedRate(
                this::checkNotifications,
                60,
                60,
                TimeUnit.SECONDS
            );
            
            logger.info("Notification service started");
        }
    }

    public void stop() {
        isRunning = false;
        scheduler.shutdown();
        logger.info("Notification service stopped");
    }

    private void checkNotifications() {
        if (!isRunning) return;
        
        try {
            // Check break reminders
            checkBreakReminder();
            
            // Check screen time warning
            checkScreenTimeWarning();
            
            // Check goals
            checkGoals();
            
        } catch (Exception e) {
            logger.warning("Error checking notifications: " + e.getMessage());
        }
    }

    private void checkBreakReminder() {
        if (!Boolean.parseBoolean(settingsService.getSetting("break_reminder_enabled", "true"))) {
            return;
        }
        
        long minutesSinceLastBreak = ChronoUnit.MINUTES.between(
            lastBreakReminder, LocalDateTime.now()
        );
        
        int interval = Integer.parseInt(
            settingsService.getSetting("break_interval_minutes", "60")
        );
        
        if (minutesSinceLastBreak >= interval) {
            showBreakReminder();
            lastBreakReminder = LocalDateTime.now();
        }
    }

    private void checkScreenTimeWarning() {
        if (!Boolean.parseBoolean(settingsService.getSetting("screen_time_warning_enabled", "true"))) {
            return;
        }
        
        long threshold = Long.parseLong(
            settingsService.getSetting("screen_time_warning_threshold", "3600")
        );
        
        // Get current screen time
        String sql = "SELECT total_screen_time FROM daily_stats WHERE date = ?";
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, LocalDate.now().toString());
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                long screenTime = rs.getLong("total_screen_time");
                
                if (screenTime > threshold && 
                    ChronoUnit.MINUTES.between(lastScreenTimeWarning, LocalDateTime.now()) > 30) {
                    showScreenTimeWarning(screenTime, threshold);
                    lastScreenTimeWarning = LocalDateTime.now();
                }
            }
        } catch (Exception e) {
            logger.warning("Error checking screen time: " + e.getMessage());
        }
    }

    private void checkGoals() {
        // Goals' current_value is only ever written here and in
        // GoalsView.loadGoals() - there's no background job that keeps it
        // in sync with actual tracked usage. Refresh it first so a goal
        // that was reached while the Goals tab wasn't open still fires its
        // notification instead of silently sitting at a stale value.
        updateGoalProgress();
        
        String sql = """
            SELECT * FROM goals 
            WHERE is_active = 1 
            AND current_value >= target_value
            """;
        
        try (Statement stmt = databaseManager.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                showGoalReached(rs.getString("type"), rs.getInt("target_value"));
            }
        } catch (Exception e) {
            logger.warning("Error checking goals: " + e.getMessage());
        }
    }

    /**
     * Recalculates current_value for every active goal from today's real
     * tracked data. Mirrors GoalsView.updateGoalProgress() - kept here too
     * so goal-reached notifications work even when the Goals tab is never
     * opened during the session.
     */
    private void updateGoalProgress() {
        String selectSql = "SELECT id, type FROM goals WHERE is_active = 1";
        try (Statement stmt = databaseManager.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(selectSql)) {
            
            while (rs.next()) {
                int id = rs.getInt("id");
                String type = rs.getString("type");
                int minutes = computeTodayMinutesForGoalType(type);
                
                try (java.sql.PreparedStatement upd = databaseManager.getConnection().prepareStatement(
                        "UPDATE goals SET current_value = ? WHERE id = ?")) {
                    upd.setInt(1, minutes);
                    upd.setInt(2, id);
                    upd.executeUpdate();
                }
            }
        } catch (Exception e) {
            logger.warning("Error updating goal progress: " + e.getMessage());
        }
    }

    private int computeTodayMinutesForGoalType(String type) {
        String sql = switch (type.toLowerCase()) {
            case "screen_time" ->
                "SELECT COALESCE(total_screen_time, 0) / 60 AS m FROM daily_stats WHERE date = ?";
            case "productive_time" -> """
                SELECT COALESCE(SUM(ut.duration_seconds * c.productivity_weight), 0) / 60 AS m
                FROM usage_tracking ut
                JOIN applications a ON ut.application_id = a.id
                JOIN categories c ON a.category_id = c.id
                WHERE date(ut.start_time) = ?
                """;
            case "social_media" -> """
                SELECT COALESCE(SUM(ut.duration_seconds), 0) / 60 AS m
                FROM usage_tracking ut
                JOIN applications a ON ut.application_id = a.id
                JOIN categories c ON a.category_id = c.id
                WHERE c.name = 'Communication'
                AND date(ut.start_time) = ?
                """;
            case "focus_time" ->
                "SELECT COALESCE(SUM(duration_minutes), 0) AS m FROM focus_sessions " +
                "WHERE date(start_time) = ? AND completed = 1";
            default -> null;
        };
        
        if (sql == null) return 0;
        
        // Bound local date, not SQLite's UTC-based date('now') - see
        // ActivityTracker.loadTodayAppUsage() for why that matters.
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, LocalDate.now().toString());
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) return rs.getInt("m");
        } catch (Exception e) {
            logger.warning("Error computing progress for goal type " + type + ": " + e.getMessage());
        }
        return 0;
    }

    private void showBreakReminder() {
        Platform.runLater(() -> {
            if (SystemTray.isSupported()) {
                showSystemTrayNotification(
                    "DeskWell - Break Time!",
                    "You've been working for a while. Time to take a break! 🏃‍♂️"
                );
            } else {
                showAlert(
                    "Break Reminder",
                    "You've been working for a while. Time to take a break! 🏃‍♂️\n\n" +
                    "Stand up, stretch, and rest your eyes for a few minutes."
                );
            }
        });
    }

    private void showScreenTimeWarning(long screenTime, long threshold) {
        Platform.runLater(() -> {
            long hours = screenTime / 3600;
            long minutes = (screenTime % 3600) / 60;
            
            showAlert(
                "Screen Time Warning",
                String.format(
                    "You've been using your computer for %d hours and %d minutes today.\n" +
                    "Consider taking a longer break to rest your eyes and mind.",
                    hours, minutes
                )
            );
        });
    }

    private void showGoalReached(String goalType, int targetValue) {
        Platform.runLater(() -> {
            showAlert(
                "Goal Reached! 🎉",
                String.format(
                    "Congratulations! You've reached your %s goal of %d.",
                    goalType, targetValue
                )
            );
        });
    }

    public void showFocusSessionFinished(int sessionMinutes) {
        Platform.runLater(() -> {
            showAlert(
                "Focus Session Complete!",
                String.format(
                    "Great job! You completed a %d-minute focus session.\n" +
                    "Take a short break before starting the next one.",
                    sessionMinutes
                )
            );
        });
    }

    private void showSystemTrayNotification(String title, String message) {
        try {
            SystemTray tray = SystemTray.getSystemTray();
            
            // Create tray icon if needed
            Image image = Toolkit.getDefaultToolkit().createImage(
                getClass().getResource("/icons/tray-icon.png")
            );
            
            TrayIcon trayIcon = new TrayIcon(image, "DeskWell");
            trayIcon.setImageAutoSize(true);
            
            try {
                tray.add(trayIcon);
            } catch (AWTException e) {
                // Tray icon might already exist
            }
            
            trayIcon.displayMessage(title, message, TrayIcon.MessageType.INFO);
            
            // Remove tray icon after showing notification
            tray.remove(trayIcon);
            
        } catch (Exception e) {
            logger.warning("Error showing system tray notification: " + e.getMessage());
            showAlert(title, message);
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    @Override
    public void onTrackerEvent(String event, ActivityTracker tracker) {
        switch (event) {
            case "started" -> logger.info("Tracking started");
            case "stopped" -> logger.info("Tracking stopped");
            case "idle" -> logger.info("User went idle");
            case "active" -> logger.info("User became active");
            case "app_changed" -> logger.info("Active application changed");
            case "new_session" -> logger.info("New session started");
        }
    }
}
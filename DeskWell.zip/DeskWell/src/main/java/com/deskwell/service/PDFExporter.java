package com.deskwell.service;

import com.deskwell.service.ReportService.*;
import org.apache.pdfbox.pdmodel.*;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.apache.pdfbox.pdmodel.graphics.color.PDColor;
import org.apache.pdfbox.pdmodel.graphics.color.PDDeviceRGB;

import com.deskwell.util.AppPaths;
import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.logging.Logger;

public class PDFExporter {
    private static final Logger logger = Logger.getLogger(PDFExporter.class.getName());
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd");
    
    private static final Color HEADER_COLOR = new Color(33, 150, 243);
    private static final Color TEXT_COLOR = new Color(33, 33, 33);
    private static final Color LIGHT_GRAY = new Color(245, 245, 245);

    public static File exportDailyReport(DailyReport report) throws IOException {
        String fileName = String.format("deskwell_daily_report_%s.pdf", 
            report.date.format(DATE_FORMAT));
        File file = new File(AppPaths.getExportDir(), fileName);
        
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);
            
            PDPageContentStream content = new PDPageContentStream(document, page);
            
            float yPosition = page.getMediaBox().getHeight() - 50;
            float margin = 50;
            float width = page.getMediaBox().getWidth() - 2 * margin;
            
            // Title
            content.setNonStrokingColor(HEADER_COLOR);
            content.beginText();
            content.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD), 24);
            content.newLineAtOffset(margin, yPosition);
            content.showText("DeskWell Daily Report");
            content.endText();
            
            yPosition -= 40;
            
            // Date
            content.setNonStrokingColor(TEXT_COLOR);
            content.beginText();
            content.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 14);
            content.newLineAtOffset(margin, yPosition);
            content.showText("Date: " + report.date.toString());
            content.endText();
            
            yPosition -= 30;
            
            // Summary Section
            yPosition = addSectionHeader(content, "Summary", margin, yPosition);
            
            String[][] summaryData = {
                {"Total Screen Time:", String.format("%.1f hours", report.totalScreenTime / 3600.0)},
                {"Productive Time:", String.format("%.1f hours", report.productiveTime / 3600.0)},
                {"Idle Time:", String.format("%.1f hours", report.idleTime / 3600.0)},
                {"Number of Sessions:", String.valueOf(report.sessionCount)},
                {"Productivity Score:", String.format("%.1f%%", report.productivityScore)}
            };
            
            for (String[] row : summaryData) {
                content.beginText();
                content.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 12);
                content.newLineAtOffset(margin + 20, yPosition);
                content.showText(row[0] + " " + row[1]);
                content.endText();
                yPosition -= 20;
            }
            
            yPosition -= 20;
            
            // App Usage Section
            yPosition = addSectionHeader(content, "Application Usage", margin, yPosition);
            
            if (!report.appUsage.isEmpty()) {
                // Table header
                String[] headers = {"Application", "Category", "Sessions", "Time"};
                float[] colWidths = {200, 100, 80, 100};
                yPosition = drawTableRow(content, margin, yPosition, headers, colWidths, true);
                
                // Table rows
                for (AppUsageInfo app : report.appUsage) {
                    String[] row = {
                        truncate(app.name, 30),
                        app.category,
                        String.valueOf(app.sessionCount),
                        app.getFormattedTime()
                    };
                    yPosition = drawTableRow(content, margin, yPosition, row, colWidths, false);
                }
            }
            
            content.close();
            document.save(file);
        }
        
        return file;
    }

    public static File exportWeeklyReport(WeeklyReport report) throws IOException {
        String fileName = String.format("deskwell_weekly_report_%s.pdf",
            report.weekStart.format(DATE_FORMAT));
        File file = new File(AppPaths.getExportDir(), fileName);
        
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);
            
            PDPageContentStream content = new PDPageContentStream(document, page);
            
            float yPosition = page.getMediaBox().getHeight() - 50;
            float margin = 50;
            
            // Title
            content.setNonStrokingColor(HEADER_COLOR);
            content.beginText();
            content.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD), 24);
            content.newLineAtOffset(margin, yPosition);
            content.showText("DeskWell Weekly Report");
            content.endText();
            
            yPosition -= 40;
            
            // Period
            content.setNonStrokingColor(TEXT_COLOR);
            content.beginText();
            content.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 14);
            content.newLineAtOffset(margin, yPosition);
            content.showText(String.format("Period: %s to %s", 
                report.weekStart.toString(), report.weekEnd.toString()));
            content.endText();
            
            yPosition -= 30;
            
            // Summary
            yPosition = addSectionHeader(content, "Weekly Summary", margin, yPosition);
            
            String[][] summaryData = {
                {"Total Screen Time:", report.getFormattedTotalTime()},
                {"Average Daily Screen Time:", report.getFormattedAverage()},
                {"Average Productivity Score:", String.format("%.1f%%", report.averageProductivityScore)}
            };
            
            for (String[] row : summaryData) {
                content.beginText();
                content.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 12);
                content.newLineAtOffset(margin + 20, yPosition);
                content.showText(row[0] + " " + row[1]);
                content.endText();
                yPosition -= 20;
            }
            
            yPosition -= 20;
            
            // Daily Breakdown
            yPosition = addSectionHeader(content, "Daily Breakdown", margin, yPosition);
            
            if (!report.dailySummaries.isEmpty()) {
                String[] headers = {"Date", "Screen Time", "Productivity"};
                float[] colWidths = {200, 140, 140};
                yPosition = drawTableRow(content, margin, yPosition, headers, colWidths, true);
                
                for (DailySummary day : report.dailySummaries) {
                    String[] row = {
                        day.getFormattedDate(),
                        ReportService.formatDuration(day.totalScreenTime),
                        String.format("%.1f%%", day.productivityScore)
                    };
                    yPosition = drawTableRow(content, margin, yPosition, row, colWidths, false);
                }
            }
            
            content.close();
            document.save(file);
        }
        
        return file;
    }

    public static File exportMonthlyReport(MonthlyReport report) throws IOException {
        String fileName = String.format("deskwell_monthly_report_%s.pdf",
            report.monthStart.format(DateTimeFormatter.ofPattern("yyyyMM")));
        File file = new File(AppPaths.getExportDir(), fileName);
        
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);
            
            PDPageContentStream content = new PDPageContentStream(document, page);
            
            float yPosition = page.getMediaBox().getHeight() - 50;
            float margin = 50;
            
            // Title
            content.setNonStrokingColor(HEADER_COLOR);
            content.beginText();
            content.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD), 24);
            content.newLineAtOffset(margin, yPosition);
            content.showText("DeskWell Monthly Report - " + report.monthName);
            content.endText();
            
            yPosition -= 40;
            
            // Summary
            yPosition = addSectionHeader(content, "Monthly Summary", margin, yPosition);
            
            String[][] summaryData = {
                {"Total Screen Time:", report.getFormattedTotalTime()},
                {"Average Daily Screen Time:", ReportService.formatDuration(report.averageDailyScreenTime)},
                {"Average Productivity Score:", String.format("%.1f%%", report.averageProductivityScore)}
            };
            
            if (report.mostProductiveDay != null) {
                summaryData = java.util.Arrays.copyOf(summaryData, summaryData.length + 1);
                summaryData[summaryData.length - 1] = new String[]{
                    "Most Productive Day:", 
                    report.mostProductiveDay.getFormattedDate() + 
                    String.format(" (%.1f%%)", report.mostProductiveDay.productivityScore)
                };
            }
            
            for (String[] row : summaryData) {
                content.beginText();
                content.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 12);
                content.newLineAtOffset(margin + 20, yPosition);
                content.showText(row[0] + " " + row[1]);
                content.endText();
                yPosition -= 20;
            }
            
            content.close();
            document.save(file);
        }
        
        return file;
    }

    private static float addSectionHeader(PDPageContentStream content, String title, 
                                          float x, float y) throws IOException {
        content.setNonStrokingColor(HEADER_COLOR);
        content.beginText();
        content.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD), 16);
        content.newLineAtOffset(x, y);
        content.showText(title);
        content.endText();
        
        // Draw underline
        content.setStrokingColor(HEADER_COLOR);
        content.setLineWidth(2);
        content.moveTo(x, y - 5);
        content.lineTo(x + 200, y - 5);
        content.stroke();
        content.setNonStrokingColor(TEXT_COLOR);
        
        return y - 30;
    }

    private static float drawTableRow(PDPageContentStream content, float x, float y,
                                      String[] cells, float[] widths, boolean isHeader) 
                                      throws IOException {
        float currentX = x;
        float rowHeight = 25;
        
        // Draw background for header
        if (isHeader) {
            content.setNonStrokingColor(HEADER_COLOR);
            content.addRect(currentX, y - rowHeight + 5, 
                sumWidths(widths), rowHeight);
            content.fill();
            content.setNonStrokingColor(Color.WHITE);
        } else {
            content.setNonStrokingColor(TEXT_COLOR);
        }
        
        for (int i = 0; i < cells.length; i++) {
            content.beginText();
            content.setFont(new PDType1Font(isHeader ? Standard14Fonts.FontName.HELVETICA_BOLD : 
                Standard14Fonts.FontName.HELVETICA), 10);
            content.newLineAtOffset(currentX + 5, y - 15);
            content.showText(cells[i]);
            content.endText();
            currentX += widths[i];
        }
        
        // Draw border
        content.setStrokingColor(LIGHT_GRAY);
        content.setLineWidth(1);
        content.moveTo(x, y - rowHeight);
        content.lineTo(x + sumWidths(widths), y - rowHeight);
        content.stroke();
        
        return y - rowHeight;
    }

    private static float sumWidths(float[] widths) {
        float total = 0;
        for (float w : widths) {
            total += w;
        }
        return total;
    }

    private static String truncate(String text, int maxLength) {
        if (text.length() <= maxLength) return text;
        return text.substring(0, maxLength - 3) + "...";
    }
}
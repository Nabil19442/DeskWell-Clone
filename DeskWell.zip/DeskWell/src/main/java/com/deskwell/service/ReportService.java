package com.deskwell.service;

import com.deskwell.database.DatabaseManager;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.WeekFields;
import java.util.*;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class ReportService {
    private static final Logger logger = Logger.getLogger(ReportService.class.getName());
    private final DatabaseManager databaseManager;
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter DISPLAY_DATE_FORMAT = DateTimeFormatter.ofPattern("MMM dd, yyyy");

    public ReportService(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
    }

    // Daily report data
    public DailyReport getDailyReport(LocalDate date) {
        DailyReport report = new DailyReport();
        report.date = date;
        
        // Get daily stats
        String statsSql = """
            SELECT * FROM daily_stats WHERE date = ?
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(statsSql)) {
            pstmt.setString(1, date.toString());
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                report.totalScreenTime = rs.getLong("total_screen_time");
                report.productiveTime = rs.getLong("productive_time");
                report.idleTime = rs.getLong("idle_time");
                report.sessionCount = rs.getInt("session_count");
                report.productivityScore = rs.getDouble("productivity_score");
            }
        } catch (SQLException e) {
            logger.warning("Error getting daily stats: " + e.getMessage());
        }
        
        // Get session details
        report.sessions = getSessions(date);
        
        // Get app usage
        report.appUsage = getAppUsage(date);
        
        // Get hourly breakdown
        report.hourlyBreakdown = getHourlyBreakdown(date);
        
        // Get category breakdown
        report.categoryBreakdown = getCategoryBreakdown(date);
        
        return report;
    }

    private List<SessionInfo> getSessions(LocalDate date) {
        List<SessionInfo> sessions = new ArrayList<>();
        String sql = """
            SELECT id, start_time, end_time, duration_seconds
            FROM sessions
            WHERE date(start_time) = ?
            ORDER BY start_time
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, date.toString());
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                SessionInfo session = new SessionInfo();
                session.id = rs.getInt("id");
                session.startTime = rs.getString("start_time") != null ? 
                    LocalDateTime.parse(rs.getString("start_time").replace(" ", "T")) : null;
                session.endTime = rs.getString("end_time") != null ? 
                    LocalDateTime.parse(rs.getString("end_time").replace(" ", "T")) : null;
                session.durationSeconds = rs.getLong("duration_seconds");
                sessions.add(session);
            }
        } catch (SQLException e) {
            logger.warning("Error getting sessions: " + e.getMessage());
        }
        
        return sessions;
    }

    private List<AppUsageInfo> getAppUsage(LocalDate date) {
        List<AppUsageInfo> apps = new ArrayList<>();
        String sql = """
            SELECT a.name, c.name as category, c.color,
                   COUNT(*) as session_count,
                   SUM(ut.duration_seconds) as total_time
            FROM usage_tracking ut
            JOIN applications a ON ut.application_id = a.id
            JOIN categories c ON a.category_id = c.id
            WHERE date(ut.start_time) = ?
            GROUP BY a.id
            ORDER BY total_time DESC
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, date.toString());
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                AppUsageInfo app = new AppUsageInfo();
                app.name = rs.getString("name");
                app.category = rs.getString("category");
                app.color = rs.getString("color");
                app.sessionCount = rs.getInt("session_count");
                app.totalSeconds = rs.getLong("total_time");
                apps.add(app);
            }
        } catch (SQLException e) {
            logger.warning("Error getting app usage: " + e.getMessage());
        }
        
        return apps;
    }

    private Map<Integer, Long> getHourlyBreakdown(LocalDate date) {
        Map<Integer, Long> hourly = new LinkedHashMap<>();
        for (int i = 0; i < 24; i++) {
            hourly.put(i, 0L);
        }
        
        String sql = """
            SELECT CAST(strftime('%H', start_time) AS INTEGER) as hour,
                   SUM(duration_seconds) as total_time
            FROM usage_tracking
            WHERE date(start_time) = ?
            GROUP BY hour
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, date.toString());
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                hourly.put(rs.getInt("hour"), rs.getLong("total_time"));
            }
        } catch (SQLException e) {
            logger.warning("Error getting hourly breakdown: " + e.getMessage());
        }
        
        return hourly;
    }

    private Map<String, Long> getCategoryBreakdown(LocalDate date) {
        Map<String, Long> categories = new LinkedHashMap<>();
        
        String sql = """
            SELECT c.name, SUM(ut.duration_seconds) as total_time
            FROM usage_tracking ut
            JOIN applications a ON ut.application_id = a.id
            JOIN categories c ON a.category_id = c.id
            WHERE date(ut.start_time) = ?
            GROUP BY c.name
            ORDER BY total_time DESC
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, date.toString());
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                categories.put(rs.getString("name"), rs.getLong("total_time"));
            }
        } catch (SQLException e) {
            logger.warning("Error getting category breakdown: " + e.getMessage());
        }
        
        return categories;
    }

    // Weekly report
    public WeeklyReport getWeeklyReport(int weekOffset) {
        WeeklyReport report = new WeeklyReport();
        
        LocalDate today = LocalDate.now();
        LocalDate weekStart = today.minusWeeks(weekOffset)
            .with(WeekFields.of(Locale.getDefault()).dayOfWeek(), 1);
        LocalDate weekEnd = weekStart.plusDays(6);
        
        report.weekStart = weekStart;
        report.weekEnd = weekEnd;
        
        String sql = """
            SELECT date, total_screen_time, productive_time, idle_time,
                   session_count, productivity_score
            FROM daily_stats
            WHERE date BETWEEN ? AND ?
            ORDER BY date
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, weekStart.toString());
            pstmt.setString(2, weekEnd.toString());
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                DailySummary summary = new DailySummary();
                summary.date = LocalDate.parse(rs.getString("date"));
                summary.totalScreenTime = rs.getLong("total_screen_time");
                summary.productiveTime = rs.getLong("productive_time");
                summary.idleTime = rs.getLong("idle_time");
                summary.sessionCount = rs.getInt("session_count");
                summary.productivityScore = rs.getDouble("productivity_score");
                report.dailySummaries.add(summary);
                
                // Aggregate totals
                report.totalScreenTime += summary.totalScreenTime;
                report.totalProductiveTime += summary.productiveTime;
            }
        } catch (SQLException e) {
            logger.warning("Error getting weekly report: " + e.getMessage());
        }
        
        // Get top apps for the week
        report.topApps = getTopApps(weekStart, weekEnd, 10);
        
        // Calculate averages
        if (!report.dailySummaries.isEmpty()) {
            report.averageDailyScreenTime = report.totalScreenTime / report.dailySummaries.size();
            report.averageProductivityScore = report.dailySummaries.stream()
                .mapToDouble(d -> d.productivityScore)
                .average()
                .orElse(0.0);
        }
        
        return report;
    }

    // Monthly report
    public MonthlyReport getMonthlyReport(int monthOffset) {
        MonthlyReport report = new MonthlyReport();
        
        LocalDate today = LocalDate.now();
        LocalDate monthStart = today.minusMonths(monthOffset).withDayOfMonth(1);
        LocalDate monthEnd = monthStart.plusMonths(1).minusDays(1);
        
        report.monthStart = monthStart;
        report.monthEnd = monthEnd;
        report.monthName = monthStart.format(DateTimeFormatter.ofPattern("MMMM yyyy"));
        
        String sql = """
            SELECT date, total_screen_time, productive_time, idle_time,
                   session_count, productivity_score
            FROM daily_stats
            WHERE date BETWEEN ? AND ?
            ORDER BY date
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, monthStart.toString());
            pstmt.setString(2, monthEnd.toString());
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                DailySummary summary = new DailySummary();
                summary.date = LocalDate.parse(rs.getString("date"));
                summary.totalScreenTime = rs.getLong("total_screen_time");
                summary.productiveTime = rs.getLong("productive_time");
                summary.idleTime = rs.getLong("idle_time");
                summary.sessionCount = rs.getInt("session_count");
                summary.productivityScore = rs.getDouble("productivity_score");
                report.dailySummaries.add(summary);
                
                // Aggregate totals
                report.totalScreenTime += summary.totalScreenTime;
                report.totalProductiveTime += summary.productiveTime;
            }
        } catch (SQLException e) {
            logger.warning("Error getting monthly report: " + e.getMessage());
        }
        
        // Weekly breakdown within month
        report.weeklyBreakdown = getWeeklyBreakdown(monthStart, monthEnd);
        
        // Top apps for the month
        report.topApps = getTopApps(monthStart, monthEnd, 15);
        
        // Category breakdown
        report.categoryBreakdown = getCategoryBreakdown(monthStart, monthEnd);
        
        // Calculate averages
        if (!report.dailySummaries.isEmpty()) {
            report.averageDailyScreenTime = report.totalScreenTime / report.dailySummaries.size();
            report.averageProductivityScore = report.dailySummaries.stream()
                .mapToDouble(d -> d.productivityScore)
                .average()
                .orElse(0.0);
        }
        
        // Most productive day
        report.mostProductiveDay = report.dailySummaries.stream()
            .max(Comparator.comparingDouble(d -> d.productivityScore))
            .orElse(null);
        
        // Least productive day
        report.leastProductiveDay = report.dailySummaries.stream()
            .min(Comparator.comparingDouble(d -> d.productivityScore))
            .orElse(null);
        
        return report;
    }

    private List<AppUsageInfo> getTopApps(LocalDate start, LocalDate end, int limit) {
        List<AppUsageInfo> apps = new ArrayList<>();
        String sql = """
            SELECT a.name, c.name as category, c.color,
                   COUNT(*) as session_count,
                   SUM(ut.duration_seconds) as total_time
            FROM usage_tracking ut
            JOIN applications a ON ut.application_id = a.id
            JOIN categories c ON a.category_id = c.id
            WHERE date(ut.start_time) BETWEEN ? AND ?
            GROUP BY a.id
            ORDER BY total_time DESC
            LIMIT ?
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, start.toString());
            pstmt.setString(2, end.toString());
            pstmt.setInt(3, limit);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                AppUsageInfo app = new AppUsageInfo();
                app.name = rs.getString("name");
                app.category = rs.getString("category");
                app.color = rs.getString("color");
                app.sessionCount = rs.getInt("session_count");
                app.totalSeconds = rs.getLong("total_time");
                apps.add(app);
            }
        } catch (SQLException e) {
            logger.warning("Error getting top apps: " + e.getMessage());
        }
        
        return apps;
    }

    private List<WeeklyBreakdown> getWeeklyBreakdown(LocalDate monthStart, LocalDate monthEnd) {
        List<WeeklyBreakdown> weeks = new ArrayList<>();
        
        // Get weeks in month
        LocalDate current = monthStart;
        while (current.isBefore(monthEnd) || current.equals(monthEnd)) {
            LocalDate weekStart = current;
            LocalDate weekEnd = current.plusDays(6);
            if (weekEnd.isAfter(monthEnd)) {
                weekEnd = monthEnd;
            }
            
            WeeklyBreakdown week = new WeeklyBreakdown();
            week.weekStart = weekStart;
            week.weekEnd = weekEnd;
            
            String sql = """
                SELECT SUM(total_screen_time) as total_time,
                       AVG(productivity_score) as avg_score
                FROM daily_stats
                WHERE date BETWEEN ? AND ?
                """;
            
            try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
                pstmt.setString(1, weekStart.toString());
                pstmt.setString(2, weekEnd.toString());
                ResultSet rs = pstmt.executeQuery();
                
                if (rs.next()) {
                    week.totalScreenTime = rs.getLong("total_time");
                    week.averageProductivityScore = rs.getDouble("avg_score");
                }
            } catch (SQLException e) {
                logger.warning("Error getting weekly breakdown: " + e.getMessage());
            }
            
            weeks.add(week);
            current = current.plusWeeks(1);
        }
        
        return weeks;
    }

    private Map<String, Long> getCategoryBreakdown(LocalDate start, LocalDate end) {
        Map<String, Long> categories = new LinkedHashMap<>();
        
        String sql = """
            SELECT c.name, SUM(ut.duration_seconds) as total_time
            FROM usage_tracking ut
            JOIN applications a ON ut.application_id = a.id
            JOIN categories c ON a.category_id = c.id
            WHERE date(ut.start_time) BETWEEN ? AND ?
            GROUP BY c.name
            ORDER BY total_time DESC
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, start.toString());
            pstmt.setString(2, end.toString());
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                categories.put(rs.getString("name"), rs.getLong("total_time"));
            }
        } catch (SQLException e) {
            logger.warning("Error getting category breakdown: " + e.getMessage());
        }
        
        return categories;
    }

    // Comparison between two periods
    public ComparisonReport getComparisonReport(LocalDate period1Start, LocalDate period1End,
                                                  LocalDate period2Start, LocalDate period2End) {
        ComparisonReport report = new ComparisonReport();
        
        report.period1 = getPeriodSummary(period1Start, period1End);
        report.period2 = getPeriodSummary(period2Start, period2End);
        
        // Calculate changes
        if (report.period1.totalScreenTime > 0) {
            report.screenTimeChange = ((double)(report.period2.totalScreenTime - report.period1.totalScreenTime) 
                / report.period1.totalScreenTime) * 100;
        }
        
        report.productivityChange = report.period2.averageProductivityScore - 
                                     report.period1.averageProductivityScore;
        
        return report;
    }

    private PeriodSummary getPeriodSummary(LocalDate start, LocalDate end) {
        PeriodSummary summary = new PeriodSummary();
        
        String sql = """
            SELECT SUM(total_screen_time) as total_time,
                   AVG(productivity_score) as avg_score,
                   COUNT(*) as days_count
            FROM daily_stats
            WHERE date BETWEEN ? AND ?
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, start.toString());
            pstmt.setString(2, end.toString());
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                summary.totalScreenTime = rs.getLong("total_time");
                summary.averageProductivityScore = rs.getDouble("avg_score");
                summary.daysCount = rs.getInt("days_count");
            }
        } catch (SQLException e) {
            logger.warning("Error getting period summary: " + e.getMessage());
        }
        
        return summary;
    }

    // Export data for CSV
    public List<Map<String, Object>> getExportData(LocalDate start, LocalDate end) {
        List<Map<String, Object>> data = new ArrayList<>();
        
        String sql = """
            SELECT date, total_screen_time, productive_time, idle_time,
                   session_count, productivity_score
            FROM daily_stats
            WHERE date BETWEEN ? AND ?
            ORDER BY date
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, start.toString());
            pstmt.setString(2, end.toString());
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("Date", rs.getString("date"));
                row.put("Screen Time (hours)", rs.getLong("total_screen_time") / 3600.0);
                row.put("Productive Time (hours)", rs.getLong("productive_time") / 3600.0);
                row.put("Idle Time (hours)", rs.getLong("idle_time") / 3600.0);
                row.put("Sessions", rs.getInt("session_count"));
                row.put("Productivity Score", rs.getDouble("productivity_score"));
                data.add(row);
            }
        } catch (SQLException e) {
            logger.warning("Error getting export data: " + e.getMessage());
        }
        
        return data;
    }

    // Data classes
    public static class DailyReport {
        public LocalDate date;
        public long totalScreenTime;
        public long productiveTime;
        public long idleTime;
        public int sessionCount;
        public double productivityScore;
        public List<SessionInfo> sessions = new ArrayList<>();
        public List<AppUsageInfo> appUsage = new ArrayList<>();
        public Map<Integer, Long> hourlyBreakdown = new LinkedHashMap<>();
        public Map<String, Long> categoryBreakdown = new LinkedHashMap<>();
        
        public String getFormattedScreenTime() {
            return formatDuration(totalScreenTime);
        }
        
        public String getFormattedProductiveTime() {
            return formatDuration(productiveTime);
        }
    }

    public static class WeeklyReport {
        public LocalDate weekStart;
        public LocalDate weekEnd;
        public long totalScreenTime;
        public long totalProductiveTime;
        public long averageDailyScreenTime;
        public double averageProductivityScore;
        public List<DailySummary> dailySummaries = new ArrayList<>();
        public List<AppUsageInfo> topApps = new ArrayList<>();
        
        public String getFormattedTotalTime() {
            return formatDuration(totalScreenTime);
        }
        
        public String getFormattedAverage() {
            return formatDuration(averageDailyScreenTime);
        }
    }

    public static class MonthlyReport {
        public LocalDate monthStart;
        public LocalDate monthEnd;
        public String monthName;
        public long totalScreenTime;
        public long totalProductiveTime;
        public long averageDailyScreenTime;
        public double averageProductivityScore;
        public List<DailySummary> dailySummaries = new ArrayList<>();
        public List<WeeklyBreakdown> weeklyBreakdown = new ArrayList<>();
        public List<AppUsageInfo> topApps = new ArrayList<>();
        public Map<String, Long> categoryBreakdown = new LinkedHashMap<>();
        public DailySummary mostProductiveDay;
        public DailySummary leastProductiveDay;
        
        public String getFormattedTotalTime() {
            long hours = totalScreenTime / 3600;
            return String.format("%d hours %d minutes", hours, (totalScreenTime % 3600) / 60);
        }
    }

    public static class DailySummary {
        public LocalDate date;
        public long totalScreenTime;
        public long productiveTime;
        public long idleTime;
        public int sessionCount;
        public double productivityScore;
        
        public String getFormattedDate() {
            return date.format(DISPLAY_DATE_FORMAT);
        }
    }

    public static class WeeklyBreakdown {
        public LocalDate weekStart;
        public LocalDate weekEnd;
        public long totalScreenTime;
        public double averageProductivityScore;
    }

    public static class SessionInfo {
        public int id;
        public LocalDateTime startTime;
        public LocalDateTime endTime;
        public long durationSeconds;
        
        public String getFormattedStart() {
            return startTime != null ? startTime.format(DateTimeFormatter.ofPattern("HH:mm")) : "N/A";
        }
        
        public String getFormattedEnd() {
            return endTime != null ? endTime.format(DateTimeFormatter.ofPattern("HH:mm")) : "Active";
        }
        
        public String getFormattedDuration() {
            if (durationSeconds == 0 && endTime == null) {
                return "Active";
            }
            return formatDuration(durationSeconds);
        }
    }

    public static class AppUsageInfo {
        public String name;
        public String category;
        public String color;
        public int sessionCount;
        public long totalSeconds;
        
        public String getFormattedTime() {
            return formatDuration(totalSeconds);
        }
        
        public double getHours() {
            return totalSeconds / 3600.0;
        }
    }

    public static class ComparisonReport {
        public PeriodSummary period1;
        public PeriodSummary period2;
        public double screenTimeChange;
        public double productivityChange;
        
        public String getScreenTimeChangeFormatted() {
            String direction = screenTimeChange > 0 ? "↑" : "↓";
            return String.format("%s %.1f%%", direction, Math.abs(screenTimeChange));
        }
        
        public String getProductivityChangeFormatted() {
            String direction = productivityChange > 0 ? "↑" : "↓";
            return String.format("%s %.1f points", direction, Math.abs(productivityChange));
        }
    }

    public static class PeriodSummary {
        public long totalScreenTime;
        public double averageProductivityScore;
        public int daysCount;
    }

    // Utility
    public static String formatDuration(long seconds) {
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        if (hours > 0) {
            return String.format("%dh %dm", hours, minutes);
        }
        return String.format("%dm", minutes);
    }
}
package com.deskwell.service;

import com.deskwell.database.DatabaseManager;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

public class SettingsService {
    private static final Logger logger = Logger.getLogger(SettingsService.class.getName());
    private final DatabaseManager databaseManager;

    public SettingsService(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
    }

    public String getSetting(String key, String defaultValue) {
        String sql = "SELECT value FROM settings WHERE key = ?";
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, key);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getString("value");
            }
        } catch (SQLException e) {
            logger.warning("Error getting setting: " + key);
        }
        return defaultValue;
    }

    public void setSetting(String key, String value) {
        String sql = """
            INSERT INTO settings (key, value) VALUES (?, ?)
            ON CONFLICT(key) DO UPDATE SET value = ?, updated_at = CURRENT_TIMESTAMP
            """;
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, key);
            pstmt.setString(2, value);
            pstmt.setString(3, value);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            logger.warning("Error setting: " + key);
        }
    }

    public Map<String, String> getAllSettings() {
        Map<String, String> settings = new HashMap<>();
        String sql = "SELECT key, value FROM settings";
        try (Statement stmt = databaseManager.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                settings.put(rs.getString("key"), rs.getString("value"));
            }
        } catch (SQLException e) {
            logger.warning("Error getting all settings");
        }
        return settings;
    }

    public void toggleTheme() {
        String current = getSetting("theme", "light");
        setSetting("theme", current.equals("light") ? "dark" : "light");
    }
}
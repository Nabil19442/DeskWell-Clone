package com.deskwell.service;

import com.deskwell.DeskWellApp;

import java.io.*;
import java.net.URISyntaxException;
import java.nio.file.*;
import java.util.logging.Logger;

public class StartupManager {
    private static final Logger logger = Logger.getLogger(StartupManager.class.getName());
    private final SettingsService settingsService;
    
    public StartupManager(SettingsService settingsService) {
        this.settingsService = settingsService;
    }

    public void setStartupWithWindows(boolean enable) {
        if (System.getProperty("os.name").toLowerCase().contains("win")) {
            setWindowsStartup(enable);
        } else if (System.getProperty("os.name").toLowerCase().contains("mac")) {
            setMacStartup(enable);
        } else {
            setLinuxStartup(enable);
        }
        
        settingsService.setSetting("startup_with_windows", String.valueOf(enable));
    }

    public boolean isStartupEnabled() {
        return Boolean.parseBoolean(settingsService.getSetting("startup_with_windows", "false"));
    }

    private void setWindowsStartup(boolean enable) {
        try {
            String userHome = System.getProperty("user.home");
            String startupPath = System.getenv("APPDATA") + 
                "\\Microsoft\\Windows\\Start Menu\\Programs\\Startup";
            
            File startupDir = new File(startupPath);
            File shortcut = new File(startupDir, "DeskWell.lnk");
            
            if (enable) {
                // Create shortcut using VBScript
                createWindowsShortcut(shortcut);
            } else {
                // Remove shortcut
                if (shortcut.exists()) {
                    shortcut.delete();
                }
            }
            
            logger.info("Windows startup " + (enable ? "enabled" : "disabled"));
            
        } catch (Exception e) {
            logger.warning("Error setting Windows startup: " + e.getMessage());
        }
    }

    private void createWindowsShortcut(File shortcut) throws IOException, URISyntaxException {
        File jarFile = new File(DeskWellApp.class.getProtectionDomain()
            .getCodeSource().getLocation().toURI());

        // When installed via jpackage the layout is:
        //   <installDir>\DeskWell.exe        <- native launcher, has its own bundled JRE
        //   <installDir>\app\DeskWell-app.jar
        //   <installDir>\runtime\...
        // Prefer launching that native exe directly so the startup shortcut
        // works even on machines with no system-wide Java installed, which
        // is the whole point of shipping a bundled runtime. Only fall back
        // to "javaw -jar ..." when running the raw jar outside an install
        // (e.g. during development), where a native exe won't exist.
        File installDir = jarFile.getParentFile() != null ? jarFile.getParentFile().getParentFile() : null;
        File nativeExe = installDir != null ? new File(installDir, "DeskWell.exe") : null;

        String targetPath;
        String argumentsLine;
        String workingDir;

        if (nativeExe != null && nativeExe.exists()) {
            targetPath = nativeExe.getAbsolutePath();
            argumentsLine = "Shortcut.Arguments = \"\"\n";
            workingDir = installDir.getAbsolutePath();
        } else {
            targetPath = "javaw";
            argumentsLine = "Shortcut.Arguments = \"-jar \\\"" + jarFile.getAbsolutePath() + "\\\"\"\n";
            workingDir = jarFile.getParent();
        }

        String vbScript = 
            "Set WshShell = WScript.CreateObject(\"WScript.Shell\")\n" +
            "Set Shortcut = WshShell.CreateShortcut(\"" + shortcut.getAbsolutePath() + "\")\n" +
            "Shortcut.TargetPath = \"" + targetPath + "\"\n" +
            argumentsLine +
            "Shortcut.WorkingDirectory = \"" + workingDir + "\"\n" +
            "Shortcut.Description = \"DeskWell - Digital Wellbeing\"\n" +
            "Shortcut.IconLocation = \"shell32.dll,13\"\n" +
            "Shortcut.Save\n";
        
        File vbsFile = File.createTempFile("deskwell_shortcut_", ".vbs");
        Files.write(vbsFile.toPath(), vbScript.getBytes());
        
        try {
            Process process = Runtime.getRuntime().exec(
                new String[]{"wscript", vbsFile.getAbsolutePath()}
            );
            process.waitFor();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            vbsFile.delete();
        }
    }

    private void setMacStartup(boolean enable) {
        try {
            String userHome = System.getProperty("user.home");
            Path launchAgentsDir = Paths.get(userHome, "Library", "LaunchAgents");
            Files.createDirectories(launchAgentsDir);
            
            Path plistFile = launchAgentsDir.resolve("com.deskwell.app.plist");
            
            if (enable) {
                String plistContent = """
                    <?xml version="1.0" encoding="UTF-8"?>
                    <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" 
                    "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
                    <plist version="1.0">
                    <dict>
                        <key>Label</key>
                        <string>com.deskwell.app</string>
                        <key>ProgramArguments</key>
                        <array>
                            <string>java</string>
                            <string>-jar</string>
                            <string>/Applications/DeskWell.jar</string>
                        </array>
                        <key>RunAtLoad</key>
                        <true/>
                    </dict>
                    </plist>
                    """;
                
                Files.writeString(plistFile, plistContent);
            } else {
                Files.deleteIfExists(plistFile);
            }
            
        } catch (IOException e) {
            logger.warning("Error setting Mac startup: " + e.getMessage());
        }
    }

    private void setLinuxStartup(boolean enable) {
        try {
            String userHome = System.getProperty("user.home");
            Path autostartDir = Paths.get(userHome, ".config", "autostart");
            Files.createDirectories(autostartDir);
            
            Path desktopFile = autostartDir.resolve("deskwell.desktop");
            
            if (enable) {
                String desktopContent = """
                    [Desktop Entry]
                    Type=Application
                    Name=DeskWell
                    Exec=java -jar /opt/deskwell/DeskWell.jar
                    StartupNotify=false
                    Terminal=false
                    """;
                
                Files.writeString(desktopFile, desktopContent);
                desktopFile.toFile().setExecutable(true);
            } else {
                Files.deleteIfExists(desktopFile);
            }
            
        } catch (IOException e) {
            logger.warning("Error setting Linux startup: " + e.getMessage());
        }
    }
}
package com.deskwell.service;

import javafx.application.Platform;
import javafx.scene.Scene;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class ThemeManager {
    private static final Logger logger = Logger.getLogger(ThemeManager.class.getName());
    private static ThemeManager instance;
    private final SettingsService settingsService;
    private final List<Scene> registeredScenes = new ArrayList<>();
    
    private static final String LIGHT_THEME = "/styles/light-theme.css";
    private static final String DARK_THEME = "/styles/dark-theme.css";
    private static final String MAIN_CSS = "/styles/main.css";

    private ThemeManager(SettingsService settingsService) {
        this.settingsService = settingsService;
    }

    public static synchronized ThemeManager getInstance(SettingsService settingsService) {
        if (instance == null) {
            instance = new ThemeManager(settingsService);
        }
        return instance;
    }

    public void registerScene(Scene scene) {
        registeredScenes.add(scene);
        applyCurrentTheme(scene);
    }

    public void applyCurrentTheme(Scene scene) {
        String theme = settingsService.getSetting("theme", "light");
        applyTheme(scene, theme);
    }

    public void toggleTheme() {
        String currentTheme = settingsService.getSetting("theme", "light");
        String newTheme = currentTheme.equals("light") ? "dark" : "light";
        settingsService.setSetting("theme", newTheme);
        
        // Apply to all registered scenes
        for (Scene scene : registeredScenes) {
            applyTheme(scene, newTheme);
        }
        
        logger.info("Theme switched to: " + newTheme);
    }

    public void setTheme(String theme) {
        if (!theme.equals("light") && !theme.equals("dark")) {
            throw new IllegalArgumentException("Theme must be 'light' or 'dark'");
        }
        
        settingsService.setSetting("theme", theme);
        
        for (Scene scene : registeredScenes) {
            applyTheme(scene, theme);
        }
    }

    private void applyTheme(Scene scene, String theme) {
        Platform.runLater(() -> {
            // Remove existing theme stylesheets
            scene.getStylesheets().removeIf(style -> 
                style.contains("light-theme") || style.contains("dark-theme")
            );
            
            // Add new theme
            String themePath = theme.equals("dark") ? DARK_THEME : LIGHT_THEME;
            
            if (!scene.getStylesheets().contains(themePath)) {
                scene.getStylesheets().add(
                    getClass().getResource(themePath).toExternalForm()
                );
            }
            
            if (!scene.getStylesheets().contains(MAIN_CSS)) {
                scene.getStylesheets().add(
                    getClass().getResource(MAIN_CSS).toExternalForm()
                );
            }
            
            // Force refresh
            scene.getRoot().applyCss();
            scene.getRoot().layout();
        });
    }

    public String getCurrentTheme() {
        return settingsService.getSetting("theme", "light");
    }

    public boolean isDarkMode() {
        return "dark".equals(getCurrentTheme());
    }
}
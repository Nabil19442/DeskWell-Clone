package com.deskwell.tracker;

import com.deskwell.database.DatabaseManager;
import com.deskwell.model.TrackedApplication;
import com.deskwell.service.AppBlockerService;
import com.deskwell.service.CategoryService;
import com.deskwell.service.SettingsService;
import com.sun.jna.Native;
import com.sun.jna.Platform;
import com.sun.jna.platform.win32.*;
import com.sun.jna.ptr.IntByReference;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.*;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class ActivityTracker {
    private static final Logger logger = Logger.getLogger(ActivityTracker.class.getName());
    private final DatabaseManager databaseManager;
    private final CategoryService categoryService;
    private SettingsService settingsService;
    private final ScheduledExecutorService scheduler;
    private AppBlockerService appBlockerService;
    private ScheduledFuture<?> pollingTaskHandle;
    private final List<TrackerListener> listeners = new CopyOnWriteArrayList<>();
    
    private TrackedApplication currentApp;
    private LocalDateTime currentAppStartTime;
    // Accumulated seconds the *currently open* usage_tracking row has
    // actually been active, built up one polling tick at a time (see
    // tickCurrentApp()). This - not a wall-clock timestamp difference - is
    // what gets persisted as the row's duration_seconds. Using the
    // accumulated value means a long gap where the polling thread itself
    // didn't run (the machine was asleep/hibernating) can never leak into a
    // persisted duration, because nothing was ever added to this field
    // during that gap.
    private long currentAppElapsedSeconds = 0;
    private int currentSessionId;
    private LocalDateTime lastActivityTime;
    private LocalDateTime sessionStartTime;
    private boolean isRunning = false;
    private boolean isIdle = false;
    private long totalIdleTimeToday = 0;
    private long totalScreenTimeToday = 0;
    // The calendar day the in-memory totals above belong to. Checked every
    // poll (see checkDayRollover()) so that crossing midnight while the app
    // keeps running in the tray resets today's counters and starts a fresh
    // usage_tracking row for the new day, instead of the new day silently
    // inheriting (and continuing to add to) the previous day's numbers.
    private volatile LocalDate currentTrackingDate;
    // Wall-clock time of the last completed poll, used only to detect sleep
    // /hibernate (see handleWakeFromSleep()) - not for any duration math.
    private volatile long lastPollEpochMillis = 0;
    
    // These used to be hardcoded constants, which meant the "Tracking
    // Frequency" and "Idle Detection" spinners in Settings had no effect at
    // all on actual tracking behavior. They're now mutable and loaded from
    // (and persisted to) SettingsService, and setPollingInterval() /
    // setIdleThreshold() below let the Settings screen change them live.
    private volatile int POLLING_INTERVAL_SECONDS = 3;
    private volatile int IDLE_THRESHOLD_SECONDS = 60;
    private static final int SESSION_END_THRESHOLD_MINUTES = 30;
    private static final int DAILY_STATS_UPDATE_INTERVAL = 30;
    // If the gap between two consecutive polls is bigger than this, the
    // polling thread itself was suspended rather than the user merely being
    // idle - i.e. the PC went to sleep/hibernated. Idle detection
    // (IDLE_THRESHOLD_SECONDS / getIdleTimeSeconds()) alone can't tell these
    // apart: GetLastInputInfo happily reports a multi-hour idle gap for
    // "away for lunch" just as it would for "asleep overnight". Comparing
    // actual poll-to-poll wall-clock time against the configured interval
    // does, and lets us exclude real sleep time from both screen time and
    // idle time entirely, per product requirement.
    private static final int SLEEP_GAP_THRESHOLD_SECONDS = 120;
    private static final int DAY_ROLLOVER_CHECK_INTERVAL_SECONDS = 20;
    // Process name used for the synthetic placeholder TrackedApplication
    // created by handleIdleState() while the user is away from keyboard.
    // It exists purely so the UI (e.g. the "Current Application" card) has
    // something to display during idle stretches - it is NEVER written to
    // usage_tracking (see saveAppUsageStart()/endCurrentAppUsage()). Idle
    // time is already tracked and persisted on its own via
    // totalIdleTimeToday / daily_stats.idle_time; if it were also inserted
    // into usage_tracking as if it were a real app, every downstream reader
    // of that table (Category Breakdown, Hourly Activity, Most Used Apps,
    // Reports, CSV/PDF exports) would pick it up under the "Other" category
    // (nothing in CategoryService's keyword list matches "Idle") and its
    // totals would balloon past the dashboard's "Screen Time Today" figure,
    // which deliberately excludes idle time - exactly the mismatch users
    // reported between the two.
    private static final String IDLE_APP_NAME = "Idle";
    
    // Track application usage statistics in memory for quick access
    private final Map<String, AppUsageStats> appUsageMap = new ConcurrentHashMap<>();
    private final Map<Integer, HourlyStats> hourlyStatsMap = new ConcurrentHashMap<>();

    public ActivityTracker(DatabaseManager databaseManager, CategoryService categoryService) {
        this.databaseManager = databaseManager;
        this.categoryService = categoryService;
        this.scheduler = Executors.newScheduledThreadPool(3);
    }
    public void setAppBlockerService(AppBlockerService appBlockerService) {
    this.appBlockerService = appBlockerService;
    }

    public void setSettingsService(SettingsService settingsService) {
        this.settingsService = settingsService;
        loadTrackingSettings();
    }

    private void loadTrackingSettings() {
        if (settingsService == null) return;
        try {
            POLLING_INTERVAL_SECONDS = Integer.parseInt(
                settingsService.getSetting("tracking_frequency_seconds", String.valueOf(POLLING_INTERVAL_SECONDS)));
            IDLE_THRESHOLD_SECONDS = Integer.parseInt(
                settingsService.getSetting("idle_threshold_seconds", String.valueOf(IDLE_THRESHOLD_SECONDS)));
        } catch (NumberFormatException e) {
            logger.warning("Invalid tracking settings stored, using defaults: " + e.getMessage());
        }
    }

    public void start() {
        if (!isRunning) {
            isRunning = true;
            loadTrackingSettings();
            currentTrackingDate = LocalDate.now();
            lastPollEpochMillis = System.currentTimeMillis();
            loadTodayStats();
            startNewSession();
            lastActivityTime = LocalDateTime.now();
            
            // Main tracking thread - polls active window
            pollingTaskHandle = scheduler.scheduleAtFixedRate(
                this::pollActiveWindow,
                0,
                POLLING_INTERVAL_SECONDS,
                TimeUnit.SECONDS
            );
            
            // Daily stats updater
            scheduler.scheduleAtFixedRate(
                this::updateDailyStats,
                DAILY_STATS_UPDATE_INTERVAL,
                DAILY_STATS_UPDATE_INTERVAL,
                TimeUnit.SECONDS
            );
            
            // Session check thread - checks for session end conditions
            scheduler.scheduleAtFixedRate(
                this::checkSessionStatus,
                60,
                60,
                TimeUnit.SECONDS
            );

            // Day-rollover check - catches the app running right through
            // midnight (e.g. minimized to tray overnight) and resets
            // today's counters/opens a fresh usage row for the new day.
            // See checkDayRollover().
            scheduler.scheduleAtFixedRate(
                this::checkDayRollover,
                DAY_ROLLOVER_CHECK_INTERVAL_SECONDS,
                DAY_ROLLOVER_CHECK_INTERVAL_SECONDS,
                TimeUnit.SECONDS
            );

            // Periodically fold the WAL file back into deskwell.db so that
            // recently-tracked days are visible even if the app is ever
            // killed abnormally (crash, power loss, task-killed) instead of
            // shut down through the tray's "Exit" (which already checkpoints
            // - see DatabaseManager.close()).
            scheduler.scheduleAtFixedRate(
                databaseManager::checkpoint,
                300,
                300,
                TimeUnit.SECONDS
            );
            
            notifyListeners("started");
            logger.info("Activity tracker started with enhanced tracking");
        }
    }

    public void stop() {
        if (isRunning) {
            isRunning = false;
            endCurrentAppUsage();
            endCurrentSession();
            updateDailyStats();
            scheduler.shutdown();
            notifyListeners("stopped");
            logger.info("Activity tracker stopped");
        }
    }

    private void loadTodayStats() {
        // Reset first: if there's no daily_stats row for today (e.g. right
        // after "Clear All Data" in Settings), the previous in-memory totals
        // must not be left behind - otherwise the dashboard keeps showing
        // stale numbers until the app is restarted.
        totalScreenTimeToday = 0;
        totalIdleTimeToday = 0;
        
        String sql = """
            SELECT total_screen_time, idle_time 
            FROM daily_stats 
            WHERE date = ?
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, LocalDate.now().toString());
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                totalScreenTimeToday = rs.getLong("total_screen_time");
                totalIdleTimeToday = rs.getLong("idle_time");
            }
            
            // Load today's app usage
            loadTodayAppUsage();
            loadHourlyStats();
            
        } catch (SQLException e) {
            logger.warning("Error loading today stats: " + e.getMessage());
        }
    }

    // Uses the JVM's local LocalDate.now(), bound as a parameter, rather
    // than SQLite's own date('now'). SQLite's date('now') is always UTC,
    // but every timestamp this app writes (start_time/end_time) is a naive
    // local wall-clock value from Java's LocalDateTime.now(). For anyone
    // not on UTC (e.g. UTC+6), there's a several-hour window every day
    // (right after local midnight, while UTC's date hasn't rolled over yet)
    // where date('now') and the local "today" disagree - so this query
    // would silently match zero rows and the dashboard's "Most Used Apps"
    // would look empty/stuck, even though usage_tracking rows for today
    // exist and Reports (which already bind LocalDate.now() explicitly)
    // shows them fine.
    private void loadTodayAppUsage() {
        String sql = """
            SELECT a.name, a.id, SUM(ut.duration_seconds) as total_time,
                   c.name as category, c.color
            FROM usage_tracking ut
            JOIN applications a ON ut.application_id = a.id
            LEFT JOIN categories c ON a.category_id = c.id
            WHERE date(ut.start_time) = ?
            GROUP BY a.id
            ORDER BY total_time DESC
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, LocalDate.now().toString());
            ResultSet rs = pstmt.executeQuery();
            
            appUsageMap.clear();
            while (rs.next()) {
                AppUsageStats stats = new AppUsageStats();
                stats.appId = rs.getInt("id");
                stats.appName = rs.getString("name");
                stats.totalSeconds = rs.getLong("total_time");
                stats.category = rs.getString("category");
                stats.color = rs.getString("color");
                appUsageMap.put(stats.appName, stats);
            }
        } catch (SQLException e) {
            logger.warning("Error loading app usage: " + e.getMessage());
        }
    }

    // Same local-date-vs-UTC fix as loadTodayAppUsage() above.
    private void loadHourlyStats() {
        String sql = """
            SELECT CAST(strftime('%H', start_time) AS INTEGER) as hour,
                   SUM(duration_seconds) as total_time
            FROM usage_tracking
            WHERE date(start_time) = ?
            GROUP BY hour
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, LocalDate.now().toString());
            ResultSet rs = pstmt.executeQuery();
            
            hourlyStatsMap.clear();
            while (rs.next()) {
                HourlyStats stats = new HourlyStats();
                stats.hour = rs.getInt("hour");
                stats.totalSeconds = rs.getLong("total_time");
                hourlyStatsMap.put(stats.hour, stats);
            }
        } catch (SQLException e) {
            logger.warning("Error loading hourly stats: " + e.getMessage());
        }
    }

    // pollActiveWindow(), updateDailyStats() and checkSessionStatus() are all
    // scheduled independently on a 3-thread pool, but they read/write the
    // same in-memory fields (currentApp, currentSessionId, totalScreenTimeToday,
    // ...) and the same shared SQLite Connection from DatabaseManager. Running
    // them concurrently was a source of intermittent, hard-to-reproduce
    // database errors ("database is locked" / corrupted-looking stats) since
    // neither the JDBC connection nor these fields were protected against
    // concurrent access. Synchronizing on the tracker instance serializes the
    // three periodic jobs against each other so only one touches the DB/state
    // at a time, without slowing down normal use (each run is a few
    // millisecond).
    private synchronized void pollActiveWindow() {
        try {
            if (!isRunning) return;

            long nowMillis = System.currentTimeMillis();
            if (lastPollEpochMillis > 0) {
                long gapSeconds = (nowMillis - lastPollEpochMillis) / 1000;
                int sleepThreshold = Math.max(SLEEP_GAP_THRESHOLD_SECONDS, POLLING_INTERVAL_SECONDS * 10);
                if (gapSeconds > sleepThreshold) {
                    // The gap between this poll and the last one is far
                    // bigger than the configured interval, which means this
                    // scheduled task was itself suspended - the machine was
                    // asleep/hibernating - rather than merely idle. Exclude
                    // the whole gap from tracking entirely (neither screen
                    // time nor idle time) and start clean from now, instead
                    // of letting it inflate either counter or the currently
                    // open usage row's duration.
                    handleWakeFromSleep();
                    lastPollEpochMillis = nowMillis;
                    return;
                }
            }
            lastPollEpochMillis = nowMillis;

            TrackedApplication newApp = getActiveWindow();
            if (appBlockerService != null && appBlockerService.isAppBlocked(newApp.getProcessName())) {
               // App is blocked, don't track it and show notification
                notifyListeners("app_blocked");
                return;
            }
            long idleTime = getIdleTimeSeconds();
            
            if (idleTime > IDLE_THRESHOLD_SECONDS) {
                if (!isIdle) {
                    handleIdleState(idleTime);
                } else {
                    // Already idle - keep accumulating idle time for as long
                    // as the idle period continues. Previously this only got
                    // added once (the moment idle was first detected), so
                    // long idle stretches were massively under-counted.
                    totalIdleTimeToday += POLLING_INTERVAL_SECONDS;
                    currentAppElapsedSeconds += POLLING_INTERVAL_SECONDS;
                }
            } 
            else {
                // Only count this tick as screen time when the user is
                // actually not idle this tick (moved out of the unconditional
                // increment above it used to be under, which counted the
                // very tick idleness first crosses the threshold as screen
                // time too).
                totalScreenTimeToday += POLLING_INTERVAL_SECONDS;

                if (isIdle) {
                    // Coming back from idle
                    isIdle = false;
                    lastActivityTime = LocalDateTime.now();
                    notifyListeners("active");
                }
                
                if (currentApp == null || !currentApp.equals(newApp)) {
                    // Application changed
                    handleAppChange(newApp);
                } else {
                    // Same app, update duration
                    updateCurrentAppDuration();
                }
            }
            
        } catch (Exception e) {
            logger.warning("Error polling active window: " + e.getMessage());
        }
    }

    /**
     * Called when a poll-to-poll gap far larger than the tracking interval
     * is detected, meaning the machine was asleep/hibernating in between.
     * Closes out whatever was open using only time actually accumulated
     * while awake (never a wall-clock difference spanning the sleep), and
     * resets to a clean slate so the next poll starts fresh - the sleep
     * duration itself is counted as neither screen time nor idle time.
     */
    private void handleWakeFromSleep() {
        logger.info("Detected system sleep/hibernate gap - excluding it from tracking");
        endCurrentAppUsage();
        isIdle = false;
        lastActivityTime = LocalDateTime.now();
        notifyListeners("resumed_from_sleep");
    }

    /**
     * Detects the in-memory "today" totals crossing into a new calendar
     * day - which happens whenever the app is left running (e.g. minimized
     * to the tray) across midnight - and rolls them over: finalizes and
     * persists the outgoing day's numbers, resets every in-memory
     * accumulator to zero, and (if something was actively being tracked)
     * opens a fresh usage row for the new day so tracking continues
     * seamlessly instead of the new day silently starting from whatever
     * total the previous day happened to reach.
     */
    private synchronized void checkDayRollover() {
        if (!isRunning) return;
        LocalDate today = LocalDate.now();
        if (currentTrackingDate == null) {
            currentTrackingDate = today;
            return;
        }
        if (today.equals(currentTrackingDate)) return;

        LocalDate outgoingDate = currentTrackingDate;
        logger.info("Day rollover: finalizing " + outgoingDate + " and starting " + today);

        TrackedApplication appToResume = (!isIdle) ? currentApp : null;

        // Close out the outgoing day's open session/app-usage rows and
        // persist its final totals under its own date - not date('now'),
        // which would already be "today" by this point.
        endCurrentAppUsage();
        endCurrentSession();
        updateDailyStats(outgoingDate);

        // Reset every in-memory accumulator for the new day.
        totalScreenTimeToday = 0;
        totalIdleTimeToday = 0;
        appUsageMap.clear();
        hourlyStatsMap.clear();
        currentTrackingDate = today;

        startNewSession();

        // If something was actively in the foreground right at the moment
        // of rollover, keep tracking it without a gap under the new day.
        if (appToResume != null) {
            currentApp = appToResume;
            currentAppStartTime = LocalDateTime.now();
            currentAppElapsedSeconds = 0;
            saveAppUsageStart(appToResume);
            appUsageMap.computeIfAbsent(
                appToResume.getProcessName(),
                k -> {
                    AppUsageStats s = new AppUsageStats();
                    s.appName = k;
                    s.appId = getOrCreateApplication(appToResume);
                    s.category = categoryService.getCategoryForApp(s.appId);
                    return s;
                }
            );
        }

        notifyListeners("new_day");
    }

    private void handleAppChange(TrackedApplication newApp) {
        // End previous app usage
        if (currentApp != null) {
            // The outgoing app was still active for this last polling
            // interval right up until the switch was detected, but that
            // slice was never added to the in-memory stats (only the
            // "same app" branch in pollActiveWindow did that). Without this,
            // every app switch silently dropped up to POLLING_INTERVAL_SECONDS
            // of usage from the dashboard/pie chart totals.
            tickCurrentApp(POLLING_INTERVAL_SECONDS);
            endCurrentAppUsage();
        }
        
        // Start new app tracking
        currentApp = newApp;
        currentAppStartTime = LocalDateTime.now();
        currentAppElapsedSeconds = 0;
        saveAppUsageStart(newApp);
        
        // Update in-memory stats
        AppUsageStats stats = appUsageMap.computeIfAbsent(
            newApp.getProcessName(), 
            k -> {
                AppUsageStats s = new AppUsageStats();
                s.appName = k;
                s.appId = getOrCreateApplication(newApp);
                s.category = categoryService.getCategoryForApp(s.appId);
                return s;
            }
        );
        
        // Update hourly stats
        int currentHour = LocalTime.now().getHour();
        HourlyStats hourlyStats = hourlyStatsMap.computeIfAbsent(
            currentHour,
            k -> {
                HourlyStats hs = new HourlyStats();
                hs.hour = k;
                return hs;
            }
        );
        
        notifyListeners("app_changed");
    }

    private void updateCurrentAppDuration() {
        if (currentApp != null && currentAppStartTime != null) {
            tickCurrentApp(POLLING_INTERVAL_SECONDS);

            // Keep the still-open usage_tracking row's duration_seconds in
            // sync on every poll (not just when the app is switched away
            // from / the tracker stops). Without this, duration_seconds for
            // the in-progress row stays at its default of 0 the whole time
            // the user is on the same app, so any SQL that reads it directly
            // (ChartService's pie/hourly charts, ReportService, CSVExporter,
            // PDFExporter) sees no/stale data until the app is switched.
            //
            // Uses the accumulated per-poll total (currentAppElapsedSeconds),
            // not a wall-clock difference from currentAppStartTime - a
            // wall-clock diff would silently include any sleep/hibernate gap
            // that happened while this same app stayed in the foreground
            // across the suspend, wrongly counting the whole sleep duration
            // as screen time for this app once persisted.
            updateOpenUsageRowDuration(currentAppElapsedSeconds);
        }
    }

    /**
     * Adds one polling tick's worth of time to the currently active app: the
     * in-memory per-app total, the current hour's bucket, and the running
     * elapsed-seconds counter for the open usage_tracking row. Centralizing
     * this (instead of duplicating the three increments at every call site)
     * is what lets endCurrentAppUsage()/updateOpenUsageRowDuration() persist
     * a duration that can only ever reflect ticks that actually happened
     * while the tracker was polling - never a suspended/sleeping gap.
     */
    private void tickCurrentApp(long seconds) {
        if (currentApp == null) return;

        AppUsageStats stats = appUsageMap.get(currentApp.getProcessName());
        if (stats != null) {
            stats.totalSeconds += seconds;
        }

        int hour = LocalTime.now().getHour();
        HourlyStats hourlyStats = hourlyStatsMap.get(hour);
        if (hourlyStats != null) {
            hourlyStats.totalSeconds += seconds;
        }

        currentAppElapsedSeconds += seconds;
    }

    /**
     * Updates duration_seconds on the currently open usage_tracking row for
     * the active app/session, without closing it out. This is a live
     * heartbeat, not a new row: the WHERE clause targets the same
     * end_time IS NULL row that saveAppUsageStart() created, so repeated
     * calls just UPDATE that one row in place instead of inserting
     * duplicates.
     *
     * Note: end_time is deliberately left untouched here (it stays NULL).
     * end_time IS NULL is the sentinel this same query - and the finalize
     * query in updateAppUsageEndTime() - use to find "the" open row; if a
     * heartbeat set end_time early, the very next heartbeat (and the real
     * end-of-usage update on app switch) would no longer be able to find
     * the row to update.
     */
    private void updateOpenUsageRowDuration(long durationSeconds) {
        if (currentApp == null || currentSessionId <= 0) return;
        
        String sql = """
            UPDATE usage_tracking
            SET duration_seconds = ?
            WHERE id = (
                SELECT id FROM usage_tracking
                WHERE session_id = ? AND application_id = (
                    SELECT id FROM applications WHERE name = ?
                ) AND end_time IS NULL
                ORDER BY start_time DESC LIMIT 1
            )
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setLong(1, durationSeconds);
            pstmt.setInt(2, currentSessionId);
            pstmt.setString(3, currentApp.getProcessName());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            logger.warning("Error updating open usage row duration: " + e.getMessage());
        }
    }

    private TrackedApplication getActiveWindow() {
        try {
            if (!Platform.isWindows()) {
                return getGenericActiveWindow();
            }

            char[] windowText = new char[512];
            char[] className = new char[256];
            
            WinDef.HWND hwnd = User32.INSTANCE.GetForegroundWindow();
            
            if (hwnd == null) {
                return new TrackedApplication("Desktop", "Desktop", "Desktop");
            }
            
            User32.INSTANCE.GetWindowText(hwnd, windowText, 512);
            User32.INSTANCE.GetClassName(hwnd, className, 256);
            
            IntByReference processId = new IntByReference();
            User32.INSTANCE.GetWindowThreadProcessId(hwnd, processId);
            
            String windowTitle = Native.toString(windowText);
            String classNameStr = Native.toString(className);
            
            // Get detailed process information
            ProcessInfo processInfo = getProcessInfo(processId.getValue());
            
            return new TrackedApplication(
                processInfo.processName,
                windowTitle.isEmpty() ? processInfo.processName : windowTitle,
                classNameStr,
                processInfo.executablePath
            );
            
        } catch (Exception e) {
            logger.warning("Error getting active window: " + e.getMessage());
            return new TrackedApplication("Unknown", "Unknown", "Unknown", "");
        }
    }

    private ProcessInfo getProcessInfo(int processId) {
        ProcessInfo info = new ProcessInfo();
        info.processId = processId;
        
        WinNT.HANDLE processHandle = Kernel32.INSTANCE.OpenProcess(
            Kernel32.PROCESS_QUERY_INFORMATION | Kernel32.PROCESS_VM_READ,
            false,
            processId
        );
        
        if (processHandle != null) {
            try {
                char[] exePath = new char[2048];
                IntByReference size = new IntByReference(exePath.length);
                
                if (Kernel32.INSTANCE.QueryFullProcessImageName(
                    processHandle, 0, exePath, size)) {
                    String fullPath = Native.toString(exePath);
                    info.executablePath = fullPath;
                    info.processName = fullPath.substring(fullPath.lastIndexOf('\\') + 1);
                }
                
                // Get process times for CPU usage
                Kernel32.FILETIME creationTime = new Kernel32.FILETIME();
                Kernel32.FILETIME exitTime = new Kernel32.FILETIME();
                Kernel32.FILETIME kernelTime = new Kernel32.FILETIME();
                Kernel32.FILETIME userTime = new Kernel32.FILETIME();
                
                if (Kernel32.INSTANCE.GetProcessTimes(
                    processHandle, creationTime, exitTime, kernelTime, userTime)) {
                    // Convert FILETIME to milliseconds
                    long kernelMillis = kernelTime.toTime() / 10000;
                    long userMillis = userTime.toTime() / 10000;
                    info.cpuTimeMs = kernelMillis + userMillis;
                }
            } finally {
                Kernel32.INSTANCE.CloseHandle(processHandle);
            }
        }
        
        if (info.processName == null) {
            info.processName = "Unknown";
        }
        
        return info;
    }

    private TrackedApplication getGenericActiveWindow() {
        try {
            Process process = Runtime.getRuntime().exec(
                new String[]{"xdotool", "getactivewindow", "getwindowname"}
            );
            java.io.BufferedReader reader = new java.io.BufferedReader(
                new java.io.InputStreamReader(process.getInputStream())
            );
            String windowTitle = reader.readLine();
            process.waitFor();
            
            return new TrackedApplication("Unknown", 
                windowTitle != null ? windowTitle : "Desktop", "Unknown", "");
        } catch (Exception e) {
            return new TrackedApplication("Unknown", "Desktop", "Unknown", "");
        }
    }

    private long getIdleTimeSeconds() {
        try {
            if (!Platform.isWindows()) {
                return 0;
            }
            
            WinUser.LASTINPUTINFO lastInputInfo = new WinUser.LASTINPUTINFO();
            lastInputInfo.cbSize = lastInputInfo.size();
            
            if (User32.INSTANCE.GetLastInputInfo(lastInputInfo)) {
                int idleMillis = Kernel32.INSTANCE.GetTickCount() - lastInputInfo.dwTime;
                return idleMillis / 1000;
            }
        } catch (Exception e) {
            logger.warning("Error getting idle time: " + e.getMessage());
        }
        return 0;
    }

    private void handleIdleState(long idleTime) {
        if (!isIdle) {
            isIdle = true;
            totalIdleTimeToday += idleTime;
            
            // End current app usage when going idle
            if (currentApp != null) {
                endCurrentAppUsage();
                currentApp = new TrackedApplication(IDLE_APP_NAME, "System Idle", "Idle", "");
                currentAppStartTime = LocalDateTime.now().minusSeconds(idleTime);
                // idleTime here is a genuine "away from keyboard but the PC
                // stayed awake" gap (getIdleTimeSeconds()/GetLastInputInfo),
                // as opposed to a sleep/hibernate gap (handled separately by
                // handleWakeFromSleep()), so it's legitimate to seed the
                // elapsed counter with it up front.
                currentAppElapsedSeconds = idleTime;
                // Deliberately NOT calling saveAppUsageStart() here - see
                // IDLE_APP_NAME. currentApp/currentAppStartTime/
                // currentAppElapsedSeconds are still set purely so the UI
                // can show "System Idle" and so endCurrentAppUsage() has a
                // clean, no-op-for-Idle path once activity resumes.
            }
            
            notifyListeners("idle");
        }
    }

    private void startNewSession() {
        sessionStartTime = LocalDateTime.now();
        
        String sql = "INSERT INTO sessions (user_id, start_time) VALUES (1, ?)";
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, sessionStartTime.toString());
            pstmt.executeUpdate();
            
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                currentSessionId = rs.getInt(1);
            }
        } catch (SQLException e) {
            logger.severe("Error starting new session: " + e.getMessage());
        }
    }

    private void endCurrentSession() {
        if (currentSessionId > 0) {
            long duration = ChronoUnit.SECONDS.between(sessionStartTime, LocalDateTime.now());
            
            String sql = "UPDATE sessions SET end_time = ?, is_active = 0, duration_seconds = ? WHERE id = ?";
            try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
                pstmt.setString(1, LocalDateTime.now().toString());
                pstmt.setLong(2, duration);
                pstmt.setInt(3, currentSessionId);
                pstmt.executeUpdate();
            } catch (SQLException e) {
                logger.severe("Error ending session: " + e.getMessage());
            }
        }
    }

    private synchronized void checkSessionStatus() {
        if (!isRunning) return;
        
        // Check if session should be ended due to long idle time
        if (isIdle && lastActivityTime != null) {
            long idleDuration = ChronoUnit.SECONDS.between(lastActivityTime, LocalDateTime.now());
            if (idleDuration > SESSION_END_THRESHOLD_MINUTES * 60) {
                endCurrentSession();
                startNewSession();
                notifyListeners("new_session");
            }
        }
    }

    private void saveAppUsageStart(TrackedApplication app) {
        if (IDLE_APP_NAME.equals(app.getProcessName())) {
            // Never persisted - see IDLE_APP_NAME.
            return;
        }
        int appId = getOrCreateApplication(app);
        
        String sql = """
            INSERT INTO usage_tracking (session_id, application_id, window_title, start_time)
            VALUES (?, ?, ?, ?)
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, currentSessionId);
            pstmt.setInt(2, appId);
            pstmt.setString(3, app.getWindowTitle());
            pstmt.setString(4, currentAppStartTime.toString());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            logger.severe("Error saving app usage start: " + e.getMessage());
        }
    }

    private void endCurrentAppUsage() {
        if (currentApp != null && currentAppStartTime != null) {
            LocalDateTime endTime = LocalDateTime.now();
            // Persist the accumulated per-poll total, not a wall-clock
            // difference between start and now: a wall-clock diff would
            // include any sleep/hibernate gap that happened while this app
            // (or the idle placeholder) was left "open", silently crediting
            // the sleep duration as tracked time once saved. See
            // currentAppElapsedSeconds / tickCurrentApp() / handleWakeFromSleep().
            long duration = currentAppElapsedSeconds;
            
            // Nothing was ever inserted into usage_tracking for the Idle
            // placeholder (see saveAppUsageStart()), so there is no open
            // row to close/update here either - see IDLE_APP_NAME.
            if (duration > 0 && !IDLE_APP_NAME.equals(currentApp.getProcessName())) {
                updateAppUsageEndTime(endTime, duration);
            }
        }
        currentApp = null;
        currentAppStartTime = null;
        currentAppElapsedSeconds = 0;
    }

    private void updateAppUsageEndTime(LocalDateTime endTime, long durationSeconds) {
        String sql = """
            UPDATE usage_tracking 
            SET end_time = ?, duration_seconds = ? 
            WHERE id = (
                SELECT id FROM usage_tracking
                WHERE session_id = ? AND application_id = (
                    SELECT id FROM applications WHERE name = ?
                ) AND end_time IS NULL
                ORDER BY start_time DESC LIMIT 1
            )
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, endTime.toString());
            pstmt.setLong(2, durationSeconds);
            pstmt.setInt(3, currentSessionId);
            pstmt.setString(4, currentApp.getProcessName());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            logger.severe("Error updating app usage end time: " + e.getMessage());
        }
    }

    private int getOrCreateApplication(TrackedApplication app) {
        String findSql = "SELECT id FROM applications WHERE name = ?";
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(findSql)) {
            pstmt.setString(1, app.getProcessName());
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            logger.severe("Error finding application: " + e.getMessage());
        }

        String insertSql = "INSERT INTO applications (name, executable_path) VALUES (?, ?)";
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(insertSql)) {
            pstmt.setString(1, app.getProcessName());
            pstmt.setString(2, app.getExecutablePath());
            pstmt.executeUpdate();
            
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                int appId = rs.getInt(1);
                categoryService.autoCategorizeApplication(appId, app.getProcessName());
                return appId;
            }
        } catch (SQLException e) {
            logger.severe("Error creating application: " + e.getMessage());
        }
        
        return -1;
    }

    /** Periodic flush for "today" - see updateDailyStats(LocalDate) for the parameterized version used during day rollover. */
    private void updateDailyStats() {
        updateDailyStats(LocalDate.now());
    }

    /**
     * Persists total/idle/productive time for a specific date, rather than
     * always assuming SQLite's date('now'). That distinction matters at day
     * rollover: by the time we finalize the *outgoing* day's numbers,
     * date('now') has often already ticked over to the new day, so a
     * hardcoded date('now') would silently write the outgoing day's final
     * totals into the new day's row instead. Every subquery below is scoped
     * to the passed-in date explicitly via bind parameters.
     *
     * "Productive" time is a weighted sum (duration_seconds *
     * categories.productivity_weight), driven entirely by the
     * categories.productivity_weight column: only coding/IDE/compiler tools
     * (Development, weight 1.0) count toward it. Every other category -
     * office/design/AI tools (Productivity), Browser, Entertainment,
     * Communication (incl. social media) and Gaming - has weight 0.0 and
     * contributes nothing to productive time, even though those apps are
     * still tracked and shown under their own category - see
     * DatabaseManager.insertDefaultCategories().
     */
    private synchronized void updateDailyStats(LocalDate date) {
        String dateStr = date.toString();
        String sql = """
            INSERT INTO daily_stats (date, total_screen_time, idle_time, session_count,
                productive_time, productivity_score)
            VALUES (?, ?, ?, 
                (SELECT COUNT(*) FROM sessions WHERE date(start_time) = ?),
                (SELECT COALESCE(ROUND(SUM(ut.duration_seconds * c.productivity_weight)), 0) 
                 FROM usage_tracking ut 
                 JOIN applications a ON ut.application_id = a.id 
                 JOIN categories c ON a.category_id = c.id 
                 WHERE date(ut.start_time) = ?),
                CASE 
                    WHEN ? > 0 THEN 
                        ROUND(CAST((SELECT COALESCE(SUM(ut.duration_seconds * c.productivity_weight), 0) 
                         FROM usage_tracking ut 
                         JOIN applications a ON ut.application_id = a.id 
                         JOIN categories c ON a.category_id = c.id 
                         WHERE date(ut.start_time) = ?) AS REAL) / ? * 100, 2)
                    ELSE 0 
                END
            )
            ON CONFLICT(date) DO UPDATE SET 
                total_screen_time = excluded.total_screen_time,
                idle_time = excluded.idle_time,
                session_count = excluded.session_count,
                productive_time = excluded.productive_time,
                productivity_score = excluded.productivity_score
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, dateStr);
            pstmt.setLong(2, totalScreenTimeToday);
            pstmt.setLong(3, totalIdleTimeToday);
            pstmt.setString(4, dateStr);
            pstmt.setString(5, dateStr);
            pstmt.setLong(6, totalScreenTimeToday);
            pstmt.setString(7, dateStr);
            pstmt.setLong(8, totalScreenTimeToday);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            logger.warning("Error updating daily stats: " + e.getMessage());
        }
    }

    // Public API methods for real-time data
    public TrackedApplication getCurrentApplication() {
        return currentApp;
    }

    public long getTotalScreenTimeToday() {
        return totalScreenTimeToday;
    }

    public long getTotalIdleTimeToday() {
        return totalIdleTimeToday;
    }

    public long getActiveScreenTime() {
        return totalScreenTimeToday - totalIdleTimeToday;
    }

    public double getProductivityScore() {
        if (totalScreenTimeToday == 0) return 0;
        
        // Weighted by categories.productivity_weight: only coding/IDE/
        // compiler tools (Development) count toward this at all (weight
        // 1.0). Office/design/AI tools (Productivity), Browser,
        // Entertainment, Communication (incl. social media) and Gaming all
        // have weight 0.0, so time in those apps is tracked and shown under
        // their own category but never counted as productive - see
        // CategoryService.getProductivityWeight() and
        // DatabaseManager.insertDefaultCategories().
        double weightedProductiveTime = appUsageMap.values().stream()
            .mapToDouble(s -> s.totalSeconds * categoryService.getProductivityWeight(s.category))
            .sum();
        
        double percentage = (weightedProductiveTime / totalScreenTimeToday) * 100.0;
        // Round to 2 decimal places without dividing the value back down again
        // (previously this divided by 100 twice, so a real score of e.g. 75%
        // was returned as 0.75 and displayed on the dashboard as "1%").
        return Math.round(percentage * 100.0) / 100.0;
    }

    public Map<String, AppUsageStats> getAppUsageStats() {
        return new HashMap<>(appUsageMap);
    }

    public Map<Integer, HourlyStats> getHourlyStats() {
        return new HashMap<>(hourlyStatsMap);
    }

    public List<AppUsageStats> getTopApps(int limit) {
        return appUsageMap.values().stream()
            .sorted((a, b) -> Long.compare(b.totalSeconds, a.totalSeconds))
            .limit(limit)
            .collect(Collectors.toList());
    }

    public String getCurrentSessionDuration() {
        if (sessionStartTime == null) return "00:00:00";
        long seconds = ChronoUnit.SECONDS.between(sessionStartTime, LocalDateTime.now());
        return formatDuration(seconds);
    }

    public String getTodayScreenTimeFormatted() {
        return formatDuration(totalScreenTimeToday);
    }

    private String formatDuration(long seconds) {
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, secs);
    }

    public void addListener(TrackerListener listener) {
        listeners.add(listener);
    }

    public void removeListener(TrackerListener listener) {
        listeners.remove(listener);
    }

    private void notifyListeners(String event) {
    for (TrackerListener listener : listeners) {
        try {
            listener.onTrackerEvent(event, this);
        } catch (Exception e) {
            logger.warning("Error notifying listener: " + e.getMessage());
        }
    }
    }
    public boolean isRunning() {
        return isRunning;
    }

    /**
     * Reloads all in-memory stats (today's screen/idle time, per-app and
     * hourly maps) from the database. Used by Settings after "Clear All
     * Data" so the dashboard reflects the cleared state immediately instead
     * of showing stale numbers until the app restarts.
     */
    public void reloadStatsFromDatabase() {
        loadTodayStats();
    }

    public int getPollingIntervalSeconds() {
        return POLLING_INTERVAL_SECONDS;
    }

    public int getIdleThresholdSeconds() {
        return IDLE_THRESHOLD_SECONDS;
    }

    /**
     * Updates how often the active window is polled and reschedules the
     * polling task so the new interval takes effect immediately, instead of
     * only after an app restart.
     */
    public synchronized void setPollingIntervalSeconds(int seconds) {
        if (seconds <= 0 || seconds == POLLING_INTERVAL_SECONDS) return;
        POLLING_INTERVAL_SECONDS = seconds;
        if (settingsService != null) {
            settingsService.setSetting("tracking_frequency_seconds", String.valueOf(seconds));
        }
        if (isRunning && pollingTaskHandle != null) {
            pollingTaskHandle.cancel(false);
            pollingTaskHandle = scheduler.scheduleAtFixedRate(
                this::pollActiveWindow, 0, POLLING_INTERVAL_SECONDS, TimeUnit.SECONDS
            );
        }
    }

    public synchronized void setIdleThresholdSeconds(int seconds) {
        if (seconds <= 0) return;
        IDLE_THRESHOLD_SECONDS = seconds;
        if (settingsService != null) {
            settingsService.setSetting("idle_threshold_seconds", String.valueOf(seconds));
        }
    }

    public int getCurrentSessionId() {
        return currentSessionId;
    }

    // Inner classes
    public interface TrackerListener {
        void onTrackerEvent(String event, ActivityTracker tracker);
    }

    public static class AppUsageStats {
        public int appId;
        public String appName;
        public long totalSeconds;
        public String category;
        public String color;
        
        public String getFormattedDuration() {
            long hours = totalSeconds / 3600;
            long minutes = (totalSeconds % 3600) / 60;
            if (hours > 0) {
                return String.format("%dh %dm", hours, minutes);
            }
            return String.format("%dm", minutes);
        }
        
        public double getPercentageOfTotal(long totalScreenTime) {
            if (totalScreenTime == 0) return 0;
            return ((double) totalSeconds / totalScreenTime) * 100;
        }
    }

    public static class HourlyStats {
        public int hour;
        public long totalSeconds;
        
        public String getFormattedHour() {
            return String.format("%02d:00", hour);
        }
    }

    private static class ProcessInfo {
        String processName;
        String executablePath;
        int processId;
        long cpuTimeMs;
    }
}
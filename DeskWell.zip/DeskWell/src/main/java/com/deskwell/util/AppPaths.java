package com.deskwell.util;

import java.io.File;

/**
 * Central place for every writable folder DeskWell uses.
 *
 * When installed via jpackage, the app lives under "C:\Program Files\DeskWell",
 * which normal (non-admin) Windows users cannot write to. Any file DeskWell
 * creates at runtime (database, settings backup, exported reports) must
 * instead go under the current user's own folders.
 */
public final class AppPaths {
    private AppPaths() {}

    /** Per-user app data folder, e.g. C:\Users\<name>\AppData\Roaming\DeskWell */
    public static File getDataDir() {
        String appData = System.getenv("APPDATA");
        File dir = (appData != null && !appData.isBlank())
                ? new File(appData, "DeskWell")
                : new File(System.getProperty("user.home"), ".deskwell");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }

    /** Folder for exported reports, e.g. C:\Users\<name>\Documents\DeskWell */
    public static File getExportDir() {
        File dir = new File(System.getProperty("user.home"), "Documents" + File.separator + "DeskWell");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }
}

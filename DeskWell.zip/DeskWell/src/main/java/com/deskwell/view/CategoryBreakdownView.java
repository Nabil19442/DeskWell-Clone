package com.deskwell.view;

import com.deskwell.service.ChartService;
import com.deskwell.service.ChartService.CategoryStats;
import javafx.animation.*;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.util.Duration;

import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.Collectors;

public class CategoryBreakdownView {
    private final ChartService chartService;
    private VBox view;
    private VBox legendContainer;
    private StackPane chartContainer;
    private List<Arc> arcs = new ArrayList<>();
    private Timer refreshTimer;
    private boolean firstRender = true;
    
    private static final double CHART_SIZE = 200;
    private static final double RING_WIDTH = 40;
    
    // Category colors
    private static final Map<String, String> CATEGORY_COLORS = new LinkedHashMap<>();
    static {
        CATEGORY_COLORS.put("Productivity", "#4CAF50");
        CATEGORY_COLORS.put("Development", "#2196F3");
        CATEGORY_COLORS.put("Browser", "#FF9800");
        CATEGORY_COLORS.put("Entertainment", "#F44336");
        CATEGORY_COLORS.put("Communication", "#9C27B0");
        CATEGORY_COLORS.put("Gaming", "#795548");
        CATEGORY_COLORS.put("Other", "#607D8B");
    }

    public CategoryBreakdownView(ChartService chartService) {
        this.chartService = chartService;
        buildView();
        startAutoRefresh();
    }

    private void buildView() {
        view = new VBox(15);
        view.setAlignment(Pos.CENTER);
        
        // Donut chart
        chartContainer = new StackPane();
        chartContainer.setPrefSize(CHART_SIZE, CHART_SIZE);
        chartContainer.setMinSize(CHART_SIZE, CHART_SIZE);
        chartContainer.setMaxSize(CHART_SIZE, CHART_SIZE);
        // Clip to the container's own bounds so hover-scaled wedges never
        // bleed outside the widget (was causing the pie chart to overflow
        // onto the legend / neighboring cards).
        Rectangle clip = new Rectangle(CHART_SIZE, CHART_SIZE);
        clip.widthProperty().bind(chartContainer.widthProperty());
        clip.heightProperty().bind(chartContainer.heightProperty());
        chartContainer.setClip(clip);
        
        // Center circle for donut effect
        Circle centerCircle = new Circle(RING_WIDTH);
        centerCircle.setFill(Color.WHITE);
        centerCircle.getStyleClass().add("donut-center");
        
        // Center text
        VBox centerText = new VBox(2);
        centerText.setAlignment(Pos.CENTER);
        
        Label totalTimeLabel = new Label("Total");
        totalTimeLabel.getStyleClass().add("donut-label");
        
        Label timeValueLabel = new Label("0h");
        timeValueLabel.setId("totalTimeValue");
        timeValueLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
        
        centerText.getChildren().addAll(totalTimeLabel, timeValueLabel);
        
        chartContainer.getChildren().addAll(centerCircle, centerText);
        
        // Legend
        legendContainer = new VBox(8);
        legendContainer.setAlignment(Pos.CENTER);
        legendContainer.setPadding(new Insets(10, 0, 0, 0));
        
        view.getChildren().addAll(chartContainer, legendContainer);
        
        // Initial render
        updateChart();
    }

    private void updateChart() {
        Map<String, CategoryStats> categories = chartService.getCategoryBreakdown();
        
        // Filter out categories with 0 time
        List<CategoryStats> activeCategories = categories.values().stream()
            .filter(cat -> cat.totalSeconds > 0)
            .collect(Collectors.toList());
        
        if (activeCategories.isEmpty()) {
            showEmptyState();
            return;
        }
        
        long totalTime = activeCategories.stream()
            .mapToLong(cat -> cat.totalSeconds)
            .sum();
        
        // Update center text
        VBox centerText = (VBox) chartContainer.getChildren().get(1);
        Label timeValueLabel = (Label) centerText.getChildren().get(1);
        timeValueLabel.setText(formatDuration(totalTime));
        
        // Clear old arcs
        chartContainer.getChildren().removeIf(node -> node instanceof Arc);
        arcs.clear();
        
        // Calculate angles
        double startAngle = 90;
        for (CategoryStats category : activeCategories) {
            double percentage = category.getPercentage(totalTime);
            double arcLength = (percentage / 100.0) * 360;
            
            Arc arc = new Arc(
                CHART_SIZE / 2,
                CHART_SIZE / 2,
                CHART_SIZE / 2 - RING_WIDTH / 2,
                CHART_SIZE / 2 - RING_WIDTH / 2,
                startAngle,
                -arcLength
            );
            
            // Each wedge is a *partial* arc, so its bounding box only wraps
            // the drawn stroke and changes shape as arcLength/startAngle
            // vary between categories. Left managed, the StackPane
            // re-centers each wedge on its own shrinking/growing box
            // instead of leaving it on the shared ring path, which is what
            // made small-percentage wedges collapse toward the middle of
            // the donut instead of sitting on the circle - the "pie chart
            // overflow/mistake" reported by users. Unmanaging pins every
            // wedge to its real (CHART_SIZE/2, CHART_SIZE/2)-centered
            // geometry so they all sit correctly on the same ring.
            arc.setManaged(false);
            arc.setType(ArcType.OPEN);
            arc.setStrokeWidth(RING_WIDTH);
            arc.setFill(null);
            arc.setStroke(Color.web(getCategoryColor(category.name)));
            arc.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.BUTT);
            
            // Add tooltip
            Tooltip tooltip = new Tooltip(
                String.format("%s\n%s (%.1f%%)", 
                    category.name, 
                    category.getFormattedTime(), 
                    percentage)
            );
            Tooltip.install(arc, tooltip);
            
            // Add interaction
            arc.setOnMouseEntered(e -> {
                ScaleTransition st = new ScaleTransition(Duration.millis(200), arc);
                st.setToX(1.04);
                st.setToY(1.04);
                st.play();
            });
            
            arc.setOnMouseExited(e -> {
                ScaleTransition st = new ScaleTransition(Duration.millis(200), arc);
                st.setToX(1.0);
                st.setToY(1.0);
                st.play();
            });
            
            chartContainer.getChildren().add(arc);
            arcs.add(arc);
            
            startAngle -= arcLength;
        }
        
        // Only animate the wedges growing in on the very first render.
        // Re-running this animation on every periodic refresh was resetting
        // each arc's length to 0 and regrowing it, which is what caused the
        // chart to visibly "blink" every 10 seconds.
        if (firstRender) {
            animateArcs();
            firstRender = false;
        }
        
        // Update legend
        updateLegend(activeCategories, totalTime);
    }

    private void animateArcs() {
        for (Arc arc : arcs) {
            double targetLength = arc.getLength();
            arc.setLength(0);
            
            Timeline timeline = new Timeline();
            KeyValue kv = new KeyValue(arc.lengthProperty(), targetLength);
            KeyFrame kf = new KeyFrame(Duration.millis(1000), kv);
            timeline.getKeyFrames().add(kf);
            timeline.setDelay(Duration.millis(200));
            timeline.play();
        }
    }

    private void updateLegend(List<CategoryStats> categories, long totalTime) {
        legendContainer.getChildren().clear();
        
        for (CategoryStats category : categories) {
            HBox legendItem = createLegendItem(category, totalTime);
            legendContainer.getChildren().add(legendItem);
        }
    }

    private HBox createLegendItem(CategoryStats category, long totalTime) {
        HBox item = new HBox(10);
        item.setAlignment(Pos.CENTER_LEFT);
        
        // Color indicator
        StackPane colorDot = new StackPane();
        colorDot.setPrefSize(12, 12);
        colorDot.getStyleClass().add("legend-dot");
        colorDot.setStyle("-fx-background-color: " + getCategoryColor(category.name) + 
                         "; -fx-background-radius: 6;");
        
        // Category name
        Label nameLabel = new Label(category.name);
        nameLabel.getStyleClass().add("legend-name");
        
        // Percentage
        Label percentLabel = new Label(String.format("%.1f%%", category.getPercentage(totalTime)));
        percentLabel.getStyleClass().add("legend-percent");
        
        HBox.setHgrow(nameLabel, Priority.ALWAYS);
        item.getChildren().addAll(colorDot, nameLabel, percentLabel);
        
        // Hover effect
        item.setOnMouseEntered(e -> {
            item.setStyle("-fx-background-color: derive(-fx-base, 5%); -fx-background-radius: 5;");
        });
        
        item.setOnMouseExited(e -> {
            item.setStyle("-fx-background-color: transparent;");
        });
        
        return item;
    }

    private void showEmptyState() {
        chartContainer.getChildren().removeIf(node -> node instanceof Arc);
        arcs.clear();
        
        VBox centerText = (VBox) chartContainer.getChildren().get(1);
        Label timeValueLabel = (Label) centerText.getChildren().get(1);
        timeValueLabel.setText("0h");
        
        legendContainer.getChildren().clear();
        Label emptyLabel = new Label("No data for today yet");
        emptyLabel.getStyleClass().add("empty-label");
        legendContainer.getChildren().add(emptyLabel);
        
        // Draw empty circle
        Arc emptyArc = new Arc(
            CHART_SIZE / 2, CHART_SIZE / 2,
            CHART_SIZE / 2 - RING_WIDTH / 2,
            CHART_SIZE / 2 - RING_WIDTH / 2,
            0, 360
        );
        emptyArc.setManaged(false);
        emptyArc.setType(ArcType.OPEN);
        emptyArc.setStrokeWidth(RING_WIDTH);
        emptyArc.setFill(null);
        emptyArc.setStroke(Color.LIGHTGRAY);
        chartContainer.getChildren().add(emptyArc);
    }

    private String getCategoryColor(String category) {
        return CATEGORY_COLORS.getOrDefault(category, "#607D8B");
    }

    private String formatDuration(long seconds) {
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        if (hours > 0) {
            return String.format("%dh %dm", hours, minutes);
        }
        return String.format("%dm", minutes);
    }

    private void startAutoRefresh() {
        refreshTimer = new Timer(true);
        refreshTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() -> updateChart());
            }
        }, 0, 10000); // Update every 10 seconds
    }

    public void refresh() {
        Platform.runLater(() -> updateChart());
    }

    public void cleanup() {
        if (refreshTimer != null) {
            refreshTimer.cancel();
        }
    }

    public VBox getView() {
        return view;
    }
}
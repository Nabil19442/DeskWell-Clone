package com.deskwell.view;

import com.deskwell.service.ChartService;
import com.deskwell.tracker.ActivityTracker;
import com.deskwell.tracker.ActivityTracker.AppUsageStats;
import javafx.animation.*;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.Node;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class DashboardView implements ActivityTracker.TrackerListener {
    private final ChartService chartService;
    private final ActivityTracker activityTracker;
    private ScrollPane mainScroll;
    private VBox view;
    
    // Real-time UI components
    private Label screenTimeLabel;
    private Label currentAppLabel;
    private Label productivityLabel;
    private Label focusTimeLabel;
    private VBox topAppsContainer;
    private Arc productivityArc;
    private CategoryBreakdownView categoryBreakdown;
    private BarChart<String, Number> hourlyChart;
    private XYChart.Series<String, Number> hourlySeries;
    private LineChart<String, Number> weeklyTrendChart;
    
    private Timer refreshTimer;

    public DashboardView(ChartService chartService, ActivityTracker activityTracker) {
        this.chartService = chartService;
        this.activityTracker = activityTracker;
        this.activityTracker.addListener(this);
        buildView();
        startRealTimeUpdates();
    }

    private void buildView() {
        mainScroll = new ScrollPane();
        mainScroll.setFitToWidth(true);
        mainScroll.getStyleClass().add("transparent-scroll");
        
        view = new VBox(25);
        view.setPadding(new Insets(25));
        view.getStyleClass().add("dashboard-view");
        
        // Header
        HBox header = createHeader();
        
        // Real-time metrics
        HBox metricsRow = createMetricsRow();
        
        // Main content with charts
        GridPane mainGrid = createMainGrid();
        
        // Weekly trends
        VBox trendsSection = createTrendsSection();
        
        view.getChildren().addAll(header, metricsRow, mainGrid, trendsSection);
        mainScroll.setContent(view);
    }

    private HBox createHeader() {
        HBox header = new HBox();
        header.setAlignment(Pos.CENTER_LEFT);
        
        VBox titleBox = new VBox(5);
        Label title = new Label("Dashboard");
        title.getStyleClass().add("view-title");
        
        Label subtitle = new Label("Your digital wellbeing at a glance");
        subtitle.getStyleClass().add("subtitle-label");
        
        // Date selector for historical view
        HBox dateControls = new HBox(10);
        dateControls.setAlignment(Pos.CENTER_RIGHT);
        
        Button todayBtn = new Button("Today");
        todayBtn.getStyleClass().add("date-button");
        todayBtn.setOnAction(e -> refreshDashboard());
        
        Button weekBtn = new Button("This Week");
        weekBtn.getStyleClass().add("date-button");
        
        Button monthBtn = new Button("This Month");
        monthBtn.getStyleClass().add("date-button");
        
        dateControls.getChildren().addAll(todayBtn, weekBtn, monthBtn);
        
        titleBox.getChildren().addAll(title, subtitle);
        
        HBox.setHgrow(titleBox, Priority.ALWAYS);
        header.getChildren().addAll(titleBox, dateControls);
        
        return header;
    }

    private HBox createMetricsRow() {
        HBox metricsRow = new HBox(15);
        metricsRow.setAlignment(Pos.CENTER);
        
        // Screen Time Card
        VBox screenTimeCard = createMetricCard(
            "📱", "Screen Time Today", "0h 0m", "#2196F3"
        );
        screenTimeLabel = (Label) ((VBox)((HBox)screenTimeCard.getChildren().get(0))
            .getChildren().get(1)).getChildren().get(1);
        
        // Current App Card
        VBox currentAppCard = createMetricCard(
            "🖥️", "Current Application", "None", "#4CAF50"
        );
        currentAppLabel = (Label) ((VBox)((HBox)currentAppCard.getChildren().get(0))
            .getChildren().get(1)).getChildren().get(1);
        
        // Productivity Score Card
        VBox productivityCard = createProductivityCard();
        productivityLabel = (Label) ((VBox)((StackPane)productivityCard.getChildren().get(0))
            .getChildren().get(2)).getChildren().get(0);
        
        // Focus Time Card
        VBox focusCard = createMetricCard(
            "🎯", "Focus Time Today", "0m", "#FF9800"
        );
        focusTimeLabel = (Label) ((VBox)((HBox)focusCard.getChildren().get(0))
            .getChildren().get(1)).getChildren().get(1);
        
        metricsRow.getChildren().addAll(
            screenTimeCard, currentAppCard, productivityCard, focusCard
        );
        
        return metricsRow;
    }

    private VBox createMetricCard(String icon, String title, String value, String color) {
        VBox card = new VBox(10);
        card.getStyleClass().add("metric-card");
        card.setPadding(new Insets(20));
        card.setPrefWidth(250);
        
        HBox header = new HBox(10);
        header.setAlignment(Pos.CENTER_LEFT);
        
        Label iconLabel = new Label(icon);
        iconLabel.setFont(Font.font(24));
        
        VBox textBox = new VBox(3);
        Label titleLabel = new Label(title);
        titleLabel.getStyleClass().add("metric-label");
        
        Label valueLabel = new Label(value);
        valueLabel.getStyleClass().add("metric-value");
        
        textBox.getChildren().addAll(titleLabel, valueLabel);
        header.getChildren().addAll(iconLabel, textBox);
        
        // Color indicator
        StackPane colorBar = new StackPane();
        colorBar.setPrefHeight(4);
        colorBar.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 2;");
        
        card.getChildren().addAll(header, colorBar);
        
        // Add hover effect
        addCardHoverEffect(card);
        
        return card;
    }

    private VBox createProductivityCard() {
        VBox card = new VBox(10);
        card.getStyleClass().add("metric-card");
        card.setPadding(new Insets(20));
        card.setPrefWidth(250);
        card.setAlignment(Pos.CENTER);
        
        // Productivity ring
        StackPane ringContainer = new StackPane();
        ringContainer.setPrefSize(120, 120);
        // MUST also lock min/max size, not just pref. A Region's max size
        // defaults to unlimited, so without this the surrounding HBox
        // (which stretches all 4 metric cards to a uniform row height) was
        // free to size this container taller/wider than 120x120. The
        // managed bgCircle below re-centers itself to whatever the actual
        // (larger) box turned out to be on each layout pass, but the
        // unmanaged productivityArc stays pinned to its hardcoded
        // (60,60) center - so the two drifted apart and the arc rendered
        // off-center, poking outside the ring. Locking min/max == pref
        // keeps the container at exactly 120x120 always, the same fix
        // already applied to the Focus Mode ring (300x300) and the pie
        // chart (CHART_SIZE x CHART_SIZE).
        ringContainer.setMinSize(120, 120);
        ringContainer.setMaxSize(120, 120);
        
        // Background circle
        Circle bgCircle = new Circle(50);
        bgCircle.setFill(null);
        bgCircle.setStroke(Color.web("#E0E0E0"));
        bgCircle.setStrokeWidth(10);
        
        // Progress arc
        productivityArc = new Arc(60, 60, 45, 45, 90, 0);
        // See the matching comment in FocusModeView.createTimerCircle():
        // a StackPane re-centers managed children using their *current*
        // bounding box, and a partial Arc's box shrinks/grows with its
        // length, which made this ring's progress line render from the
        // center of the card instead of along its border. Unmanaging it
        // pins it to its real (60,60)-centered geometry, matching the
        // 120x120 ringContainer's center.
        productivityArc.setManaged(false);
        productivityArc.setType(ArcType.OPEN);
        productivityArc.setStroke(Color.valueOf("#2196F3"));
        productivityArc.setStrokeWidth(10);
        productivityArc.setFill(null);
        productivityArc.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        
        // Center text
        VBox ringText = new VBox(2);
        ringText.setAlignment(Pos.CENTER);
        
        Label percentLabel = new Label("0%");
        percentLabel.setId("productivityScore");
        percentLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 28));
        
        Label ringTitle = new Label("Productivity");
        ringTitle.getStyleClass().add("productivity-ring-title");
        
        ringText.getChildren().addAll(percentLabel, ringTitle);
        
        ringContainer.getChildren().addAll(bgCircle, productivityArc, ringText);
        
        card.getChildren().add(ringContainer);
        
        return card;
    }

    private GridPane createMainGrid() {
        GridPane grid = new GridPane();
        grid.setHgap(20);
        grid.setVgap(20);
        
        // Category breakdown
        categoryBreakdown = new CategoryBreakdownView(chartService);
        VBox categorySection = createSection("Category Breakdown", categoryBreakdown.getView());
        
        // Hourly activity chart
        VBox hourlySection = createSection("Hourly Activity", createHourlyChart());
        
        // Top apps list
        VBox appsSection = createSection("Most Used Apps", createTopAppsContainer());
        
        grid.add(categorySection, 0, 0);
        grid.add(hourlySection, 1, 0);
        grid.add(appsSection, 0, 1, 2, 1);
        
        // Column constraints
        ColumnConstraints col1 = new ColumnConstraints();
        col1.setPercentWidth(45);
        ColumnConstraints col2 = new ColumnConstraints();
        col2.setPercentWidth(55);
        grid.getColumnConstraints().addAll(col1, col2);
        
        return grid;
    }

    private VBox createSection(String title, Node content) {
        VBox section = new VBox(10);
        section.getStyleClass().add("dashboard-section");
        section.setPadding(new Insets(20));
        
        Label titleLabel = new Label(title);
        titleLabel.getStyleClass().add("section-title");
        
        section.getChildren().addAll(titleLabel, content);
        VBox.setVgrow(content, Priority.ALWAYS);
        
        return section;
    }

    private Node createHourlyChart() {
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Minutes");
        
        hourlyChart = new BarChart<>(xAxis, yAxis);
        hourlyChart.setTitle("Today's Activity by Hour");
        hourlyChart.setLegendVisible(false);
        // Animation was replaying in full every time the periodic refresh
        // cleared and re-added the series data, which is what made the
        // chart appear to "blink" every few seconds. Keeping the chart
        // un-animated (we update values in place below) makes refreshes
        // silent and smooth instead.
        hourlyChart.setAnimated(false);
        hourlyChart.setBarGap(3);
        hourlyChart.setCategoryGap(5);
        
        // Style the chart
        hourlyChart.getStyleClass().add("dashboard-chart");
        
        // Persistent series - reused across refreshes instead of being
        // torn down and rebuilt each time.
        hourlySeries = new XYChart.Series<>();
        hourlyChart.getData().add(hourlySeries);
        
        // Initialize with data
        updateHourlyChartData();
        
        return hourlyChart;
    }

    private void updateHourlyChartData() {
        Map<Integer, Long> hourlyData = chartService.getHourlyActivity();
        int currentHour = LocalTime.now().getHour();
        
        Platform.runLater(() -> {
            ObservableList<XYChart.Data<String, Number>> existing = hourlySeries.getData();
            
            // Update values in place / append new hours as the day progresses,
            // instead of clearing and re-adding the whole series (which was
            // destroying and recreating every bar node on each refresh).
            for (int hour = 0; hour <= currentHour; hour++) {
                long minutes = hourlyData.getOrDefault(hour, 0L) / 60;
                String hourLabel = String.format("%02d:00", hour);
                
                if (hour < existing.size()) {
                    existing.get(hour).setYValue(minutes);
                    colorHourBar(existing.get(hour), hour, currentHour);
                } else {
                    XYChart.Data<String, Number> data = new XYChart.Data<>(hourLabel, minutes);
                    existing.add(data);
                    int hourForListener = hour;
                    // Node is only created once the bar is added to a live
                    // chart, so color it (once) as soon as it becomes available.
                    data.nodeProperty().addListener((obs, oldNode, newNode) -> {
                        if (newNode != null) {
                            colorHourBar(data, hourForListener, currentHour);
                        }
                    });
                }
            }
        });
    }

    private void colorHourBar(XYChart.Data<String, Number> data, int hour, int currentHour) {
        if (data.getNode() == null) return;
        if (hour == currentHour) {
            data.getNode().setStyle("-fx-bar-fill: #2196F3;");
        } else if (hour >= 9 && hour <= 17) {
            data.getNode().setStyle("-fx-bar-fill: #4CAF50;");
        } else {
            data.getNode().setStyle("-fx-bar-fill: #FF9800;");
        }
    }

    private Node createTopAppsContainer() {
        topAppsContainer = new VBox(8);
        
        ScrollPane scrollPane = new ScrollPane(topAppsContainer);
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefHeight(250);
        scrollPane.getStyleClass().add("transparent-scroll");
        
        return scrollPane;
    }

    private VBox createTrendsSection() {
        VBox section = createSection("Weekly Trends", createWeeklyTrendChart());
        return section;
    }

    private Node createWeeklyTrendChart() {
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Hours");
        
        weeklyTrendChart = new LineChart<>(xAxis, yAxis);
        weeklyTrendChart.setTitle("Screen Time - Last 7 Days");
        weeklyTrendChart.setAnimated(true);
        weeklyTrendChart.setCreateSymbols(true);
        weeklyTrendChart.getStyleClass().add("dashboard-chart");
        
        // Screen time series
        XYChart.Series<String, Number> screenTimeSeries = new XYChart.Series<>();
        screenTimeSeries.setName("Screen Time");
        
        Map<LocalDate, Long> dailyData = chartService.getDailyActivity(7);
        for (Map.Entry<LocalDate, Long> entry : dailyData.entrySet()) {
            double hours = entry.getValue() / 3600.0;
            screenTimeSeries.getData().add(
                new XYChart.Data<>(entry.getKey().format(java.time.format.DateTimeFormatter.ofPattern("MM/dd")), 
                Math.round(hours * 10.0) / 10.0)
            );
        }
        
        // Productivity series
        XYChart.Series<String, Number> productivitySeries = new XYChart.Series<>();
        productivitySeries.setName("Productivity %");
        
        Map<LocalDate, Double> trends = chartService.getProductivityTrends(7);
        for (Map.Entry<LocalDate, Double> entry : trends.entrySet()) {
            productivitySeries.getData().add(
                new XYChart.Data<>(entry.getKey().format(java.time.format.DateTimeFormatter.ofPattern("MM/dd")), 
                entry.getValue())
            );
        }
        
        weeklyTrendChart.getData().addAll(screenTimeSeries, productivitySeries);
        
        return weeklyTrendChart;
    }

    private void updateTopApps() {
        List<AppUsageStats> topApps = activityTracker.getTopApps(8);
        long totalScreenTime = activityTracker.getTotalScreenTimeToday();
        
        topAppsContainer.getChildren().clear();
        
        if (topApps.isEmpty()) {
            Label emptyLabel = new Label("No apps tracked yet today");
            emptyLabel.getStyleClass().add("empty-label");
            topAppsContainer.getChildren().add(emptyLabel);
            return;
        }
        
        for (int i = 0; i < topApps.size(); i++) {
            AppUsageStats app = topApps.get(i);
            HBox appRow = createAppUsageRow(i + 1, app, totalScreenTime);
            topAppsContainer.getChildren().add(appRow);
        }
    }

    private HBox createAppUsageRow(int rank, AppUsageStats app, long totalScreenTime) {
        HBox row = new HBox(15);
        row.setAlignment(Pos.CENTER_LEFT);
        row.getStyleClass().add("app-usage-row");
        row.setPadding(new Insets(12, 15, 12, 15));
        
        // Rank number
        Label rankLabel = new Label(String.valueOf(rank));
        rankLabel.getStyleClass().add("rank-label");
        rankLabel.setPrefWidth(25);
        
        // App icon with first letter
        StackPane iconContainer = new StackPane();
        iconContainer.setPrefSize(45, 45);
        iconContainer.getStyleClass().add("app-icon");
        
        String firstLetter = app.appName.substring(0, 1).toUpperCase();
        Text iconText = new Text(firstLetter);
        iconText.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        iconText.setFill(Color.WHITE);
        iconContainer.getChildren().add(iconText);
        
        // App details
        VBox details = new VBox(3);
        details.setAlignment(Pos.CENTER_LEFT);
        
        Label nameLabel = new Label(app.appName);
        nameLabel.getStyleClass().add("app-name");
        nameLabel.setFont(Font.font("Segoe UI", FontWeight.SEMI_BOLD, 14));
        
        Label categoryLabel = new Label(app.category != null ? app.category : "Other");
        categoryLabel.getStyleClass().add("category-label");
        
        // Progress section
        VBox progressSection = new VBox(5);
        progressSection.setAlignment(Pos.CENTER_RIGHT);
        
        double percentage = app.getPercentageOfTotal(totalScreenTime);
        
        // Custom progress bar
        StackPane progressBar = new StackPane();
        progressBar.setPrefWidth(200);
        progressBar.setPrefHeight(6);
        progressBar.getStyleClass().add("custom-progress-track");
        
        StackPane progressFill = new StackPane();
        progressFill.setPrefWidth(percentage * 2); // 200 * percentage/100
        progressFill.setPrefHeight(6);
        progressFill.getStyleClass().add("custom-progress-fill");
        progressFill.setStyle("-fx-background-color: " + getCategoryColor(app.category) + ";");
        progressBar.getChildren().add(progressFill);
        StackPane.setAlignment(progressFill, Pos.CENTER_LEFT);
        
        Label timeLabel = new Label(app.getFormattedDuration());
        timeLabel.getStyleClass().add("app-time");
        
        Label percentLabel = new Label(String.format("%.1f%%", percentage));
        percentLabel.getStyleClass().add("percentage-label");
        
        progressSection.getChildren().addAll(progressBar, new HBox(5, timeLabel, percentLabel));
        
        details.getChildren().addAll(nameLabel, categoryLabel);
        
        HBox.setHgrow(details, Priority.ALWAYS);
        row.getChildren().addAll(rankLabel, iconContainer, details, progressSection);
        
        // Hover animation
        addRowHoverEffect(row);
        
        return row;
    }

    private String getCategoryColor(String category) {
        if (category == null) return "#607D8B";
        return switch (category) {
            case "Productivity" -> "#4CAF50";
            case "Development" -> "#2196F3";
            case "Browser" -> "#FF9800";
            case "Entertainment" -> "#F44336";
            case "Communication" -> "#9C27B0";
            case "Gaming" -> "#795548";
            default -> "#607D8B";
        };
    }

    private void addCardHoverEffect(Node card) {
        DropShadow shadow = new DropShadow();
        shadow.setRadius(15);
        shadow.setColor(Color.rgb(0, 0, 0, 0.1));
        
        card.setOnMouseEntered(e -> {
            card.setEffect(shadow);
            ScaleTransition st = new ScaleTransition(Duration.millis(200), card);
            st.setToX(1.02);
            st.setToY(1.02);
            st.play();
        });
        
        card.setOnMouseExited(e -> {
            card.setEffect(null);
            ScaleTransition st = new ScaleTransition(Duration.millis(200), card);
            st.setToX(1.0);
            st.setToY(1.0);
            st.play();
        });
    }

    private void addRowHoverEffect(Node row) {
        row.setOnMouseEntered(e -> {
            row.setStyle("-fx-background-color: derive(-fx-base, 8%); -fx-background-radius: 8;");
        });
        
        row.setOnMouseExited(e -> {
            row.setStyle("-fx-background-color: transparent;");
        });
    }

    private void startRealTimeUpdates() {
        refreshTimer = new Timer(true);
        refreshTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() -> refreshDashboard());
            }
        }, 0, 5000); // Update every 5 seconds
    }

    private void refreshDashboard() {
        if (!activityTracker.isRunning()) return;
        
        // Update metrics
        screenTimeLabel.setText(activityTracker.getTodayScreenTimeFormatted());
        
        if (activityTracker.getCurrentApplication() != null) {
            currentAppLabel.setText(
                activityTracker.getCurrentApplication().getDisplayName()
            );
        }
        
        // Update productivity score with animation
        double score = activityTracker.getProductivityScore();
        productivityLabel.setText(String.format("%.0f%%", score));
        animateProductivityRing(score);
        
        // Update focus time
        ChartService.FocusStats focusStats = chartService.getFocusStats();
        focusTimeLabel.setText(focusStats.getFormattedFocusTime());
        
        // Update top apps
        updateTopApps();
        
        // Update hourly chart
        updateHourlyChartData();
        
        // Update category breakdown
        categoryBreakdown.refresh();
    }

    private void animateProductivityRing(double targetScore) {
        double targetAngle = (targetScore / 100.0) * 360;
        
        // Determine color based on score
        Color targetColor;
        if (targetScore >= 70) {
            targetColor = Color.valueOf("#4CAF50");
        } else if (targetScore >= 40) {
            targetColor = Color.valueOf("#FF9800");
        } else {
            targetColor = Color.valueOf("#F44336");
        }
        
        Timeline timeline = new Timeline();
        KeyValue angleValue = new KeyValue(productivityArc.lengthProperty(), targetAngle);
        KeyValue colorValue = new KeyValue(productivityArc.strokeProperty(), targetColor);
        KeyFrame keyFrame = new KeyFrame(Duration.millis(800), angleValue, colorValue);
        timeline.getKeyFrames().add(keyFrame);
        timeline.play();
    }

    @Override
    public void onTrackerEvent(String event, ActivityTracker tracker) {
        Platform.runLater(() -> refreshDashboard());
    }

    public void cleanup() {
        if (refreshTimer != null) {
            refreshTimer.cancel();
        }
        activityTracker.removeListener(this);
        if (categoryBreakdown != null) {
            categoryBreakdown.cleanup();
        }
    }

    public ScrollPane getView() {
        return mainScroll;
    }
}
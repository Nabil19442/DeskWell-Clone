package com.deskwell.view;

import com.deskwell.service.AppBlockerService;
import com.deskwell.service.FocusModeService;
import com.deskwell.service.FocusModeService.*;
import javafx.animation.*;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.util.List;

public class FocusModeView implements FocusModeService.FocusListener {
    private final FocusModeService focusService;
    private final AppBlockerService appBlocker;
    private VBox view;
    
    // Timer UI components
    private Label timerLabel;
    private Arc progressArc;
    // Single reusable Timeline for animating the progress arc. Reused (and
    // stopped before restarting) on every "tick" instead of creating a new
    // Timeline each second - see updateTimerDisplay().
    private Timeline progressTimeline;
    private Label statusLabel;
    private Label sessionCountLabel;
    private Button startPauseBtn;
    private Button stopBtn;
    private Button skipBreakBtn;
    private VBox blockListContainer;
    
    // Settings
    private ComboBox<Integer> focusDurationCombo;
    private ComboBox<Integer> breakDurationCombo;
    
    public FocusModeView(FocusModeService focusService, AppBlockerService appBlocker) {
        this.focusService = focusService;
        this.appBlocker = appBlocker;
        this.focusService.addListener(this);
        buildView();
    }

    private void buildView() {
        view = new VBox(25);
        view.setPadding(new Insets(25));
        
        // Header
        HBox header = createHeader();
        
        // Main content
        HBox mainContent = new HBox(20);
        VBox.setVgrow(mainContent, Priority.ALWAYS);
        
        // Left side - Timer and controls
        VBox timerSection = createTimerSection();
        
        // Right side - Settings and blocked apps
        VBox settingsSection = createSettingsSection();
        
        mainContent.getChildren().addAll(timerSection, settingsSection);
        
        view.getChildren().addAll(header, mainContent);
    }

    private HBox createHeader() {
        HBox header = new HBox();
        header.setAlignment(Pos.CENTER_LEFT);
        
        VBox titleBox = new VBox(5);
        Label title = new Label("Focus Mode");
        title.getStyleClass().add("view-title");
        
        Label subtitle = new Label("Stay focused with Pomodoro timer and app blocking");
        subtitle.getStyleClass().add("subtitle-label");
        
        titleBox.getChildren().addAll(title, subtitle);
        HBox.setHgrow(titleBox, Priority.ALWAYS);
        
        // Stats
        HBox statsBox = new HBox(20);
        FocusStats stats = focusService.getTodayStats();
        
        VBox sessionsStat = createStatBox("Today's Sessions", String.valueOf(stats.totalSessions));
        VBox focusTimeStat = createStatBox("Focus Time", stats.getFormattedTotalTime());
        VBox streakStat = createStatBox("Current Streak", String.valueOf(stats.currentStreak));
        
        statsBox.getChildren().addAll(sessionsStat, focusTimeStat, streakStat);
        header.getChildren().addAll(titleBox, statsBox);
        
        return header;
    }

    private VBox createStatBox(String label, String value) {
        VBox box = new VBox(3);
        box.setAlignment(Pos.CENTER);
        
        Label valueLabel = new Label(value);
        valueLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 20));
        valueLabel.setStyle("-fx-text-fill: #2196F3;");
        
        Label textLabel = new Label(label);
        textLabel.getStyleClass().add("stat-label");
        
        box.getChildren().addAll(valueLabel, textLabel);
        return box;
    }

    private VBox createTimerSection() {
        VBox section = new VBox(25);
        section.setAlignment(Pos.CENTER);
        section.getStyleClass().add("focus-timer-section");
        section.setPadding(new Insets(30));
        
        // Timer circle
        StackPane timerCircle = createTimerCircle();
        
        // Status
        statusLabel = new Label("Ready to Focus");
        statusLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        statusLabel.getStyleClass().add("focus-status");
        
        // Session counter
        sessionCountLabel = new Label("Completed: 0 sessions");
        sessionCountLabel.getStyleClass().add("session-count");
        
        // Controls
        HBox controls = createTimerControls();
        
        section.getChildren().addAll(timerCircle, statusLabel, sessionCountLabel, controls);
        
        return section;
    }

    private StackPane createTimerCircle() {
        StackPane container = new StackPane();
        container.setPrefSize(300, 300);
        container.setMinSize(300, 300);
        container.setMaxSize(300, 300);
        
        // Clip to the container's own bounds so the completion pulse
        // (ScaleTransition on progressArc in animateCompletion()) can't
        // paint outside the 300x300 circle and overlap neighboring UI -
        // same fix as the pie chart overflow in CategoryBreakdownView.java.
        Rectangle clip = new Rectangle(300, 300);
        clip.widthProperty().bind(container.widthProperty());
        clip.heightProperty().bind(container.heightProperty());
        container.setClip(clip);
        
        // Background circle
        Circle bgCircle = new Circle(130);
        bgCircle.setFill(Color.TRANSPARENT);
        bgCircle.setStroke(Color.web("#E0E0E0"));
        bgCircle.setStrokeWidth(12);
        
        // Progress arc
        progressArc = new Arc(150, 150, 130, 130, 90, 0);
        // IMPORTANT: StackPane auto-centers managed children using each
        // child's *current* layout bounds. A full circle's bounding box
        // never changes, so bgCircle stays put - but a partial Arc's
        // bounding box shrinks to hug only the drawn stroke, so as the arc
        // grows from length 0 the StackPane kept re-centering that
        // shrinking/growing box, making the progress line render from the
        // middle of the ring instead of tracing the circle's edge (visible
        // in the app as a short blue squiggle behind the timer digits
        // instead of an arc on the border). Marking it unmanaged pins it to
        // its real (150,150)-centered geometry, which lines up with the
        // StackPane's center exactly since the container is 300x300.
        progressArc.setManaged(false);
        progressArc.setType(ArcType.OPEN);
        progressArc.setStroke(Color.valueOf("#2196F3"));
        progressArc.setStrokeWidth(12);
        progressArc.setFill(Color.TRANSPARENT);
        progressArc.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        
        // Timer text
        VBox timerText = new VBox(5);
        timerText.setAlignment(Pos.CENTER);
        
        timerLabel = new Label("25:00");
        timerLabel.setId("focusTimer");
        timerLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 52));
        timerLabel.setTextFill(Color.valueOf("#2196F3"));
        
        Label unitLabel = new Label("minutes");
        unitLabel.getStyleClass().add("timer-unit");
        
        timerText.getChildren().addAll(timerLabel, unitLabel);
        
        container.getChildren().addAll(bgCircle, progressArc, timerText);
        
        // Drop shadow effect
        DropShadow shadow = new DropShadow();
        shadow.setRadius(20);
        shadow.setColor(Color.rgb(33, 150, 243, 0.3));
        container.setEffect(shadow);
        
        return container;
    }

    private HBox createTimerControls() {
        HBox controls = new HBox(15);
        controls.setAlignment(Pos.CENTER);
        
        startPauseBtn = new Button("▶ Start Focus");
        startPauseBtn.getStyleClass().add("focus-control-btn");
        startPauseBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        startPauseBtn.setOnAction(e -> handleStartPause());
        
        stopBtn = new Button("⏹ Stop");
        stopBtn.getStyleClass().add("focus-control-btn");
        stopBtn.setStyle("-fx-background-color: #F44336; -fx-text-fill: white;");
        stopBtn.setVisible(false);
        stopBtn.setOnAction(e -> handleStop());
        
        skipBreakBtn = new Button("⏭ Skip Break");
        skipBreakBtn.getStyleClass().add("focus-control-btn");
        skipBreakBtn.setStyle("-fx-background-color: #FF9800; -fx-text-fill: white;");
        skipBreakBtn.setVisible(false);
        skipBreakBtn.setOnAction(e -> handleSkipBreak());
        
        controls.getChildren().addAll(startPauseBtn, stopBtn, skipBreakBtn);
        
        return controls;
    }

    private void handleStartPause() {
        TimerState state = focusService.getTimerState();
        
        switch (state) {
            case IDLE -> {
                // Start new focus session
                focusService.startFocusSession();
                startPauseBtn.setText("⏸ Pause");
                startPauseBtn.setStyle("-fx-background-color: #FF9800; -fx-text-fill: white;");
                stopBtn.setVisible(true);
                
                // Start app blocking
                List<String> appsToBlock = getSelectedBlockedApps();
                appBlocker.startBlocking(appsToBlock);
            }
            case FOCUS, BREAK -> {
                focusService.pauseSession();
                startPauseBtn.setText("▶ Resume");
                startPauseBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
            }
            case PAUSED -> {
                focusService.resumeSession();
                startPauseBtn.setText("⏸ Pause");
                startPauseBtn.setStyle("-fx-background-color: #FF9800; -fx-text-fill: white;");
            }
        }
    }

    private void handleStop() {
        focusService.stopSession();
        appBlocker.stopBlocking();
        resetUI();
    }

    private void handleSkipBreak() {
        focusService.skipBreak();
        skipBreakBtn.setVisible(false);
    }

    private void resetUI() {
        startPauseBtn.setText("▶ Start Focus");
        startPauseBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        stopBtn.setVisible(false);
        skipBreakBtn.setVisible(false);
        timerLabel.setText(String.format("%02d:00", focusService.getFocusDurationMinutes()));
        progressArc.setLength(0);
        statusLabel.setText("Ready to Focus");
        sessionCountLabel.setText(String.format("Completed: %d sessions", 
            focusService.getCompletedSessions()));
    }

    private VBox createSettingsSection() {
        VBox section = new VBox(15);
        section.setPadding(new Insets(20));
        section.getStyleClass().add("focus-settings-section");
        
        // Timer settings
        Label settingsTitle = new Label("⏱ Timer Settings");
        settingsTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
        
        GridPane timerSettings = createTimerSettings();
        
        // Blocked apps
        Label blockTitle = new Label("🚫 Blocked Applications");
        blockTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
        
        VBox blockSection = createBlockSection();
        
        // Separator
        Separator sep = new Separator();
        Separator sep2 = new Separator();
        
        // Focus tips
        VBox tipsBox = createTipsBox();
        
        section.getChildren().addAll(
            settingsTitle, timerSettings,
            sep,
            blockTitle, blockSection,
            sep2,
            tipsBox
        );
        
        ScrollPane scrollPane = new ScrollPane(section);
        scrollPane.setFitToWidth(true);
        scrollPane.getStyleClass().add("transparent-scroll");
        
        VBox container = new VBox(scrollPane);
        return container;
    }

    private GridPane createTimerSettings() {
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10, 0, 10, 0));
        
        // Focus duration
        Label focusLabel = new Label("Focus Duration:");
        focusDurationCombo = new ComboBox<>();
        focusDurationCombo.getItems().addAll(15, 20, 25, 30, 45, 60);
        focusDurationCombo.setValue(focusService.getFocusDurationMinutes());
        focusDurationCombo.setOnAction(e -> 
            focusService.setFocusDuration(focusDurationCombo.getValue()));
        
        // Break duration
        Label breakLabel = new Label("Break Duration:");
        breakDurationCombo = new ComboBox<>();
        breakDurationCombo.getItems().addAll(3, 5, 10, 15, 20);
        breakDurationCombo.setValue(focusService.getBreakDurationMinutes());
        breakDurationCombo.setOnAction(e -> 
            focusService.setBreakDuration(breakDurationCombo.getValue()));
        
        grid.add(focusLabel, 0, 0);
        grid.add(focusDurationCombo, 1, 0);
        grid.add(new Label("minutes"), 2, 0);
        grid.add(breakLabel, 0, 1);
        grid.add(breakDurationCombo, 1, 1);
        grid.add(new Label("minutes"), 2, 1);
        
        return grid;
    }

    private VBox createBlockSection() {
        VBox section = new VBox(10);
        
        // Search/Add bar
        HBox searchBar = new HBox(10);
        
        ComboBox<String> appCombo = new ComboBox<>();
        appCombo.setEditable(true);
        appCombo.setPromptText("Search or type app name...");
        appCombo.getItems().addAll(appBlocker.getAvailableAppsForBlocking());
        
        Button addBtn = new Button("+ Block");
        addBtn.getStyleClass().add("block-button");
        addBtn.setOnAction(e -> {
            String appName = appCombo.getValue();
            if (appName != null && !appName.isEmpty()) {
                appBlocker.addPermanentBlock(appName);
                refreshBlockedAppsList();
            }
        });
        
        searchBar.getChildren().addAll(appCombo, addBtn);
        
        // Blocked apps list
        blockListContainer = new VBox(8);
        refreshBlockedAppsList();
        
        ScrollPane listScroll = new ScrollPane(blockListContainer);
        listScroll.setFitToWidth(true);
        listScroll.setPrefHeight(200);
        listScroll.getStyleClass().add("transparent-scroll");
        
        section.getChildren().addAll(searchBar, listScroll);
        
        return section;
    }

    private void refreshBlockedAppsList() {
        blockListContainer.getChildren().clear();
        
        for (String app : appBlocker.getPermanentlyBlockedApps()) {
            HBox appRow = new HBox(10);
            appRow.setAlignment(Pos.CENTER_LEFT);
            appRow.getStyleClass().add("blocked-app-row");
            appRow.setPadding(new Insets(8, 12, 8, 12));
            
            Label iconLabel = new Label("🚫");
            iconLabel.setFont(Font.font(16));
            
            Label nameLabel = new Label(app);
            nameLabel.setFont(Font.font("Segoe UI", FontWeight.SEMI_BOLD, 13));
            
            HBox.setHgrow(nameLabel, Priority.ALWAYS);
            
            Button removeBtn = new Button("✕");
            removeBtn.getStyleClass().add("remove-block-btn");
            removeBtn.setOnAction(e -> {
                appBlocker.removePermanentBlock(app);
                refreshBlockedAppsList();
            });
            
            appRow.getChildren().addAll(iconLabel, nameLabel, removeBtn);
            blockListContainer.getChildren().add(appRow);
        }
        
        if (blockListContainer.getChildren().isEmpty()) {
            Label emptyLabel = new Label("No apps blocked. Add apps above to block them during focus sessions.");
            emptyLabel.setWrapText(true);
            emptyLabel.getStyleClass().add("empty-label");
            blockListContainer.getChildren().add(emptyLabel);
        }
    }

    private List<String> getSelectedBlockedApps() {
        return List.copyOf(appBlocker.getPermanentlyBlockedApps());
    }

    private VBox createTipsBox() {
        VBox tips = new VBox(8);
        tips.getStyleClass().add("tips-box");
        tips.setPadding(new Insets(15));
        
        Label tipsTitle = new Label("💡 Focus Tips");
        tipsTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        
        String[] tipsList = {
            "• Start with 25-minute sessions for best results",
            "• Take short breaks to maintain productivity",
            "• Block distracting apps during focus time",
            "• Stay consistent - try to complete at least 4 sessions daily",
            "• After 4 sessions, take a longer 15-minute break"
        };
        
        VBox tipsContent = new VBox(5);
        for (String tip : tipsList) {
            Label tipLabel = new Label(tip);
            tipLabel.setWrapText(true);
            tipLabel.getStyleClass().add("tip-label");
            tipsContent.getChildren().add(tipLabel);
        }
        
        tips.getChildren().addAll(tipsTitle, tipsContent);
        
        return tips;
    }

    // FocusListener implementation
    @Override
    public void onFocusEvent(String event, FocusModeService service) {
        Platform.runLater(() -> {
            switch (event) {
                case "tick" -> updateTimerDisplay();
                case "focus_started" -> {
                    statusLabel.setText("Focusing... 🎯");
                    statusLabel.setStyle("-fx-text-fill: #4CAF50;");
                }
                case "focus_paused" -> {
                    statusLabel.setText("Paused ⏸");
                    statusLabel.setStyle("-fx-text-fill: #FF9800;");
                }
                case "focus_resumed" -> {
                    statusLabel.setText("Focusing... 🎯");
                    statusLabel.setStyle("-fx-text-fill: #4CAF50;");
                }
                case "focus_complete" -> {
                    statusLabel.setText("Focus Complete! 🎉");
                    statusLabel.setStyle("-fx-text-fill: #4CAF50;");
                    sessionCountLabel.setText(String.format("Completed: %d sessions", 
                        service.getCompletedSessions()));
                    
                    // Show notification animation
                    animateCompletion();
                }
                case "break_started" -> {
                    statusLabel.setText("Break Time ☕");
                    statusLabel.setStyle("-fx-text-fill: #2196F3;");
                    skipBreakBtn.setVisible(true);
                }
                case "break_complete" -> {
                    statusLabel.setText("Break Complete! Ready to focus");
                    statusLabel.setStyle("-fx-text-fill: #4CAF50;");
                    skipBreakBtn.setVisible(false);
                    resetUI();
                }
                case "focus_stopped" -> resetUI();
            }
        });
    }

    private void updateTimerDisplay() {
        timerLabel.setText(focusService.getFormattedTime());
        
        // Update progress arc
        double progress = focusService.getProgress();
        double arcLength = progress * 360;
        
        // Animate arc using a single reusable Timeline. updateTimerDisplay()
        // runs on every "tick" (every second); previously this created a
        // brand-new Timeline each time without stopping the last one, so
        // over a running session many Timelines piled up and fought over
        // progressArc's lengthProperty at once, causing jittery/overflowing
        // rendering. Stopping the in-flight timeline first keeps exactly one
        // animation driving the property at any moment.
        if (progressTimeline != null) {
            progressTimeline.stop();
        }
        KeyValue kv = new KeyValue(progressArc.lengthProperty(), arcLength);
        KeyFrame kf = new KeyFrame(Duration.millis(500), kv);
        progressTimeline = new Timeline(kf);
        progressTimeline.play();
        
        // Change color based on progress
        Color color;
        if (focusService.getTimerState() == TimerState.BREAK) {
            color = Color.valueOf("#2196F3");
        } else if (progress > 0.8) {
            color = Color.valueOf("#4CAF50");
        } else if (progress > 0.5) {
            color = Color.valueOf("#2196F3");
        } else {
            color = Color.valueOf("#2196F3");
        }
        
        progressArc.setStroke(color);
        timerLabel.setTextFill(color);
    }

    private void animateCompletion() {
        // Pulse animation. progressArc's stroked bounds (radius 130 +
        // strokeWidth 12) are ~262px across, centered in the 300x300
        // container; at the 1.1x scale used below that's ~288px, which
        // still fits inside the container's clip, so no further reduction
        // is needed now that the StackPane is clipped.
        ScaleTransition st = new ScaleTransition(Duration.millis(500), progressArc);
        st.setFromX(1.0);
        st.setFromY(1.0);
        st.setToX(1.1);
        st.setToY(1.1);
        st.setAutoReverse(true);
        st.setCycleCount(3);
        st.play();
        
        // Fade animation
        FadeTransition ft = new FadeTransition(Duration.millis(500), statusLabel);
        ft.setFromValue(1.0);
        ft.setToValue(0.5);
        ft.setAutoReverse(true);
        ft.setCycleCount(4);
        ft.play();
    }

    public void cleanup() {
        focusService.removeListener(this);
        if (focusService.isFocusMode()) {
            focusService.stopSession();
            appBlocker.stopBlocking();
        }
    }

    public VBox getView() {
        return view;
    }
}
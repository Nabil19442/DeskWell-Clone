package com.deskwell.view;

import com.deskwell.database.DatabaseManager;
import javafx.animation.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.util.Duration;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.logging.Logger;

public class GoalsView {
    private static final Logger logger = Logger.getLogger(GoalsView.class.getName());
    private final DatabaseManager databaseManager;
    private VBox view;
    private VBox goalsContainer;

    public GoalsView(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
        buildView();
        loadGoals();
    }

    private void buildView() {
        view = new VBox(25);
        view.setPadding(new Insets(25));
        
        // Header
        HBox header = new HBox();
        header.setAlignment(Pos.CENTER_LEFT);
        
        VBox titleBox = new VBox(5);
        Label title = new Label("Goals & Targets");
        title.getStyleClass().add("view-title");
        
        Label subtitle = new Label("Set and track your digital wellbeing goals");
        subtitle.getStyleClass().add("subtitle-label");
        
        titleBox.getChildren().addAll(title, subtitle);
        
        Button addGoalBtn = new Button("+ New Goal");
        addGoalBtn.getStyleClass().add("primary-button");
        addGoalBtn.setOnAction(e -> showAddGoalDialog());
        
        HBox.setHgrow(titleBox, Priority.ALWAYS);
        header.getChildren().addAll(titleBox, addGoalBtn);
        
        // Goals container
        goalsContainer = new VBox(15);
        goalsContainer.setPadding(new Insets(10, 0, 0, 0));
        
        ScrollPane scrollPane = new ScrollPane(goalsContainer);
        scrollPane.setFitToWidth(true);
        scrollPane.getStyleClass().add("transparent-scroll");
        VBox.setVgrow(scrollPane, Priority.ALWAYS);
        
        view.getChildren().addAll(header, scrollPane);
    }

    private void loadGoals() {
        // Recompute progress from today's actual tracked data before
        // displaying. Goals were previously created with current_value
        // hardcoded to 0 and nothing else in the app ever updated it, so
        // every goal card permanently showed "0 / target (0%)" no matter
        // how much time was actually tracked, and NotificationService's
        // goal-reached check ("current_value >= target_value") could never
        // fire. See the matching refresh in NotificationService.checkGoals()
        // which keeps this correct even when this view isn't open.
        updateGoalProgress();
        
        goalsContainer.getChildren().clear();
        
        String sql = "SELECT * FROM goals WHERE is_active = 1 ORDER BY created_at DESC";
        
        try (Statement stmt = databaseManager.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                VBox goalCard = createGoalCard(
                    rs.getInt("id"),
                    rs.getString("type"),
                    rs.getInt("target_value"),
                    rs.getInt("current_value"),
                    rs.getString("start_date"),
                    rs.getString("end_date")
                );
                goalsContainer.getChildren().add(goalCard);
            }
            
            if (goalsContainer.getChildren().isEmpty()) {
                showEmptyState();
            }
            
        } catch (SQLException e) {
            logger.severe("Error loading goals: " + e.getMessage());
        }
    }

    /**
     * Recalculates current_value for every active goal from today's real
     * tracked data (usage_tracking / daily_stats / focus_sessions) and
     * persists it, so goal progress reflects what actually happened today
     * instead of staying frozen at its initial value.
     */
    private void updateGoalProgress() {
        String selectSql = "SELECT id, type FROM goals WHERE is_active = 1";
        try (Statement stmt = databaseManager.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(selectSql)) {
            
            while (rs.next()) {
                int id = rs.getInt("id");
                String type = rs.getString("type");
                int minutes = computeTodayMinutesForGoalType(type);
                
                try (PreparedStatement upd = databaseManager.getConnection().prepareStatement(
                        "UPDATE goals SET current_value = ? WHERE id = ?")) {
                    upd.setInt(1, minutes);
                    upd.setInt(2, id);
                    upd.executeUpdate();
                }
            }
        } catch (SQLException e) {
            logger.warning("Error updating goal progress: " + e.getMessage());
        }
    }

    /**
     * Today's tracked minutes for a given goal type. Screen time and
     * productive time come from the already-aggregated daily_stats /
     * usage_tracking tables; focus time comes from completed Pomodoro
     * sessions; social media is approximated using the "Communication"
     * category since that's the closest match among the app's fixed
     * category set.
     */
    private int computeTodayMinutesForGoalType(String type) {
        String sql = switch (type.toLowerCase()) {
            case "screen_time" -> 
                "SELECT COALESCE(total_screen_time, 0) / 60 AS m FROM daily_stats WHERE date = ?";
            case "productive_time" -> """
                SELECT COALESCE(SUM(ut.duration_seconds * c.productivity_weight), 0) / 60 AS m
                FROM usage_tracking ut
                JOIN applications a ON ut.application_id = a.id
                JOIN categories c ON a.category_id = c.id
                WHERE date(ut.start_time) = ?
                """;
            case "social_media" -> """
                SELECT COALESCE(SUM(ut.duration_seconds), 0) / 60 AS m
                FROM usage_tracking ut
                JOIN applications a ON ut.application_id = a.id
                JOIN categories c ON a.category_id = c.id
                WHERE c.name = 'Communication'
                AND date(ut.start_time) = ?
                """;
            case "focus_time" -> 
                "SELECT COALESCE(SUM(duration_minutes), 0) AS m FROM focus_sessions " +
                "WHERE date(start_time) = ? AND completed = 1";
            default -> null;
        };
        
        if (sql == null) return 0;
        
        // Bound local date, not SQLite's UTC-based date('now') - see
        // ActivityTracker.loadTodayAppUsage() for why that matters.
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, java.time.LocalDate.now().toString());
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) return rs.getInt("m");
        } catch (SQLException e) {
            logger.warning("Error computing progress for goal type " + type + ": " + e.getMessage());
        }
        return 0;
    }

    private VBox createGoalCard(int id, String type, int targetValue, 
                                int currentValue, String startDate, String endDate) {
        VBox card = new VBox(15);
        card.getStyleClass().add("goal-card");
        card.setPadding(new Insets(20));
        
        // Header
        HBox header = new HBox(10);
        header.setAlignment(Pos.CENTER_LEFT);
        
        String icon = getGoalIcon(type);
        Label iconLabel = new Label(icon);
        iconLabel.setFont(Font.font(28));
        
        VBox titleBox = new VBox(3);
        Label typeLabel = new Label(formatGoalType(type));
        typeLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
        
        Label periodLabel = new Label(formatPeriod(startDate, endDate));
        periodLabel.getStyleClass().add("period-label");
        
        titleBox.getChildren().addAll(typeLabel, periodLabel);
        
        HBox.setHgrow(titleBox, Priority.ALWAYS);
        
        // Delete button
        Button deleteBtn = new Button("✕");
        deleteBtn.getStyleClass().add("delete-button");
        deleteBtn.setOnAction(e -> {
            deleteGoal(id);
            loadGoals();
        });
        
        header.getChildren().addAll(iconLabel, titleBox, deleteBtn);
        
        // Progress section
        VBox progressSection = new VBox(10);
        
        double progress = targetValue > 0 ? (double) currentValue / targetValue : 0;
        progress = Math.min(progress, 1.0);
        final double clampedProgress = progress;
        
        // Custom progress bar
        StackPane progressBar = new StackPane();
        progressBar.setPrefHeight(12);
        progressBar.getStyleClass().add("goal-progress-track");
        
        StackPane progressFill = new StackPane();
        progressFill.setPrefHeight(12);
        progressFill.getStyleClass().add("goal-progress-fill");
        
        // Determine color based on progress
        String progressColor;
        if (progress >= 1.0) {
            progressColor = "#F44336";
        } else if (progress >= 0.8) {
            progressColor = "#FF9800";
        } else {
            progressColor = "#4CAF50";
        }
        progressFill.setStyle("-fx-background-color: " + progressColor + ";");
        
        // Animate progress fill width
        progressBar.widthProperty().addListener((obs, oldVal, newVal) -> {
            progressFill.setPrefWidth(newVal.doubleValue() * clampedProgress);
        });
        
        progressBar.getChildren().add(progressFill);
        StackPane.setAlignment(progressFill, Pos.CENTER_LEFT);
        
        // Progress text
        HBox progressText = new HBox();
        progressText.setAlignment(Pos.CENTER_LEFT);
        
        Label progressLabel = new Label(String.format("%d / %d", currentValue, targetValue));
        progressLabel.setFont(Font.font("Segoe UI", FontWeight.SEMI_BOLD, 14));
        
        Label percentLabel = new Label(String.format("(%.0f%%)", progress * 100));
        percentLabel.getStyleClass().add("percentage-label");
        
        HBox.setHgrow(progressLabel, Priority.ALWAYS);
        progressText.getChildren().addAll(progressLabel, percentLabel);
        
        // Unit label
        Label unitLabel = new Label(getUnitForType(type));
        unitLabel.getStyleClass().add("unit-label");
        
        progressSection.getChildren().addAll(progressBar, progressText, unitLabel);
        
        card.getChildren().addAll(header, progressSection);
        
        // Add hover effect
        addCardHoverEffect(card);
        
        return card;
    }

    private String getGoalIcon(String type) {
        return switch (type.toLowerCase()) {
            case "screen_time" -> "📱";
            case "social_media" -> "💬";
            case "focus_time" -> "🎯";
            case "productive_time" -> "💪";
            default -> "📊";
        };
    }

    private String formatGoalType(String type) {
        return switch (type.toLowerCase()) {
            case "screen_time" -> "Maximum Screen Time";
            case "social_media" -> "Maximum Social Media";
            case "focus_time" -> "Daily Focus Target";
            case "productive_time" -> "Productive Time Target";
            default -> type.replace("_", " ");
        };
    }

    private String getUnitForType(String type) {
        return switch (type.toLowerCase()) {
            case "screen_time", "social_media", "focus_time", "productive_time" -> "minutes per day";
            default -> "units";
        };
    }

    private String formatPeriod(String startDate, String endDate) {
        if (endDate == null) {
            return "Since " + formatDate(startDate) + " (Ongoing)";
        }
        return formatDate(startDate) + " - " + formatDate(endDate);
    }

    private String formatDate(String dateStr) {
        try {
            LocalDate date = LocalDate.parse(dateStr);
            return date.format(DateTimeFormatter.ofPattern("MMM d, yyyy"));
        } catch (Exception e) {
            return dateStr;
        }
    }

    private void addCardHoverEffect(VBox card) {
        card.setOnMouseEntered(e -> {
            TranslateTransition tt = new TranslateTransition(Duration.millis(200), card);
            tt.setToX(5);
            tt.play();
            
            card.setStyle("-fx-background-color: derive(-fx-base, 5%); -fx-background-radius: 10;");
        });
        
        card.setOnMouseExited(e -> {
            TranslateTransition tt = new TranslateTransition(Duration.millis(200), card);
            tt.setToX(0);
            tt.play();
            
            card.setStyle("-fx-background-color: -fx-base; -fx-background-radius: 10;");
        });
    }

    private void showAddGoalDialog() {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("New Goal");
        dialog.setHeaderText("Set a new wellbeing goal");
        
        // Create the form
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(15);
        grid.setPadding(new Insets(20));
        
        ComboBox<String> typeCombo = new ComboBox<>();
        typeCombo.getItems().addAll("Screen Time", "Social Media", "Focus Time", "Productive Time");
        typeCombo.setValue("Screen Time");
        
        TextField targetField = new TextField();
        targetField.setPromptText("Target value in minutes");
        
        TextField startDateField = new TextField(LocalDate.now().toString());
        startDateField.setPromptText("YYYY-MM-DD");
        
        grid.add(new Label("Goal Type:"), 0, 0);
        grid.add(typeCombo, 1, 0);
        grid.add(new Label("Target:"), 0, 1);
        grid.add(targetField, 1, 1);
        grid.add(new Label("Start Date:"), 0, 2);
        grid.add(startDateField, 1, 2);
        
        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        
        dialog.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                try {
                    String type = typeCombo.getValue().toLowerCase().replace(" ", "_");
                    int target = Integer.parseInt(targetField.getText());
                    String startDate = startDateField.getText();
                    
                    if (target <= 0) {
                        showAlert("Invalid Input", "Target value must be greater than 0.");
                        return;
                    }
                    
                    LocalDate.parse(startDate); // validates YYYY-MM-DD format
                    
                    saveGoal(type, target, startDate);
                    loadGoals();
                } catch (NumberFormatException e) {
                    showAlert("Invalid Input", "Please enter a valid number for the target value.");
                } catch (java.time.format.DateTimeParseException e) {
                    showAlert("Invalid Input", "Please enter the start date as YYYY-MM-DD.");
                }
            }
        });
    }

    private void saveGoal(String type, int targetValue, String startDate) {
        String sql = """
            INSERT INTO goals (type, target_value, current_value, start_date)
            VALUES (?, ?, 0, ?)
            """;
        
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, type);
            pstmt.setInt(2, targetValue);
            pstmt.setString(3, startDate);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            logger.severe("Error saving goal: " + e.getMessage());
        }
    }

    private void deleteGoal(int id) {
        String sql = "UPDATE goals SET is_active = 0 WHERE id = ?";
        try (PreparedStatement pstmt = databaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            logger.severe("Error deleting goal: " + e.getMessage());
        }
    }

    private void showEmptyState() {
        VBox emptyState = new VBox(20);
        emptyState.setAlignment(Pos.CENTER);
        emptyState.setPadding(new Insets(50));
        
        Label iconLabel = new Label("🎯");
        iconLabel.setFont(Font.font(48));
        
        Label messageLabel = new Label("No goals set yet");
        messageLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        
        Label subMessage = new Label("Click '+ New Goal' to set your first wellbeing target");
        subMessage.getStyleClass().add("subtitle-label");
        
        emptyState.getChildren().addAll(iconLabel, messageLabel, subMessage);
        goalsContainer.getChildren().add(emptyState);
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public VBox getView() {
        return view;
    }
}
package com.deskwell.view;

import com.deskwell.service.CSVExporter;
import com.deskwell.service.PDFExporter;
import com.deskwell.service.ReportService;
import com.deskwell.service.ReportService.*;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;

import java.io.File;
import java.time.LocalDate;
import java.util.logging.Logger;

public class ReportsView {
    private static final Logger logger = Logger.getLogger(ReportsView.class.getName());
    private final ReportService reportService;
    private VBox view;
    private StackPane contentArea;
    private ComboBox<String> reportTypeCombo;
    private DatePicker startDatePicker;
    private DatePicker endDatePicker;
    
    public ReportsView(ReportService reportService) {
        this.reportService = reportService;
        buildView();
    }

    private void buildView() {
        view = new VBox(20);
        view.setPadding(new Insets(25));
        
        // Header
        HBox header = createHeader();
        
        // Report controls
        HBox controls = createControls();
        
        // Content area
        contentArea = new StackPane();
        contentArea.getStyleClass().add("report-content");
        VBox.setVgrow(contentArea, Priority.ALWAYS);
        
        view.getChildren().addAll(header, controls, contentArea);
        
        // Show default report
        showDailyReport(LocalDate.now());
    }

    private HBox createHeader() {
        HBox header = new HBox();
        header.setAlignment(Pos.CENTER_LEFT);
        
        VBox titleBox = new VBox(5);
        Label title = new Label("Reports");
        title.getStyleClass().add("view-title");
        
        Label subtitle = new Label("Detailed analysis and export options");
        subtitle.getStyleClass().add("subtitle-label");
        
        titleBox.getChildren().addAll(title, subtitle);
        
        HBox.setHgrow(titleBox, Priority.ALWAYS);
        
        // Export buttons
        HBox exportButtons = new HBox(10);
        
        Button csvExportBtn = new Button("Export CSV");
        csvExportBtn.getStyleClass().add("export-button");
        csvExportBtn.setOnAction(e -> exportCSV());
        
        Button pdfExportBtn = new Button("Export PDF");
        pdfExportBtn.getStyleClass().add("export-button");
        pdfExportBtn.setOnAction(e -> exportPDF());
        
        exportButtons.getChildren().addAll(csvExportBtn, pdfExportBtn);
        header.getChildren().addAll(titleBox, exportButtons);
        
        return header;
    }

    private HBox createControls() {
        HBox controls = new HBox(15);
        controls.setAlignment(Pos.CENTER_LEFT);
        controls.getStyleClass().add("report-controls");
        controls.setPadding(new Insets(15));
        
        // Report type selector
        reportTypeCombo = new ComboBox<>();
        reportTypeCombo.getItems().addAll("Daily Report", "Weekly Report", "Monthly Report");
        reportTypeCombo.setValue("Daily Report");
        reportTypeCombo.setOnAction(e -> updateReport());
        
        // Date pickers
        Label fromLabel = new Label("From:");
        startDatePicker = new DatePicker(LocalDate.now());
        startDatePicker.setOnAction(e -> updateReport());
        
        Label toLabel = new Label("To:");
        endDatePicker = new DatePicker(LocalDate.now());
        endDatePicker.setOnAction(e -> updateReport());
        
        // Generate button
        Button generateBtn = new Button("Generate Report");
        generateBtn.getStyleClass().add("primary-button");
        generateBtn.setOnAction(e -> updateReport());
        
        controls.getChildren().addAll(
            reportTypeCombo, 
            new Separator(javafx.geometry.Orientation.VERTICAL),
            fromLabel, startDatePicker,
            toLabel, endDatePicker,
            generateBtn
        );
        
        return controls;
    }

    private void updateReport() {
        String reportType = reportTypeCombo.getValue();
        
        switch (reportType) {
            case "Daily Report" -> {
                LocalDate date = startDatePicker.getValue();
                if (date != null) {
                    showDailyReport(date);
                }
            }
            case "Weekly Report" -> showWeeklyReport();
            case "Monthly Report" -> showMonthlyReport();
        }
    }

    private void showDailyReport(LocalDate date) {
        contentArea.getChildren().clear();
        
        DailyReport report = reportService.getDailyReport(date);
        
        VBox reportView = new VBox(20);
        reportView.setPadding(new Insets(20));
        
        // Summary cards
        HBox summaryCards = new HBox(15);
        summaryCards.getChildren().addAll(
            createSummaryCard("Screen Time", report.getFormattedScreenTime(), "#2196F3"),
            createSummaryCard("Productive Time", report.getFormattedProductiveTime(), "#4CAF50"),
            createSummaryCard("Sessions", String.valueOf(report.sessionCount), "#FF9800"),
            createSummaryCard("Productivity", String.format("%.1f%%", report.productivityScore), 
                report.productivityScore >= 70 ? "#4CAF50" : "#F44336")
        );
        
        // App usage table
        TableView<AppUsageInfo> appTable = createAppUsageTable();
        appTable.setItems(FXCollections.observableArrayList(report.appUsage));
        
        reportView.getChildren().addAll(summaryCards, 
            new Label("Application Usage"), appTable);
        
        contentArea.getChildren().add(new ScrollPane(reportView));
    }

    private void showWeeklyReport() {
        contentArea.getChildren().clear();
        
        WeeklyReport report = reportService.getWeeklyReport(0);
        
        VBox reportView = new VBox(20);
        reportView.setPadding(new Insets(20));
        
        // Summary
        HBox summaryCards = new HBox(15);
        summaryCards.getChildren().addAll(
            createSummaryCard("Total Screen Time", report.getFormattedTotalTime(), "#2196F3"),
            createSummaryCard("Daily Average", report.getFormattedAverage(), "#4CAF50"),
            createSummaryCard("Productivity", 
                String.format("%.1f%%", report.averageProductivityScore), "#FF9800")
        );
        
        // Daily breakdown table
        TableView<DailySummary> dailyTable = new TableView<>();
        
        TableColumn<DailySummary, String> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getFormattedDate()));
        
        TableColumn<DailySummary, String> screenCol = new TableColumn<>("Screen Time");
        screenCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(
                ReportService.formatDuration(data.getValue().totalScreenTime)));
        
        TableColumn<DailySummary, String> prodCol = new TableColumn<>("Productivity");
        prodCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(
                String.format("%.1f%%", data.getValue().productivityScore)));
        
        dailyTable.getColumns().addAll(dateCol, screenCol, prodCol);
        dailyTable.setItems(FXCollections.observableArrayList(report.dailySummaries));
        
        reportView.getChildren().addAll(summaryCards, 
            new Label("Daily Breakdown"), dailyTable);
        
        contentArea.getChildren().add(new ScrollPane(reportView));
    }

    private void showMonthlyReport() {
        contentArea.getChildren().clear();
        
        MonthlyReport report = reportService.getMonthlyReport(0);
        
        VBox reportView = new VBox(20);
        reportView.setPadding(new Insets(20));
        
        // Summary
        HBox summaryCards = new HBox(15);
        summaryCards.getChildren().addAll(
            createSummaryCard("Total Screen Time", report.getFormattedTotalTime(), "#2196F3"),
            createSummaryCard("Daily Average", 
                ReportService.formatDuration(report.averageDailyScreenTime), "#4CAF50"),
            createSummaryCard("Productivity", 
                String.format("%.1f%%", report.averageProductivityScore), "#FF9800")
        );
        
        // Insights
        VBox insights = new VBox(10);
        insights.getStyleClass().add("insights-box");
        insights.setPadding(new Insets(15));
        
        Label insightsTitle = new Label("📊 Monthly Insights");
        insightsTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
        
        if (report.mostProductiveDay != null) {
            Label productiveDay = new Label(
                String.format("🎯 Most productive day: %s (%.1f%% productivity)",
                    report.mostProductiveDay.getFormattedDate(),
                    report.mostProductiveDay.productivityScore)
            );
            insights.getChildren().addAll(insightsTitle, productiveDay);
        }
        
        // Category breakdown
        VBox categoryBox = new VBox(10);
        Label categoryTitle = new Label("Category Breakdown");
        categoryTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        categoryBox.getChildren().add(categoryTitle);
        
        for (var entry : report.categoryBreakdown.entrySet()) {
            HBox categoryRow = new HBox(10);
            categoryRow.setAlignment(Pos.CENTER_LEFT);
            
            Label nameLabel = new Label(entry.getKey());
            Label timeLabel = new Label(ReportService.formatDuration(entry.getValue()));
            
            categoryRow.getChildren().addAll(nameLabel, timeLabel);
            categoryBox.getChildren().add(categoryRow);
        }
        
        reportView.getChildren().addAll(summaryCards, insights, categoryBox);
        
        contentArea.getChildren().add(new ScrollPane(reportView));
    }

    private VBox createSummaryCard(String title, String value, String color) {
        VBox card = new VBox(10);
        card.getStyleClass().add("report-summary-card");
        card.setPadding(new Insets(15));
        card.setPrefWidth(200);
        card.setAlignment(Pos.CENTER);
        
        Label valueLabel = new Label(value);
        valueLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
        valueLabel.setStyle("-fx-text-fill: " + color + ";");
        
        Label titleLabel = new Label(title);
        titleLabel.getStyleClass().add("report-card-title");
        
        // Color bar
        StackPane colorBar = new StackPane();
        colorBar.setPrefHeight(4);
        colorBar.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 2;");
        
        card.getChildren().addAll(valueLabel, titleLabel, colorBar);
        
        return card;
    }

    private TableView<AppUsageInfo> createAppUsageTable() {
        TableView<AppUsageInfo> table = new TableView<>();
        
        TableColumn<AppUsageInfo, String> nameCol = new TableColumn<>("Application");
        nameCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().name));
        nameCol.setPrefWidth(200);
        
        TableColumn<AppUsageInfo, String> categoryCol = new TableColumn<>("Category");
        categoryCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().category));
        categoryCol.setPrefWidth(120);
        
        TableColumn<AppUsageInfo, String> timeCol = new TableColumn<>("Time");
        timeCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getFormattedTime()));
        timeCol.setPrefWidth(100);
        
        TableColumn<AppUsageInfo, Number> sessionsCol = new TableColumn<>("Sessions");
        sessionsCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleIntegerProperty(data.getValue().sessionCount));
        sessionsCol.setPrefWidth(80);
        
        table.getColumns().addAll(nameCol, categoryCol, timeCol, sessionsCol);
        table.setPrefHeight(400);
        
        return table;
    }

    private void exportCSV() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Export CSV Report");
        fileChooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("CSV Files", "*.csv")
        );
        fileChooser.setInitialFileName("deskwell_report.csv");
        
        File file = fileChooser.showSaveDialog(view.getScene().getWindow());
        if (file != null) {
            try {
                var data = reportService.getExportData(
                    startDatePicker.getValue(),
                    endDatePicker.getValue()
                );
                CSVExporter.exportRawData(data, file.getAbsolutePath());
                
                showAlert("Success", "Report exported successfully to:\n" + file.getAbsolutePath());
            } catch (Exception e) {
                logger.severe("Error exporting CSV: " + e.getMessage());
                showAlert("Error", "Failed to export report: " + e.getMessage());
            }
        }
    }

    private void exportPDF() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Export PDF Report");
        fileChooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("PDF Files", "*.pdf")
        );
        fileChooser.setInitialFileName("deskwell_report.pdf");
        
        File file = fileChooser.showSaveDialog(view.getScene().getWindow());
        if (file != null) {
            try {
                // Generate appropriate report based on type
                String reportType = reportTypeCombo.getValue();
                File generatedFile;
                
                switch (reportType) {
                    case "Daily Report" -> {
                        DailyReport report = reportService.getDailyReport(startDatePicker.getValue());
                        generatedFile = PDFExporter.exportDailyReport(report);
                    }
                    case "Weekly Report" -> {
                        WeeklyReport report = reportService.getWeeklyReport(0);
                        generatedFile = PDFExporter.exportWeeklyReport(report);
                    }
                    case "Monthly Report" -> {
                        MonthlyReport report = reportService.getMonthlyReport(0);
                        generatedFile = PDFExporter.exportMonthlyReport(report);
                    }
                    default -> throw new IllegalStateException("Unknown report type");
                }
                
                // Copy to selected location
                java.nio.file.Files.copy(
                    generatedFile.toPath(), 
                    file.toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING
                );
                
                showAlert("Success", "PDF report exported successfully to:\n" + file.getAbsolutePath());
            } catch (Exception e) {
                logger.severe("Error exporting PDF: " + e.getMessage());
                showAlert("Error", "Failed to export PDF: " + e.getMessage());
            }
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public VBox getView() {
        return view;
    }
}
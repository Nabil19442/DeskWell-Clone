package com.deskwell.view;

import com.deskwell.database.DatabaseManager;
import com.deskwell.service.*;
import com.deskwell.tracker.ActivityTracker;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;

import java.io.File;
import java.util.logging.Logger;

public class SettingsView {
    private static final Logger logger = Logger.getLogger(SettingsView.class.getName());
    private final SettingsService settingsService;
    private final DatabaseManager databaseManager;
    private final ThemeManager themeManager;
    private final BackupService backupService;
    private final StartupManager startupManager;
    private final ActivityTracker activityTracker;
    private VBox view;

    public SettingsView(SettingsService settingsService, DatabaseManager databaseManager,
                       ThemeManager themeManager, BackupService backupService,
                       StartupManager startupManager, ActivityTracker activityTracker) {
        this.settingsService = settingsService;
        this.databaseManager = databaseManager;
        this.themeManager = themeManager;
        this.backupService = backupService;
        this.startupManager = startupManager;
        this.activityTracker = activityTracker;
        buildView();
    }

    private void buildView() {
        view = new VBox(25);
        view.setPadding(new Insets(25));
        
        // Header
        HBox header = createHeader();
        
        // Settings sections
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setFitToWidth(true);
        scrollPane.getStyleClass().add("transparent-scroll");
        
        VBox content = new VBox(20);
        content.setPadding(new Insets(10, 0, 0, 0));
        
        content.getChildren().addAll(
            createAppearanceSection(),
            createNotificationSection(),
            createTrackingSection(),
            createBackupSection(),
            createStartupSection(),
            createAboutSection()
        );
        
        scrollPane.setContent(content);
        view.getChildren().addAll(header, scrollPane);
    }

    private HBox createHeader() {
        HBox header = new HBox();
        header.setAlignment(Pos.CENTER_LEFT);
        
        VBox titleBox = new VBox(5);
        Label title = new Label("Settings");
        title.getStyleClass().add("view-title");
        
        Label subtitle = new Label("Customize your DeskWell experience");
        subtitle.getStyleClass().add("subtitle-label");
        
        titleBox.getChildren().addAll(title, subtitle);
        HBox.setHgrow(titleBox, Priority.ALWAYS);
        
        header.getChildren().add(titleBox);
        
        return header;
    }

    private VBox createAppearanceSection() {
        VBox section = createSection("🎨 Appearance");
        
        // Theme toggle
        HBox themeRow = createSettingRow(
            "Theme",
            "Switch between light and dark mode"
        );
        
        ToggleButton themeToggle = new ToggleButton(
            themeManager.isDarkMode() ? "Dark Mode" : "Light Mode"
        );
        themeToggle.setSelected(themeManager.isDarkMode());
        themeToggle.getStyleClass().add("theme-toggle");
        
        themeToggle.setOnAction(e -> {
            themeManager.toggleTheme();
            themeToggle.setText(themeManager.isDarkMode() ? "Dark Mode" : "Light Mode");
        });
        
        themeRow.getChildren().add(themeToggle);
        section.getChildren().add(themeRow);
        
        return section;
    }

    private VBox createNotificationSection() {
        VBox section = createSection("🔔 Notifications");
        
        // Break reminders
        HBox breakRow = createSettingRow(
            "Break Reminders",
            "Get reminded to take breaks"
        );
        
        ToggleButton breakToggle = new ToggleButton("Enabled");
        breakToggle.setSelected(
            Boolean.parseBoolean(settingsService.getSetting("break_reminder_enabled", "true"))
        );
        breakToggle.setOnAction(e -> {
            boolean enabled = breakToggle.isSelected();
            settingsService.setSetting("break_reminder_enabled", String.valueOf(enabled));
            breakToggle.setText(enabled ? "Enabled" : "Disabled");
        });
        
        breakRow.getChildren().add(breakToggle);
        
        // Break interval
        HBox intervalRow = createSettingRow(
            "Break Interval",
            "Minutes between break reminders"
        );
        
        Spinner<Integer> intervalSpinner = new Spinner<>(15, 120, 
            Integer.parseInt(settingsService.getSetting("break_interval_minutes", "60")), 5);
        intervalSpinner.setPrefWidth(100);
        intervalSpinner.valueProperty().addListener((obs, old, newVal) -> {
            settingsService.setSetting("break_interval_minutes", String.valueOf(newVal));
        });
        
        intervalRow.getChildren().add(intervalSpinner);
        
        // Screen time warnings
        HBox warningRow = createSettingRow(
            "Screen Time Warnings",
            "Get notified when exceeding screen time"
        );
        
        ToggleButton warningToggle = new ToggleButton("Enabled");
        warningToggle.setSelected(
            Boolean.parseBoolean(settingsService.getSetting("screen_time_warning_enabled", "true"))
        );
        warningToggle.setOnAction(e -> {
            boolean enabled = warningToggle.isSelected();
            settingsService.setSetting("screen_time_warning_enabled", String.valueOf(enabled));
            warningToggle.setText(enabled ? "Enabled" : "Disabled");
        });
        
        warningRow.getChildren().add(warningToggle);
        
        section.getChildren().addAll(breakRow, intervalRow, warningRow);
        
        return section;
    }

    private VBox createTrackingSection() {
        VBox section = createSection("📊 Tracking");
        
        // Polling interval
        HBox pollingRow = createSettingRow(
            "Tracking Frequency",
            "How often to check active window (seconds)"
        );
        
        int currentPollingInterval = activityTracker != null
            ? activityTracker.getPollingIntervalSeconds()
            : Integer.parseInt(settingsService.getSetting("tracking_frequency_seconds", "3"));
        
        Spinner<Integer> pollingSpinner = new Spinner<>(1, 30, currentPollingInterval, 1);
        pollingSpinner.setPrefWidth(100);
        pollingSpinner.setEditable(true);
        pollingSpinner.valueProperty().addListener((obs, old, newVal) -> {
            if (activityTracker != null) {
                activityTracker.setPollingIntervalSeconds(newVal);
            } else {
                settingsService.setSetting("tracking_frequency_seconds", String.valueOf(newVal));
            }
        });
        
        pollingRow.getChildren().add(pollingSpinner);
        
        // Idle threshold
        HBox idleRow = createSettingRow(
            "Idle Detection",
            "Time before considering user idle (seconds)"
        );
        
        int currentIdleThreshold = activityTracker != null
            ? activityTracker.getIdleThresholdSeconds()
            : Integer.parseInt(settingsService.getSetting("idle_threshold_seconds", "60"));
        
        Spinner<Integer> idleSpinner = new Spinner<>(30, 600, currentIdleThreshold, 30);
        idleSpinner.setPrefWidth(100);
        idleSpinner.setEditable(true);
        idleSpinner.valueProperty().addListener((obs, old, newVal) -> {
            if (activityTracker != null) {
                activityTracker.setIdleThresholdSeconds(newVal);
            } else {
                settingsService.setSetting("idle_threshold_seconds", String.valueOf(newVal));
            }
        });
        
        idleRow.getChildren().add(idleSpinner);
        
        // Clear data
        HBox clearRow = createSettingRow(
            "Clear Tracking Data",
            "Remove all usage history"
        );
        
        Button clearBtn = new Button("Clear All Data");
        clearBtn.getStyleClass().add("danger-button");
        clearBtn.setOnAction(e -> {
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Clear All Data");
            confirm.setHeaderText("Are you sure?");
            confirm.setContentText("This will permanently delete all your tracking data, " +
                "goals, and focus sessions. This action cannot be undone.");
            
            confirm.showAndWait().ifPresent(response -> {
                if (response == ButtonType.OK) {
                    clearAllData();
                }
            });
        });
        
        clearRow.getChildren().add(clearBtn);
        
        section.getChildren().addAll(pollingRow, idleRow, clearRow);
        
        return section;
    }

    private VBox createBackupSection() {
        VBox section = createSection("💾 Backup & Restore");
        
        // Database info
        HBox infoRow = createSettingRow(
            "Database Size",
            "Current database file size"
        );
        
        Label sizeLabel = new Label(backupService.getBackupSizeFormatted());
        sizeLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        infoRow.getChildren().add(sizeLabel);
        
        // Backup button
        HBox backupRow = createSettingRow(
            "Create Backup",
            "Export all data to a backup file"
        );
        
        Button backupBtn = new Button("Backup Now");
        backupBtn.getStyleClass().add("action-button");
        backupBtn.setOnAction(e -> createBackup());
        
        backupRow.getChildren().add(backupBtn);
        
        // Restore button
        HBox restoreRow = createSettingRow(
            "Restore Backup",
            "Restore data from a previous backup"
        );
        
        Button restoreBtn = new Button("Restore");
        restoreBtn.getStyleClass().add("action-button");
        restoreBtn.setOnAction(e -> restoreBackup());
        
        restoreRow.getChildren().add(restoreBtn);
        
        section.getChildren().addAll(infoRow, backupRow, restoreRow);
        
        return section;
    }

    private VBox createStartupSection() {
        VBox section = createSection("🚀 Startup");
        
        HBox startupRow = createSettingRow(
            "Start with Windows",
            "Launch DeskWell when Windows starts"
        );
        
        ToggleButton startupToggle = new ToggleButton("Enabled");
        startupToggle.setSelected(startupManager.isStartupEnabled());
        startupToggle.setOnAction(e -> {
            boolean enabled = startupToggle.isSelected();
            startupManager.setStartupWithWindows(enabled);
            startupToggle.setText(enabled ? "Enabled" : "Disabled");
        });
        
        startupRow.getChildren().add(startupToggle);
        section.getChildren().add(startupRow);
        
        return section;
    }

    private VBox createAboutSection() {
        VBox section = createSection("ℹ️ About");
        
        // App info
        HBox versionRow = createSettingRow(
            "Version",
            "Current application version"
        );
        
        Label versionLabel = new Label("1.0.0");
        versionLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        versionRow.getChildren().add(versionLabel);
        
        // Credits
        HBox creditsRow = createSettingRow(
            "Built With",
            "Java 21, JavaFX, SQLite, JNA"
        );
        
        // License
        HBox licenseRow = createSettingRow(
            "License",
            "MIT License - Free and Open Source"
        );
        
        Label licenseLabel = new Label("Open Source");
        licenseLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        licenseRow.getChildren().add(licenseLabel);
        
        section.getChildren().addAll(versionRow, creditsRow, licenseRow);
        
        return section;
    }

    private VBox createSection(String title) {
        VBox section = new VBox(10);
        section.getStyleClass().add("settings-section");
        section.setPadding(new Insets(20));
        
        Label titleLabel = new Label(title);
        titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        
        section.getChildren().add(titleLabel);
        
        return section;
    }

    private HBox createSettingRow(String title, String description) {
        HBox row = new HBox(15);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(12, 0, 12, 0));
        
        VBox textBox = new VBox(3);
        Label titleLabel = new Label(title);
        titleLabel.setFont(Font.font("Segoe UI", FontWeight.SEMI_BOLD, 14));
        
        Label descLabel = new Label(description);
        descLabel.getStyleClass().add("setting-description");
        
        textBox.getChildren().addAll(titleLabel, descLabel);
        
        HBox.setHgrow(textBox, Priority.ALWAYS);
        row.getChildren().add(textBox);
        
        return row;
    }

    private void createBackup() {
        FileChooser dirChooser = new FileChooser();
        dirChooser.setTitle("Save Backup");
        dirChooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("ZIP Files", "*.zip")
        );
        dirChooser.setInitialFileName("deskwell_backup.zip");
        
        File file = dirChooser.showSaveDialog(view.getScene().getWindow());
        if (file != null) {
            try {
                File backupFile = backupService.createBackup(file.getParent());
                
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Backup Successful");
                alert.setHeaderText(null);
                alert.setContentText("Database backup created successfully!\n\n" +
                    "Location: " + backupFile.getAbsolutePath());
                alert.showAndWait();
                
            } catch (Exception e) {
                logger.severe("Backup failed: " + e.getMessage());
                
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Backup Failed");
                alert.setHeaderText(null);
                alert.setContentText("Failed to create backup: " + e.getMessage());
                alert.showAndWait();
            }
        }
    }

    private void restoreBackup() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Backup File");
        fileChooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("ZIP Files", "*.zip")
        );
        
        File file = fileChooser.showOpenDialog(view.getScene().getWindow());
        if (file != null) {
            Alert confirm = new Alert(Alert.AlertType.WARNING);
            confirm.setTitle("Restore Backup");
            confirm.setHeaderText("Warning: This will overwrite all current data!");
            confirm.setContentText("Are you sure you want to restore from this backup?\n\n" +
                "All current data will be lost and replaced with the backup data.");
            
            confirm.showAndWait().ifPresent(response -> {
                if (response == ButtonType.OK) {
                    try {
                        backupService.restoreBackup(file);
                        
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Restore Successful");
                        alert.setHeaderText(null);
                        alert.setContentText("Database restored successfully!\n\n" +
                            "Please restart the application for changes to take effect.");
                        alert.showAndWait();
                        
                    } catch (Exception e) {
                        logger.severe("Restore failed: " + e.getMessage());
                        
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Restore Failed");
                        alert.setHeaderText(null);
                        alert.setContentText("Failed to restore backup: " + e.getMessage());
                        alert.showAndWait();
                    }
                }
            });
        }
    }

    private void clearAllData() {
        try {
            // Clear all tables
            String[] tables = {"usage_tracking", "sessions", "daily_stats", 
                              "goals", "focus_sessions", "blocked_apps"};
            
            for (String table : tables) {
                String sql = "DELETE FROM " + table;
                try (java.sql.Statement stmt = databaseManager.getConnection().createStatement()) {
                    stmt.execute(sql);
                }
            }
            
            // Without this, the dashboard kept showing the old screen time /
            // app usage numbers until the app was restarted, since the
            // tracker's in-memory stats weren't aware the DB had just been wiped.
            if (activityTracker != null) {
                activityTracker.reloadStatsFromDatabase();
            }
            
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Data Cleared");
            alert.setHeaderText(null);
            alert.setContentText("All tracking data has been cleared successfully.\n\n" +
                "Application categories and settings have been preserved.");
            alert.showAndWait();
            
        } catch (Exception e) {
            logger.severe("Failed to clear data: " + e.getMessage());
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Failed to clear data: " + e.getMessage());
            alert.showAndWait();
        }
    }

    public VBox getView() {
        return view;
    }
}